# RDM Pro — প্রজেক্ট নোট (নতুন চ্যাটে কাজ চালিয়ে যেতে এই ZIP আপলোড করলেই হবে)

Personal-use Android download manager (1DM alternative). Kotlin + Jetpack Compose. minSdk 29, targetSdk 34.
Built in the cloud by GitHub Actions from `project.zip` (no laptop). Same signing key every build (`app/rdm.keystore`).

## Status
- v0.1: Hello app (pipeline test) — done
- v0.2: download engine — multi-part (up to 8 parts, HTTP Range), pause/resume (persisted in downloads.json),
  retry with backoff, foreground service + notification, save to Downloads/RDM Pro (MediaStore),
  share-link intake (text/plain), Paste button.  ← current

## Files
- `Engine.kt`  — models, download logic, persistence (core)
- `DownloadService.kt` — foreground service + progress notification
- `MainActivity.kt` — Compose UI
- `RdmApp.kt` — Application (notification channel, Engine.init)

## Next (planned)
- v0.3: in-app browser + media detection, clipboard detection, scheduler, Wi-Fi only, speed limit
- v0.4: torrent, converter, vault, organizer, Bangla UI

## Rules
- Respect site ToS / copyright; no DRM bypass. YouTube-style site downloads are out of scope.
