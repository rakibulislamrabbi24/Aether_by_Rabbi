# RDM Pro — প্রজেক্ট নোট (নতুন চ্যাটে কাজ চালিয়ে যেতে এই ZIP আপলোড করলেই হবে)

Personal-use Android download manager (1DM alternative). Kotlin + Jetpack Compose. minSdk 29, targetSdk 34.
Built in the cloud by GitHub Actions from `project.zip` (no laptop). Same signing key every build (`app/rdm.keystore`).

## Status
- v0.1: Hello app (pipeline test) — done
- v0.2: download engine — multi-part (up to 8 parts, HTTP Range), pause/resume (persisted in downloads.json),
  retry with backoff, foreground service + notification, save to Downloads/RDM Pro (MediaStore),
  share-link intake (text/plain), Paste button. — done, works well on device
- v0.3: Wi-Fi only, global speed limit, download schedule (time window), clipboard link detection,
  Bangla/English UI (Strings.kt), dark/light/system theme, app icon, settings screen. — done

- v0.4: in-app browser (Browser.kt, WebView): detects direct media files (by URL extension in
  shouldInterceptRequest + <video>/<audio> tags via JS), "Media (N)" list -> download with Referer/Cookie/UA;
  WebView DownloadListener hands normal file links to the engine.  ← current

## Files
- `Engine.kt`  — models, download logic, persistence (core)
- `DownloadService.kt` — foreground service + progress notification
- `MainActivity.kt` — Compose UI
- `RdmApp.kt` — Application (notification channel, Settings.init, Engine.init)
- `Settings.kt` — persisted app settings (SharedPreferences)
- `Strings.kt` — all UI text, Bangla + English (add new strings here)
- `Browser.kt` — in-app browser + media detection

## Next (planned)
- v0.5: HLS (.m3u8) downloads — parse playlist, download segments in parallel, join into .ts (AES-128 support)
- v0.6: torrent, converter, vault, organizer

## Rules
- Respect site ToS / copyright; no DRM bypass. YouTube-style site downloads are out of scope.
