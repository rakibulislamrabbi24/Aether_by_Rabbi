# AETHER by RABBI (formerly RDM Pro) — প্রজেক্ট নোট (নতুন চ্যাটে কাজ চালিয়ে যেতে এই ZIP আপলোড করলেই হবে)

Personal-use Android download manager (1DM alternative). Kotlin + Jetpack Compose. minSdk 29, targetSdk 34.
Built in the cloud by GitHub Actions from `project.zip` (no laptop). Same signing key every build (`app/rdm.keystore`).

## Status
- v0.1: Hello app (pipeline test) — done
- v0.2: download engine — multi-part (up to 8 parts, HTTP Range), pause/resume (persisted in downloads.json),
  retry with backoff, foreground service + notification, save to Downloads/RDM Pro (MediaStore),
  share-link intake (text/plain), Paste button. — done, works well on device
- v0.3: Wi-Fi only, global speed limit, download schedule (time window), clipboard link detection,
  Bangla/English UI (Strings.kt), dark/light/system theme, app icon, settings screen. — done

- v0.4: in-app browser (Browser.kt, WebView): detects direct media files (by URL extension in
  shouldInterceptRequest + <video>/<audio> tags via JS), "Media (N)" list -> download with Referer/Cookie/UA;
  WebView DownloadListener hands normal file links to the engine. — done

- v0.5: UI overhaul — icon-based (material-icons-extended), new theme (Theme.kt), home screen with summary card,
  All/Active/Done tabs, FAB + add dialog, file-type icons, details dialog (copy link / remove), pause-all /
  resume-all / clear-completed, redesigned settings + browser. English is the default language
  (pref key `lang_bn`). — done

- (done earlier) HLS (.m3u8) downloads — Engine.runHls: master->variant pick (Settings.hlsQuality), VOD only,
  parallel segments into `<id>_hls/`, AES-128 decrypt (CipherOutputStream), fMP4 (EXT-X-MAP) -> .mp4 else .ts,
  resume at segment level. Not supported: live, SAMPLE-AES/DRM, byte-range, separate audio renditions.
- v0.7: download queue (Settings.maxParallel; Status.WAITING + waitReason "queue"), rename (before/after download,
  MediaStore DISPLAY_NAME update), save location modes (Settings.saveMode), duplicate-link warning,
  finished/failed notifications (channel "done"), search + sort in the list.
  (Review fix: Engine.start() no longer counts the item being started as a running download — new downloads
  used to be queued one slot too early.)

- v0.8: app renamed to **Aether** (applicationId stays `com.rdm.pro` so updates install over old builds); user's own
  crimson script-logo icon (adaptive icon: drawable-nodpi/ic_aether_foreground.png + monochrome, gradient background);
  in-app branding "AETHER by RABBI". Browser upgrade: multiple tabs (max 8, URLs restored), bookmarks, history,
  ad block (AdBlock.kt host list), desktop-site mode, fullscreen video (landscape, activity has configChanges),
  search-engine choice, clear browsing data. Data in BrowserStore.kt.  ← current

## Files
- `Engine.kt`  — models, download logic, persistence (core)
- `DownloadService.kt` — foreground service + progress notification
- `MainActivity.kt` — Compose UI
- `RdmApp.kt` — Application (notification channel, Settings.init, Engine.init)
- `Settings.kt` — persisted app settings (SharedPreferences)
- `Strings.kt` — all UI text, Bangla + English (add new strings here)
- `Browser.kt` — in-app browser (tabs, menu, fullscreen video) + media detection
- `BrowserStore.kt` — bookmarks / history / saved tabs (JSON files)
- `AdBlock.kt` — ad/tracker domain list
- `SettingsScreen.kt` — settings UI
- `Components.kt` — shared UI pieces (FileIcon, SettingRow, ChoiceDialog, ...)
- `Theme.kt` — light/dark color schemes

## Next (planned)
- v0.8: browser upgrade (tabs, bookmarks, history, ad-block, desktop mode, fullscreen video)
- v0.9: media tools (in-app player, converter)
- v1.0: vault (PIN/fingerprint), APK/link warnings
- v1.1: torrent
- Note: `res/drawable/ic_*.xml` (settings, globe, back, ...) are a custom stroke icon set added outside the chat; currently unused (UI uses material-icons-extended).

## Rules
- Respect site ToS / copyright; no DRM bypass. YouTube-style site downloads are out of scope.
