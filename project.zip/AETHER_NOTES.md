# AETHER by RABBI — প্রজেক্ট নোট (নতুন চ্যাটে কাজ চালিয়ে যেতে এই ZIP আপলোড করলেই হবে)

Personal-use Android download manager (1DM alternative). Kotlin + Jetpack Compose. minSdk 29, targetSdk 34.
Built in the cloud by GitHub Actions from `project.zip` (no laptop). Same signing key every build (`app/aether.keystore`, alias `aether`).

## Status
- v0.1: Hello app (pipeline test) — done
- v0.2: download engine — multi-part (up to 8 parts, HTTP Range), pause/resume (persisted in downloads.json),
  retry with backoff, foreground service + notification, save to Downloads/Aether (MediaStore),
  share-link intake (text/plain), Paste button. — done, works well on device
- v0.3: Wi-Fi only, global speed limit, download schedule (time window), clipboard link detection,
  Bangla/English UI (Strings.kt), dark/light/system theme, app icon, settings screen. — done

- v0.4: in-app browser (Browser.kt, WebView): detects direct media files (by URL extension in
  shouldInterceptRequest + <video>/<audio> tags via JS), "Media (N)" list -> download with Referer/Cookie/UA;
  WebView DownloadListener hands normal file links to the engine. — done

- v0.5: UI overhaul — icon-based (material-icons-extended), new theme (Theme.kt), home screen with summary card,
  All/Active/Done tabs, FAB + add dialog, file-type icons, details dialog (copy link / remove), pause-all /
  resume-all / clear-completed, redesigned settings + browser. English is the default language
  (pref key `lang_bn`). — done

- (done earlier) HLS (.m3u8) downloads — Engine.runHls: master->variant pick (Settings.hlsQuality), VOD only,
  parallel segments into `<id>_hls/`, AES-128 decrypt (CipherOutputStream), fMP4 (EXT-X-MAP) -> .mp4 else .ts,
  resume at segment level. Not supported: live, SAMPLE-AES/DRM, byte-range, separate audio renditions.
- v0.7: download queue (Settings.maxParallel; Status.WAITING + waitReason "queue"), rename (before/after download,
  MediaStore DISPLAY_NAME update), save location modes (Settings.saveMode), duplicate-link warning,
  finished/failed notifications (channel "done"), search + sort in the list.
  (Review fix: Engine.start() no longer counts the item being started as a running download — new downloads
  used to be queued one slot too early.)

- v0.8: app renamed to **Aether** (applicationId was `com.rdm.pro` until v0.8.1); user's own
  crimson script-logo icon (adaptive icon: drawable-nodpi/ic_aether_foreground.png + monochrome, gradient background);
  in-app branding "AETHER by RABBI". Browser upgrade: multiple tabs (max 8, URLs restored), bookmarks, history,
  ad block (AdBlock.kt host list), desktop-site mode, fullscreen video (landscape, activity has configChanges),
  search-engine choice, clear browsing data. Data in BrowserStore.kt.

- v0.8.1: **package renamed to `com.rabbi.aether`** (installs as a NEW app, not an update of the old `com.rdm.pro`; new
  signing key `aether.keystore`; sources in `com/rabbi/aether`; class `AetherApp`; theme `Theme.Aether`). Browser: opens
  blank (no Google) with a start page + auto-focus on the address bar; tap selects whole address, clear (X) button;
  "+" new-tab button replaces the X; bottom-bar Home returns to the Aether downloads page; Share in menu.
  Home: "AETHER" top-left + centred logo watermark (drawable-nodpi/ic_aether_logo.png).

- v0.8.2: 1DM-style add-download popup (AddDownload.kt): every new download (+ button, clipboard, share, browser
  media list, browser download links) opens a popup that first peeks at the URL (Engine.peek: name/size/type), then lets
  the user edit the file name, choose the save folder, set Wi-Fi-only for that file, set connections (1/2/4/8/auto)
  and either "Download" or "Add to queue" (added paused). Auto folders by type are now the default
  (Download/Aether/Videos|Music|Images|Documents|Archives|Apps|Others; `FOLDER_CATS`, `Engine.pathFor`).
  New DownloadItem fields: folder, wifiOnly, maxParts.

- v0.9: stream quality + audio-only. HLS master playlists: the popup lists every quality (height/bitrate) via
  Engine.peek -> StreamOption; chosen one is stored in DownloadItem.variantUrl (null = Settings default).
  HLS with a separate audio rendition (EXT-X-MEDIA TYPE=AUDIO) now downloads video + audio tracks and merges them
  into one .mp4 (Mux.merge, MediaExtractor/MediaMuxer, no re-encode) - fixes the old "silent video" limitation.
  "Audio only (M4A)" switch (DownloadItem.audioOnly) for HLS and for normal video files: Mux.extractAudio remuxes just
  the audio track (m4a, or webm for Opus/Vorbis). Not done yet: DASH (.mpd) -> planned v0.9.1.  ← current

## Planned (updated roadmap)
- v0.9.1: DASH (.mpd) support (quality list, separate video+audio tracks merged with Mux).
- v0.9.2: DNS-over-HTTPS + proxy settings. v1.0: site extractors (YouTube etc., NewPipeExtractor, GPL-3.0).
- v1.1: media player + converter. v1.2: vault/security. v1.3: torrent. v1.4: sharing/stats. v1.5: GitHub release prep.

## Files
- `Engine.kt`  — models, download logic, persistence (core)
- `DownloadService.kt` — foreground service + progress notification
- `MainActivity.kt` — Compose UI
- `AetherApp.kt` — Application (notification channel, Settings.init, Engine.init)
- `Settings.kt` — persisted app settings (SharedPreferences)
- `Strings.kt` — all UI text, Bangla + English (add new strings here)
- `Browser.kt` — in-app browser (tabs, menu, fullscreen video) + media detection
- `BrowserStore.kt` — bookmarks / history / saved tabs (JSON files)
- `AdBlock.kt` — ad/tracker domain list
- `SettingsScreen.kt` — settings UI
- `Components.kt` — shared UI pieces (FileIcon, SettingRow, ChoiceDialog, ...)
- `Theme.kt` — light/dark color schemes


## Rules
- Respect site ToS / copyright; no DRM bypass. YouTube-style site downloads are out of scope.
