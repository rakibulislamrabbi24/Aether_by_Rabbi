plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rabbi.aether"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.rabbi.aether"
        minSdk = 29
        targetSdk = 34
        versionCode = 9
        versionName = "0.8.1"
    }

    // একই signing key সব বিল্ডে ব্যবহার হবে, যাতে নতুন ভার্সন পুরনোটার উপর ইনস্টল হয়
    signingConfigs {
        create("aether") {
            storeFile = file("aether.keystore")
            storePassword = "aether123"
            keyAlias = "aether"
            keyPassword = "aether123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("aether")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("aether")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
