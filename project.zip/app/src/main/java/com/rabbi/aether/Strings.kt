package com.rabbi.aether

import androidx.compose.runtime.staticCompositionLocalOf

// অ্যাপের সব লেখা এখানে — ইংরেজি (ডিফল্ট) ও বাংলা দুই ভাষায়
class Strings(private val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e

    // সাধারণ
    val back = t("পেছনে", "Back")
    val close = t("বন্ধ করুন", "Close")
    val cancel = t("বাতিল", "Cancel")
    val dismiss = t("বাদ দিন", "Dismiss")

    // হোম স্ক্রিন
    val addDownload = t("ডাউনলোড যোগ করুন", "Add download")
    val downloadLink = t("ডাউনলোড লিংক", "Download link")
    val paste = t("পেস্ট", "Paste")
    val download = t("ডাউনলোড", "Download")
    val invalidLink = t("সঠিক http/https লিংক দিন", "Enter a valid http/https link")
    val browser = t("ব্রাউজার", "Browser")
    val settings = t("সেটিংস", "Settings")
    val tabAll = t("সব", "All")
    val tabActive = t("চলমান", "Active")
    val tabDone = t("সম্পূর্ণ", "Done")
    val idle = t("নিষ্ক্রিয়", "Idle")
    fun summary(active: Int, waiting: Int, done: Int) =
        t("$active চলছে · $waiting অপেক্ষায় · $done সম্পূর্ণ", "$active active · $waiting waiting · $done done")
    val pauseAll = t("সব থামান", "Pause all")
    val resumeAll = t("সব চালু করুন", "Resume all")
    val clearDone = t("সম্পূর্ণগুলো মুছুন", "Clear completed")
    val emptyTitle = t("এখনও কোনো ডাউনলোড নেই", "No downloads yet")
    val emptySub = t(
        "+ চেপে লিংক যোগ করুন, অথবা ব্রাউজার থেকে লিংক শেয়ার করুন।",
        "Tap + to add a link, or share a link from your browser."
    )
    val emptyFilter = t("এখানে কিছু নেই", "Nothing here")
    val clipFound = t("ক্লিপবোর্ডে লিংক পাওয়া গেছে", "Link found in clipboard")

    // কার্ডের বাটন (আইকনের বর্ণনা)
    val pause = t("থামান", "Pause")
    val resume = t("চালু করুন", "Resume")
    val retry = t("আবার চেষ্টা", "Retry")
    val open = t("খুলুন", "Open")
    val remove = t("মুছুন", "Remove")
    val noAppToOpen = t("এই ফাইল খোলার মতো অ্যাপ পাওয়া যায়নি", "No app found to open this file")

    // বিস্তারিত ডায়ালগ
    val linkLabel = t("লিংক", "Link")
    val sizeLabel = t("সাইজ", "Size")
    val statusLabel = t("অবস্থা", "Status")
    val savedToLabel = t("সেভ হয়েছে", "Saved to")
    val copyLink = t("লিংক কপি", "Copy link")
    val rename = t("নাম বদলান", "Rename")
    val renameTitle = t("ফাইলের নাম বদলান", "Rename file")
    val save = t("সেভ", "Save")
    val fileNameLabel = t("ফাইলের নাম", "File name")
    val fileNameOptional = t("ফাইলের নাম (ঐচ্ছিক)", "File name (optional)")
    val typeLabel = t("ধরন", "Type")
    val typeStream = t("স্ট্রিম (HLS/DASH)", "Stream (HLS/DASH)")
    val typeFile = t("সাধারণ ফাইল", "Regular file")
    val duplicateTitle = t("লিংকটা আগে থেকেই আছে", "Already in your list")
    val duplicateBody = t("এই লিংক ডাউনলোডের তালিকায় আগেই আছে। আবার যোগ করবেন?", "This link is already in your downloads. Add it again?")
    val addAnyway = t("তবুও যোগ করুন", "Add anyway")
    val searchHint = t("ডাউনলোড খুঁজুন", "Search downloads")
    val sortTitle = t("সাজান", "Sort")
    val sortNewest = t("নতুন আগে", "Newest first")
    val sortOldest = t("পুরনো আগে", "Oldest first")
    val sortName = t("নাম (A–Z)", "Name (A–Z)")
    val sortSize = t("সাইজ (বড় আগে)", "Size (largest first)")
    val linkCopied = t("লিংক কপি হয়েছে", "Link copied")

    // স্ট্যাটাস লাইন
    val starting = t("শুরু হচ্ছে…", "Starting…")
    val saving = t("Downloads-এ সেভ হচ্ছে…", "Saving to Downloads…")
    val waitWifi = t("Wi-Fi-এর জন্য অপেক্ষা করছে", "Waiting for Wi-Fi")
    val waitQueue = t("কিউতে অপেক্ষা করছে", "Waiting in queue")
    fun segments(done: Int, total: Int) = t("$done/$total সেগমেন্ট", "$done/$total segments")
    fun failedShort(err: String?) = t("ব্যর্থ: ${err ?: "অজানা সমস্যা"}", "Failed: ${err ?: "unknown error"}")
    fun waitSchedule(time: String) = t("শিডিউলের অপেক্ষায় ($time-এ শুরু হবে)", "Waiting for schedule (starts at $time)")
    fun paused(done: String, total: String) = t("থামানো · $done / $total", "Paused · $done / $total")
    fun completed(total: String) = t("সম্পূর্ণ · $total", "Completed · $total")
    fun failed(err: String?, done: String, total: String) =
        t("ব্যর্থ: ${err ?: "অজানা সমস্যা"} · $done / $total", "Failed: ${err ?: "unknown error"} · $done / $total")
    fun parts(n: Int) = t("$n পার্ট", "$n parts")
    fun eta(x: String) = t("বাকি $x", "ETA $x")

    // নোটিফিকেশন
    fun notifActive(n: Int, speed: String) = t("$n টি চলছে · $speed", "$n active · $speed")
    fun notifWaiting(n: Int) = t("$n টি অপেক্ষায় আছে", "$n waiting")

    // ব্রাউজার
    val addressHint = t("লিংক বা সার্চ লিখুন", "Search or enter link")
    val go = t("যান", "Go")
    val forward = t("সামনে", "Forward")
    val reload = t("রিলোড", "Reload")
    val home = t("হোম", "Home")
    val mediaFound = t("পাওয়া মিডিয়া", "Detected media")
    val mediaButton = t("মিডিয়া", "Media")
    val downloadStarted = t("ডাউনলোড শুরু হয়েছে", "Download started")

    // সেটিংস
    val groupDownloads = t("ডাউনলোড", "Downloads")
    val groupAppearance = t("চেহারা", "Appearance")
    val queueTitle = t("একসাথে ডাউনলোড", "Simultaneous downloads")
    fun queueLabel(n: Int) = t("সর্বোচ্চ $n টি", "Up to $n at a time")
    val saveLocationTitle = t("সেভ করার জায়গা", "Save location")
    fun saveModeLabel(m: Int) = when (m) {
        1 -> t("Downloads/Aether/ধরন অনুযায়ী ফোল্ডার", "Downloads/Aether/<type> folders")
        2 -> "Downloads"
        else -> "Downloads/Aether"
    }
    val streamQualityTitle = t("স্ট্রিমের কোয়ালিটি (HLS)", "Stream quality (HLS)")
    fun qualityLabel(q: Int) = when (q) {
        1 -> t("৭২০p পর্যন্ত", "Up to 720p")
        2 -> t("৪৮০p পর্যন্ত", "Up to 480p")
        3 -> t("সর্বনিম্ন (ডাটা বাঁচায়)", "Lowest (saves data)")
        else -> t("সেরা", "Best")
    }
    val notifyDoneTitle = t("শেষ হলে নোটিফিকেশন", "Notify when finished")
    val notifyDoneSub = t("ডাউনলোড শেষ বা ব্যর্থ হলে আলাদা নোটিফিকেশন আসবে।", "Get a notification when a download finishes or fails.")
    val wifiOnlyTitle = t("শুধু Wi-Fi-তে ডাউনলোড", "Download on Wi-Fi only")
    val wifiOnlySub = t(
        "মোবাইল ডাটায় ডাউনলোড চলবে না। Wi-Fi এলে নিজে থেকে চালু হবে।",
        "No downloads on mobile data. They resume automatically when Wi-Fi is back."
    )
    val speedLimitTitle = t("স্পিড লিমিট", "Speed limit")
    val unlimited = t("সীমাহীন", "Unlimited")
    fun speedLabel(kb: Int) = when {
        kb <= 0 -> unlimited
        kb >= 1024 -> "${kb / 1024} MB/s"
        else -> "$kb KB/s"
    }
    val scheduleTitle = t("ডাউনলোড শিডিউল", "Download schedule")
    val scheduleSub = t(
        "শুধু নির্দিষ্ট সময়ের মধ্যে ডাউনলোড চলবে।",
        "Downloads run only inside this time window."
    )
    val scheduleHint = t(
        "শিডিউল ঠিকমতো চলতে ফোনের সেটিংসে Aether-এর ব্যাটারি অপশন 'No restrictions' রাখুন।",
        "For the schedule to work reliably, set Aether's battery option to 'No restrictions'."
    )
    val startTime = t("শুরু", "Start")
    val endTime = t("শেষ", "End")
    val clipboardTitle = t("ক্লিপবোর্ডের লিংক ধরা", "Detect links in clipboard")
    val clipboardSub = t(
        "লিংক কপি করে অ্যাপ খুললেই ডাউনলোডের অপশন দেখাবে।",
        "Offers to download a link when you copy one and open the app."
    )
    val themeTitle = t("থিম", "Theme")
    val themeSystem = t("সিস্টেম অনুযায়ী", "System default")
    val themeLight = t("লাইট", "Light")
    val themeDark = t("ডার্ক", "Dark")
    fun themeLabel(i: Int) = when (i) {
        1 -> themeLight
        2 -> themeDark
        else -> themeSystem
    }
    val languageTitle = t("ভাষা", "Language")
    val versionLabel = t("সংস্করণ", "Version")
    // ব্র্যান্ডিং
    val appName = "AETHER"
    val byline = "by RABBI"

    // ব্রাউজার (v0.8)
    val newTab = t("নতুন ট্যাব", "New tab")
    val tabsTitle = t("ট্যাব", "Tabs")
    val closeTab = t("ট্যাব বন্ধ করুন", "Close tab")
    val tabLimit = t("সর্বোচ্চ ৮টা ট্যাব খোলা যায়", "You can open up to 8 tabs")
    val menuLabel = t("মেনু", "Menu")
    val desktopSite = t("ডেস্কটপ সাইট", "Desktop site")
    val bookmarksTitle = t("বুকমার্ক", "Bookmarks")
    val historyTitle = t("হিস্ট্রি", "History")
    val addBookmark = t("বুকমার্ক করুন", "Add bookmark")
    val removeBookmark = t("বুকমার্ক সরান", "Remove bookmark")
    val bookmarkAdded = t("বুকমার্ক হয়েছে", "Bookmark added")
    val bookmarkRemoved = t("বুকমার্ক সরানো হয়েছে", "Bookmark removed")
    val noBookmarks = t("এখনও কোনো বুকমার্ক নেই", "No bookmarks yet")
    val noHistory = t("হিস্ট্রি খালি", "History is empty")
    val clearHistory = t("হিস্ট্রি মুছুন", "Clear history")
    val stopLoading = t("লোড থামান", "Stop loading")

    // ব্রাউজার সেটিংস
    val groupBrowser = t("ব্রাউজার", "Browser")
    val adBlockTitle = t("বিজ্ঞাপন ব্লক", "Ad block")
    val adBlockSub = t(
        "পরিচিত বিজ্ঞাপন ও ট্র্যাকার সার্ভার ব্লক করে।",
        "Blocks known ad and tracker servers."
    )
    val searchEngineTitle = t("সার্চ ইঞ্জিন", "Search engine")
    fun engineLabel(i: Int) = when (i) {
        1 -> "DuckDuckGo"
        2 -> "Bing"
        else -> "Google"
    }
    val clearBrowsingTitle = t("ব্রাউজিং ডেটা মুছুন", "Clear browsing data")
    val clearBrowsingSub = t("হিস্ট্রি, কুকি ও সাইটের ডেটা মুছে যাবে।", "Removes history, cookies and site data.")
    val clearBrowsingConfirm = t(
        "হিস্ট্রি, কুকি ও সাইটের সব ডেটা মুছে ফেলবেন? বুকমার্ক থেকে যাবে।",
        "Delete history, cookies and all site data? Bookmarks are kept."
    )
    val clearAction = t("মুছুন", "Clear")
    val share = t("শেয়ার", "Share")
    val clearText = t("লেখা মুছুন", "Clear text")
    val appHome = t("হোম (ডাউনলোড পেজ)", "Home (downloads page)")
    val browsingCleared = t("ব্রাউজিং ডেটা মুছে গেছে", "Browsing data cleared")
    // ডাউনলোড পপআপ (v0.8.2)
    val addPopupTitle = t("ফাইল ডাউনলোড", "Download file")
    val checkingInfo = t("ফাইলের তথ্য দেখা হচ্ছে…", "Checking file…")
    val sizeUnknown = t("সাইজ জানা যায়নি", "Size unknown")
    val streamLabel = t("স্ট্রিম (HLS/DASH)", "Stream (HLS/DASH)")
    fun infoFailed(e: String) = t("ফাইলের তথ্য পড়া যায়নি ($e)। তবুও ডাউনলোড চেষ্টা করা যাবে।", "Couldn't read file info ($e). You can still try downloading.")
    val saveToLabel = t("সেভ হবে", "Save to")
    val autoTag = t("অটো", "auto")
    val saveFolderTitle = t("সেভ ফোল্ডার", "Save folder")
    val folderAuto = t("অটো (ফাইলের ধরন অনুযায়ী)", "Auto (by file type)")
    fun catLabel(dir: String) = when (dir) {
        "Videos" -> t("ভিডিও", "Videos")
        "Music" -> t("মিউজিক", "Music")
        "Images" -> t("ছবি", "Images")
        "Documents" -> t("ডকুমেন্ট", "Documents")
        "Archives" -> t("আর্কাইভ", "Archives")
        "Apps" -> t("অ্যাপ", "Apps")
        else -> t("অন্যান্য", "Others")
    }
    fun kindName(k: FileKind) = when (k) {
        FileKind.VIDEO -> t("ভিডিও", "Video")
        FileKind.AUDIO -> t("অডিও", "Audio")
        FileKind.IMAGE -> t("ছবি", "Image")
        FileKind.DOC -> t("ডকুমেন্ট", "Document")
        FileKind.ARCHIVE -> t("আর্কাইভ", "Archive")
        FileKind.APK -> t("অ্যাপ (APK)", "App (APK)")
        FileKind.OTHER -> t("ফাইল", "File")
    }
    val connectionsLabel = t("কানেকশন সংখ্যা", "Connections")
    fun connLabel(n: Int) = if (n <= 0) t("অটো", "Auto") else "$n"
    val wifiOnlyFile = t("শুধু Wi-Fi-তে (এই ফাইলের জন্য)", "Wi-Fi only (this file)")
    val addToQueue = t("কিউতে রাখুন", "Add to queue")
    val nextStep = t("এগিয়ে যান", "Next")
    val queuedLater = t("কিউতে রাখা হয়েছে, ▶ চাপলে শুরু হবে", "Added to queue — tap ▶ to start")
    // কোয়ালিটি ও শুধু অডিও (v0.9)
    val qualityRowLabel = t("কোয়ালিটি", "Quality")
    val qualityAuto = t("অটো (সেটিংস অনুযায়ী)", "Auto (from Settings)")
    val audioOnlyTitle = t("শুধু অডিও (M4A)", "Audio only (M4A)")
    val audioOnlySub = t("শুধু অডিও ট্র্যাক সেভ হবে, মান কমবে না", "Saves just the audio track, no quality loss")
    // নেটওয়ার্ক: DoH ও প্রক্সি (v0.9.2)
    val groupNetwork = t("নেটওয়ার্ক", "Network")
    val dohTitle = t("DNS over HTTPS", "DNS over HTTPS")
    val dohOff = t("বন্ধ (সিস্টেম DNS)", "Off (system DNS)")
    val dohCustomLabel = t("নিজের DoH ঠিকানা", "Custom DoH address")
    fun dohLabel(i: Int) = when (i) {
        1 -> "Cloudflare (1.1.1.1)"
        2 -> "Google (8.8.8.8)"
        3 -> "Quad9 (9.9.9.9)"
        4 -> dohCustomLabel
        else -> dohOff
    }
    val dohUrlHint = t("DoH ঠিকানা (https://…)", "DoH address (https://…)")
    val saveLabel = t("সেভ", "Save")
    val proxyTitle = t("প্রক্সি", "Proxy")
    val proxyOff = t("বন্ধ", "Off")
    fun proxySummary(type: Int, host: String, port: Int) =
        if (type == 0 || host.isBlank()) proxyOff else (if (type == 2) "SOCKS5 " else "HTTP ") + host + ":" + port
    val proxyHostHint = t("হোস্ট (যেমন 192.168.1.5)", "Host (e.g. 192.168.1.5)")
    val proxyPortHint = t("পোর্ট", "Port")
    val proxyUserHint = t("ইউজারনেম (ঐচ্ছিক)", "Username (optional)")
    val proxyPassHint = t("পাসওয়ার্ড", "Password")
    val proxyInvalid = t("সঠিক হোস্ট ও পোর্ট (১–৬৫৫৩৫) দিন", "Enter a valid host and port (1–65535)")
    val proxyNote = t(
        "প্রক্সি ডাউনলোড ও ইন-অ্যাপ ব্রাউজার দুটোতেই চলে। প্রক্সি চালু থাকলে DoH ব্যবহার হয় না, কারণ নাম প্রক্সিই খুঁজে নেয়। SOCKS5-এ ইউজারনেম ও পাসওয়ার্ড সাপোর্ট নেই।",
        "The proxy is used by downloads and the in-app browser. DoH is not used while a proxy is on (the proxy resolves names). Username and password are not supported for SOCKS5."
    )
    val networkNote = t(
        "DoH শুধু ডাউনলোডে কাজ করে। ব্রাউজারে DNS ব্লক এড়াতে ফোনের Settings → Network → Private DNS-এ dns.google বা one.one.one.one বসান, অথবা প্রক্সি ব্যবহার করুন।",
        "DoH works for downloads only. For the browser, set your phone's Settings → Network → Private DNS to dns.google or one.one.one.one, or use a proxy."
    )
    val testTitle = t("কানেকশন টেস্ট", "Test connection")
    val testSub = t("কোনো সাইট এখনকার সেটিংসে খোলে কিনা দেখুন", "Check whether a site opens with the current settings")
    val testUrlHint = t("পরীক্ষার ঠিকানা", "Address to test")
    val testRun = t("টেস্ট", "Test")
    fun testOk(code: Int, ms: Long) = t("পৌঁছানো গেছে (HTTP $code) · $ms ms", "Reachable (HTTP $code) · $ms ms")
    fun testFail(e: String?) = t("পৌঁছানো যায়নি: ${e ?: "অজানা সমস্যা"}", "Couldn't connect: ${e ?: "unknown error"}")
}

val LocalStr = staticCompositionLocalOf { Strings(false) }
