package com.rabbi.aether

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class AetherApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                DownloadService.CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
        )
        nm.createNotificationChannel(
            NotificationChannel(
                DownloadService.DONE_CHANNEL_ID,
                "Finished downloads",
                NotificationManager.IMPORTANCE_DEFAULT
            )
        )
        Settings.init(this)
        BrowserStore.init(this)
        Engine.init(this)
    }
}
