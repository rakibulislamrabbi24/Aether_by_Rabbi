package com.rabbi.aether

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.UUID

// ব্রাউজারে পাওয়া একটা মিডিয়া ফাইল
data class MediaHit(val url: String, val referer: String, val label: String)

// একটা ট্যাবের সব অবস্থা। প্রতিটা ট্যাবের নিজস্ব WebView আর নিজস্ব মিডিয়া তালিকা আছে
class BTab {
    val id: String = UUID.randomUUID().toString()
    var url by mutableStateOf("")
    var title by mutableStateOf("")
    var progress by mutableStateOf(100)
    var desktop by mutableStateOf(false)
    var rev by mutableStateOf(0) // WebView মুছে গেলে এটা বাড়ে, তখন আবার বানানো হয়
    val found = mutableStateListOf<MediaHit>()
    var web: WebView? = null
    @Volatile var page: String = ""
}

// WebView থেকে স্ক্রিনকে জানানোর কলব্যাক
private class BrowserCb(
    val showCustom: (View, WebChromeClient.CustomViewCallback) -> Unit,
    val hideCustom: () -> Unit,
    val toast: (String) -> Unit,
    val request: (DownloadRequest) -> Unit
)

private const val MAX_TABS = 8

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

private val mainHandler = Handler(Looper.getMainLooper())

private val mediaExt = setOf(
    "mp4", "m4v", "webm", "mkv", "mov", "avi", "flv", "3gp", "m3u8",
    "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac"
)

// লিংকের শেষে মিডিয়া এক্সটেনশন থাকলে সেটা মিডিয়া ধরা হবে
private fun looksLikeMedia(url: String): Boolean {
    if (!url.startsWith("http://") && !url.startsWith("https://")) return false
    val path = url.substringBefore('?').substringBefore('#').lowercase()
    return path.substringAfterLast('.', "") in mediaExt
}

private fun labelOf(url: String): String {
    val seg = Uri.parse(url).lastPathSegment ?: return url
    return runCatching { URLDecoder.decode(seg, "UTF-8") }.getOrDefault(seg)
}

private fun normalizeInput(text: String, engine: Int): String {
    val x = text.trim()
    if (x.startsWith("http://") || x.startsWith("https://")) return x
    if (!x.contains(' ') && x.contains('.')) return "https://$x"
    val base = when (engine) {
        1 -> "https://duckduckgo.com/?q="
        2 -> "https://www.bing.com/search?q="
        else -> "https://www.google.com/search?q="
    }
    return base + URLEncoder.encode(x, "UTF-8")
}

// পেজের <video>/<audio> ট্যাগ থেকে লিংক বের করার জাভাস্ক্রিপ্ট
private const val DETECT_JS =
    "(function(){var r=[];" +
        "document.querySelectorAll('video,audio').forEach(function(v){" +
        "if(v.currentSrc)r.push(v.currentSrc);if(v.src)r.push(v.src);" +
        "v.querySelectorAll('source').forEach(function(x){if(x.src)r.push(x.src)})});" +
        "return JSON.stringify(r);})()"

// ডিফল্ট UA থেকে "; wv" বাদ দেওয়া হয়, নইলে অনেক সাইট একে অ্যাপের ভেতরের ওয়েবভিউ ভেবে সীমিত করে
private fun mobileUa(c: Context): String = WebSettings.getDefaultUserAgent(c).replace("; wv", "")

private fun applyUa(w: WebView, tab: BTab) {
    w.settings.userAgentString = if (tab.desktop) DESKTOP_UA else mobileUa(w.context)
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

private fun addHit(tab: BTab, url: String, referer: String) {
    if (tab.found.size >= 60) return
    if (tab.found.none { it.url == url }) tab.found.add(MediaHit(url, referer, labelOf(url)))
}

// পেজের ভেতরের <video>/<audio> ট্যাগ থেকে লিংক বের করে (blob: লিংক বাদ)
private fun detectInPage(view: WebView, onHit: (String) -> Unit) {
    view.evaluateJavascript(DETECT_JS) { res ->
        try {
            val text = JSONTokener(res).nextValue() as? String
            if (text != null) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.startsWith("http://") || u.startsWith("https://")) onHit(u)
                }
            }
        } catch (e: Exception) {
            // পেজ থেকে পড়া না গেলে কিছু করার নেই
        }
    }
}

// একটা ট্যাবের জন্য নতুন WebView বানানো
@SuppressLint("SetJavaScriptEnabled")
private fun createWebView(c: Context, tab: BTab, s: Strings, cb: BrowserCb): WebView {
    val w = WebView(c)
    val st = w.settings
    st.javaScriptEnabled = true
    st.domStorageEnabled = true
    st.useWideViewPort = true
    st.loadWithOverviewMode = true
    st.setSupportZoom(true)
    st.builtInZoomControls = true
    st.displayZoomControls = false
    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
    applyUa(w, tab)

    w.webChromeClient = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            tab.progress = newProgress
        }

        // পেজের শিরোনাম রাখা হয়: ট্যাব তালিকা, বুকমার্ক, হিস্ট্রি আর স্ট্রিম (.m3u8) ফাইলের নামে কাজে লাগে
        override fun onReceivedTitle(view: WebView?, title: String?) {
            tab.title = title ?: ""
        }

        // ভিডিও ফুলস্ক্রিনে নেওয়া
        override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
            if (view != null && callback != null) cb.showCustom(view, callback) else callback?.onCustomViewHidden()
        }

        override fun onHideCustomView() {
            cb.hideCustom()
        }
    }

    w.webViewClient = object : WebViewClient() {
        // http/https ছাড়া অন্য লিংক (intent://, market:// ইত্যাদি) ব্লক। অ্যাড ব্লক চালু থাকলে নিজে নিজে
        // (ট্যাপ ছাড়া) অ্যাড সার্ভারে চলে যাওয়া রিডাইরেক্টও আটকানো হয়
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val req = request ?: return false
            val scheme = req.url.scheme ?: return false
            if (scheme != "http" && scheme != "https") return true
            if (Settings.state.value.adBlock && req.isForMainFrame && !req.hasGesture() &&
                AdBlock.isBlocked(req.url.host)
            ) return true
            return false
        }

        // পেজের প্রতিটা রিকোয়েস্ট এখানে আসে (ব্যাকগ্রাউন্ড থ্রেডে): অ্যাড ব্লক করা আর মিডিয়া ফাইল ধরা
        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
            val req = request ?: return null
            if (!req.isForMainFrame && Settings.state.value.adBlock && AdBlock.isBlocked(req.url.host)) {
                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            val u = req.url.toString()
            if (looksLikeMedia(u)) {
                val ref = req.requestHeaders?.get("Referer") ?: tab.page
                mainHandler.post { addHit(tab, u, ref) }
            }
            return null
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
            super.onPageStarted(view, url, favicon)
            if (url != null) {
                tab.page = url
                tab.url = url
            }
            tab.found.clear()
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            val v = view ?: return
            if (url != null) BrowserStore.addHistory(v.title ?: tab.title, url)
            // পেজ শেষ হওয়ার পর এবং একটু পরে আবার <video> ট্যাগ খুঁজে দেখা
            val task = Runnable {
                if (tab.web === v) detectInPage(v) { hit -> addHit(tab, hit, tab.page) }
            }
            task.run()
            v.postDelayed(task, 2500)
            v.postDelayed(task, 6000)
        }

        // ব্রাউজারের রেন্ডারার ক্র্যাশ করলে অ্যাপ বন্ধ না হয়ে ট্যাবটা আবার লোড হবে
        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            if (view != null) {
                (view.parent as? ViewGroup)?.removeView(view)
                view.destroy()
            }
            tab.web = null
            tab.rev = tab.rev + 1
            return true
        }
    }

    // সাধারণ ডাউনলোড লিংকে (zip, apk, pdf ইত্যাদি) ট্যাপ করলে সরাসরি Aether-এর ডাউনলোডে যাবে
    // সাধারণ ডাউনলোড লিংকে ট্যাপ করলে ডাউনলোড পপআপ খুলবে (নাম, ফোল্ডার ইত্যাদি বেছে নেওয়া যাবে)
    w.setDownloadListener { url, userAgent, _, _, _ ->
        val cookie = CookieManager.getInstance().getCookie(url)
        cb.request(DownloadRequest(url, referer = tab.page, cookie = cookie, userAgent = userAgent))
    }
    return w
}

// ---------------------------------------------------------------------------
// ব্রাউজার স্ক্রিন
// ---------------------------------------------------------------------------

@Composable
fun BrowserScreen(onClose: () -> Unit, onRequest: (DownloadRequest) -> Unit) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    val st by Settings.state.collectAsState()

    // আগের বার যে ট্যাবগুলো খোলা ছিল সেগুলো ফিরিয়ে আনা (শুধু লিংক, পেজের ভেতরের অবস্থা নয়)
    val tabs = remember {
        val l = mutableStateListOf<BTab>()
        val saved = BrowserStore.savedTabs()
        if (saved.isEmpty()) l.add(BTab()) else saved.forEach { u -> l.add(BTab().also { t -> t.url = u }) }
        l
    }
    var current by remember { mutableStateOf(BrowserStore.savedCurrent().coerceIn(0, tabs.size - 1)) }
    var showTabs by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showMedia by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }
    var libraryTab by remember { mutableStateOf(0) }
    var addrValue by remember { mutableStateOf(TextFieldValue("")) }
    var addrFocused by remember { mutableStateOf(false) }
    val addrInteraction = remember { MutableInteractionSource() }
    val addrFocus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    var customView by remember { mutableStateOf<View?>(null) }
    var customCb by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    val tab = tabs.getOrNull(current) ?: tabs.first()

    val cb = remember {
        BrowserCb(
            showCustom = { v, c ->
                customView = v
                customCb = c
            },
            hideCustom = {
                customView?.let { (it.parent as? ViewGroup)?.removeView(it) }
                customView = null
                customCb = null
            },
            toast = { m -> Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show() },
            request = onRequest
        )
    }

    fun go() {
        if (addrValue.text.isBlank()) return
        val u = normalizeInput(addrValue.text, st.searchEngine)
        val w = tab.web
        if (w != null) w.loadUrl(u) else tab.url = u
        focusManager.clearFocus()
    }

    fun newTab() {
        if (tabs.size >= MAX_TABS) {
            cb.toast(s.tabLimit)
            return
        }
        tabs.add(BTab())
        current = tabs.size - 1
    }

    fun closeTab(i: Int) {
        val t = tabs[i]
        val w = t.web
        if (w != null) {
            (w.parent as? ViewGroup)?.removeView(w)
            w.destroy()
        }
        t.web = null
        tabs.removeAt(i)
        if (tabs.isEmpty()) {
            tabs.add(BTab())
            current = 0
        } else if (current >= tabs.size) {
            current = tabs.size - 1
        } else if (i < current) {
            current -= 1
        }
    }

    fun downloadHit(hit: MediaHit) {
        val cookie = CookieManager.getInstance().getCookie(hit.url)
        val ua = tab.web?.settings?.userAgentString
        val isStream = hit.url.substringBefore('?').lowercase().endsWith(".m3u8")
        val name = if (isStream && tab.title.isNotBlank()) tab.title else null
        cb.request(DownloadRequest(hit.url, referer = hit.referer, cookie = cookie, userAgent = ua, suggestedName = name))
    }

    // ঠিকানা বারে বর্তমান ট্যাবের লিংক দেখানো
    LaunchedEffect(current, tab.url) { addrValue = TextFieldValue(tab.url) }

    // ঠিকানা বারে ট্যাপ করলে (একবার বা দুইবার) পুরো লিংক সিলেক্ট হয়ে যাবে
    LaunchedEffect(addrInteraction) {
        addrInteraction.interactions.collect { i ->
            if (i is PressInteraction.Release) {
                delay(60)
                addrValue = addrValue.copy(selection = TextRange(0, addrValue.text.length))
            }
        }
    }

    // ফাঁকা ট্যাব খুললে কার্সর নিজে থেকে ঠিকানা বারে চলে যায় (সাথে কিবোর্ড), তাই সরাসরি সার্চ করা যায়
    LaunchedEffect(tab.id, tab.url.isBlank()) {
        if (tab.url.isBlank()) {
            delay(250)
            try {
                addrFocus.requestFocus()
            } catch (e: Exception) {
                // ফোকাস দেওয়া না গেলে কিছু করার নেই
            }
        }
    }

    // খোলা ট্যাবের তালিকা সেভ রাখা
    val urlsKey = tabs.joinToString("|") { it.url }
    LaunchedEffect(urlsKey, current) { BrowserStore.saveTabs(tabs.map { it.url }, current) }

    BackHandler {
        when {
            customView != null -> {
                customCb?.onCustomViewHidden()
                cb.hideCustom()
            }
            showLibrary -> showLibrary = false
            else -> {
                val w = tab.web
                if (w != null && w.canGoBack()) w.goBack() else onClose()
            }
        }
    }

    // স্ক্রিন ছেড়ে গেলে ট্যাব সেভ করে সব WebView বন্ধ
    DisposableEffect(Unit) {
        onDispose {
            BrowserStore.saveTabs(tabs.map { it.url }, current)
            for (t in tabs) {
                val w = t.web
                if (w != null) {
                    (w.parent as? ViewGroup)?.removeView(w)
                    w.destroy()
                }
                t.web = null
            }
        }
    }

    // ভিডিও ফুলস্ক্রিনে গেলে ল্যান্ডস্কেপ ও ইমারসিভ মোড, বের হলে আগের অবস্থা
    val activity = ctx.findActivity()
    DisposableEffect(customView != null) {
        if (customView != null && activity != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (activity != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    val bookmarked = tab.url.isNotBlank() && BrowserStore.bookmarks.any { it.url == tab.url }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // ঠিকানা বার
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { newTab() }) { Icon(Icons.Rounded.Add, contentDescription = s.newTab) }
                OutlinedTextField(
                    value = addrValue,
                    onValueChange = { addrValue = it },
                    interactionSource = addrInteraction,
                    placeholder = { Text(s.addressHint) },
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    trailingIcon = {
                        if (addrFocused && addrValue.text.isNotEmpty()) {
                            // কোণার ক্রস: পুরো লিংক এক চাপে মুছে দেয়
                            IconButton(onClick = { addrValue = TextFieldValue("") }) {
                                Icon(Icons.Rounded.Close, contentDescription = s.clearText)
                            }
                        } else if (tab.url.isNotBlank()) {
                            IconButton(onClick = {
                                if (bookmarked) {
                                    BrowserStore.removeBookmark(tab.url)
                                    cb.toast(s.bookmarkRemoved)
                                } else {
                                    BrowserStore.addBookmark(tab.title.ifBlank { tab.url }, tab.url)
                                    cb.toast(s.bookmarkAdded)
                                }
                            }) {
                                Icon(
                                    if (bookmarked) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                    contentDescription = if (bookmarked) s.removeBookmark else s.addBookmark,
                                    tint = if (bookmarked) cs.primary else LocalContentColor.current
                                )
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { go() }),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(addrFocus)
                        .onFocusChanged {
                            addrFocused = it.isFocused
                            if (it.isFocused) addrValue = addrValue.copy(selection = TextRange(0, addrValue.text.length))
                        }
                )
                IconButton(onClick = {
                    if (tab.progress < 100) tab.web?.stopLoading() else tab.web?.reload()
                }) {
                    Icon(
                        if (tab.progress < 100) Icons.Rounded.Close else Icons.Rounded.Refresh,
                        contentDescription = if (tab.progress < 100) s.stopLoading else s.reload
                    )
                }
            }
            if (tab.progress < 100) {
                LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
            }

            // ওয়েব পেজ: বর্তমান ট্যাবের WebView এই ফ্রেমে বসে। ট্যাব ফাঁকা থাকলে উপরে স্টার্ট পেজ দেখায়
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { c -> FrameLayout(c) },
                update = { frame ->
                    val t = tabs.getOrNull(current)
                    if (t != null) {
                        val revision = t.rev // এই মান পড়ার কারণেই WebView মুছে গেলে আবার বানানো হয়
                        var w = t.web
                        if (w == null) {
                            w = createWebView(frame.context, t, s, cb)
                            t.web = w
                            if (t.url.isNotBlank()) w.loadUrl(t.url)
                        }
                        if (frame.childCount != 1 || frame.getChildAt(0) !== w) {
                            (frame.getChildAt(0) as? WebView)?.onPause()
                            frame.removeAllViews()
                            (w.parent as? ViewGroup)?.removeView(w)
                            frame.addView(
                                w,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                            w.onResume()
                        }
                        if (revision < 0) frame.requestLayout()
                    }
                }
            )
            if (tab.url.isBlank()) {
                BrowserStartPage(onOpen = { u ->
                    val w = tab.web
                    if (w != null) w.loadUrl(u) else tab.url = u
                })
            }
            }

            // নিচের বার: ব্যাক, ফরওয়ার্ড, অ্যাপ হোম, ট্যাব, মিডিয়া, মেনু
            Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    IconButton(onClick = { tab.web?.let { if (it.canGoBack()) it.goBack() } }) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = s.back)
                    }
                    IconButton(onClick = { tab.web?.let { if (it.canGoForward()) it.goForward() } }) {
                        Icon(Icons.Rounded.ArrowForward, contentDescription = s.forward)
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Rounded.Home, contentDescription = s.appHome)
                    }
                    // ট্যাব বাটন: খোলা ট্যাবের সংখ্যা দেখায়
                    IconButton(onClick = { showTabs = true }) {
                        Box(
                            modifier = Modifier.size(24.dp).border(2.dp, LocalContentColor.current, RoundedCornerShape(7.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("${tabs.size}", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    // মিডিয়া বাটন: পাওয়া ফাইলের সংখ্যা ব্যাজে দেখায়
                    Box {
                        IconButton(onClick = { showMedia = true }, enabled = tab.found.isNotEmpty()) {
                            Icon(Icons.Rounded.Movie, contentDescription = s.mediaButton)
                        }
                        if (tab.found.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(top = 4.dp, end = 4.dp)
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(cs.primary),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    "${tab.found.size}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = cs.onPrimary
                                )
                            }
                        }
                    }
                    // মেনু
                    Box {
                        IconButton(onClick = { showMenu = true }) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = s.menuLabel)
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(s.desktopSite) },
                                leadingIcon = { Icon(Icons.Rounded.DesktopWindows, contentDescription = null) },
                                trailingIcon = { if (tab.desktop) Icon(Icons.Rounded.Check, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    tab.desktop = !tab.desktop
                                    tab.web?.let {
                                        applyUa(it, tab)
                                        it.reload()
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.adBlockTitle) },
                                leadingIcon = { Icon(Icons.Rounded.Block, contentDescription = null) },
                                trailingIcon = { if (st.adBlock) Icon(Icons.Rounded.Check, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    Settings.update { it.copy(adBlock = !it.adBlock) }
                                    tab.web?.reload()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.bookmarksTitle) },
                                leadingIcon = { Icon(Icons.Rounded.Star, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    libraryTab = 0
                                    showLibrary = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.historyTitle) },
                                leadingIcon = { Icon(Icons.Rounded.History, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    libraryTab = 1
                                    showLibrary = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.copyLink) },
                                leadingIcon = { Icon(Icons.Rounded.ContentCopy, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    if (tab.url.isNotBlank()) {
                                        clipboard.setText(AnnotatedString(tab.url))
                                        cb.toast(s.linkCopied)
                                    }
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(s.share) },
                                leadingIcon = { Icon(Icons.Rounded.Share, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    if (tab.url.isNotBlank()) {
                                        val send = Intent(Intent.ACTION_SEND)
                                            .setType("text/plain")
                                            .putExtra(Intent.EXTRA_SUBJECT, tab.title)
                                            .putExtra(Intent.EXTRA_TEXT, tab.url)
                                        ctx.startActivity(Intent.createChooser(send, null))
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        // বুকমার্ক ও হিস্ট্রি (পুরো স্ক্রিন জুড়ে)
        if (showLibrary) {
            BrowserLibrary(
                initialTab = libraryTab,
                onOpen = { u ->
                    tab.web?.loadUrl(u)
                    showLibrary = false
                },
                onBack = { showLibrary = false }
            )
        }

        // ফুলস্ক্রিন ভিডিও
        val cv = customView
        if (cv != null) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { c ->
                        FrameLayout(c).apply {
                            (cv.parent as? ViewGroup)?.removeView(cv)
                            addView(
                                cv,
                                FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            )
                        }
                    }
                )
            }
        }
    }

    // ট্যাব তালিকা
    if (showTabs) {
        AlertDialog(
            onDismissRequest = { showTabs = false },
            title = { Text(s.tabsTitle) },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    itemsIndexed(tabs, key = { _, t -> t.id }) { i, t ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (i == current) cs.primaryContainer else Color.Transparent)
                                .clickable {
                                    current = i
                                    showTabs = false
                                }
                                .padding(start = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f).padding(vertical = 8.dp)) {
                                Text(
                                    t.title.ifBlank { if (t.url.isBlank()) s.newTab else t.url },
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    if (t.url.isBlank()) "" else (Uri.parse(t.url).host ?: t.url),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { closeTab(i) }) {
                                Icon(Icons.Rounded.Close, contentDescription = s.closeTab)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    newTab()
                    showTabs = false
                }) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(s.newTab)
                }
            },
            dismissButton = { TextButton(onClick = { showTabs = false }) { Text(s.close) } }
        )
    }

    // পাওয়া মিডিয়ার তালিকা
    if (showMedia) {
        AlertDialog(
            onDismissRequest = { showMedia = false },
            title = { Text(s.mediaFound) },
            confirmButton = { TextButton(onClick = { showMedia = false }) { Text(s.close) } },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(tab.found.toList(), key = { it.url }) { hit ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FileIcon(
                                kind = kindOf(hit.label),
                                container = cs.primaryContainer,
                                content = cs.onPrimaryContainer
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    hit.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    Uri.parse(hit.url).host ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = {
                                downloadHit(hit)
                                showMedia = false
                            }) { Icon(Icons.Rounded.Download, contentDescription = s.download) }
                        }
                    }
                }
            }
        )
    }
}

// ---------------------------------------------------------------------------
// বুকমার্ক ও হিস্ট্রি
// ---------------------------------------------------------------------------

@Composable
private fun BrowserLibrary(initialTab: Int, onOpen: (String) -> Unit, onBack: () -> Unit) {
    val s = LocalStr.current
    val cs = MaterialTheme.colorScheme
    var tab by remember { mutableStateOf(initialTab) }
    BackHandler(onBack = onBack)

    Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = s.back) }
                Text(
                    if (tab == 0) s.bookmarksTitle else s.historyTitle,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.weight(1f)
                )
                if (tab == 1 && BrowserStore.history.isNotEmpty()) {
                    IconButton(onClick = { BrowserStore.clearHistory() }) {
                        Icon(Icons.Rounded.DeleteSweep, contentDescription = s.clearHistory)
                    }
                }
            }
            TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(s.bookmarksTitle) })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(s.historyTitle) })
            }
            if (tab == 0) {
                if (BrowserStore.bookmarks.isEmpty()) {
                    LibraryEmpty(s.noBookmarks)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(BrowserStore.bookmarks.toList(), key = { it.url }) { b ->
                            LibraryRow(
                                icon = Icons.Rounded.Star,
                                title = b.title,
                                url = b.url,
                                onClick = { onOpen(b.url) },
                                onDelete = { BrowserStore.removeBookmark(b.url) }
                            )
                        }
                    }
                }
            } else {
                if (BrowserStore.history.isEmpty()) {
                    LibraryEmpty(s.noHistory)
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(BrowserStore.history.toList()) { h ->
                            LibraryRow(
                                icon = Icons.Rounded.History,
                                title = h.title,
                                url = h.url,
                                onClick = { onOpen(h.url) },
                                onDelete = null
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryEmpty(text: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LibraryRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    url: String,
    onClick: () -> Unit,
    onDelete: (() -> Unit)?
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = cs.primary)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                url,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Close, contentDescription = null) }
        } else {
            Spacer(Modifier.width(12.dp))
        }
    }
}

// ফাঁকা ট্যাবের স্টার্ট পেজ: হালকা লোগো আর বুকমার্কের শর্টকাট
@Composable
private fun BrowserStartPage(onOpen: (String) -> Unit) {
    val s = LocalStr.current
    val cs = MaterialTheme.colorScheme
    Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(R.drawable.ic_aether_logo),
                    contentDescription = null,
                    alpha = 0.12f,
                    modifier = Modifier.fillMaxWidth(0.75f)
                )
                Spacer(Modifier.height(12.dp))
                Text(s.addressHint, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
            }
            if (BrowserStore.bookmarks.isNotEmpty()) {
                LazyRow(
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 16.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(BrowserStore.bookmarks.take(10), key = { it.url }) { b ->
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(cs.surfaceVariant.copy(alpha = 0.6f))
                                .clickable { onOpen(b.url) }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Star, contentDescription = null, tint = cs.primary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                b.title,
                                style = MaterialTheme.typography.labelLarge,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.widthIn(max = 140.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
