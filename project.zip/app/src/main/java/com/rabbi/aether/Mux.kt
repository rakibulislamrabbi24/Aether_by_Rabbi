package com.rabbi.aether

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

// ডাউনলোড হওয়া ট্র্যাক জোড়া লাগানো বা শুধু অডিও আলাদা করা। পুনরায় এনকোড করা হয় না,
// তাই কাজটা দ্রুত হয় আর ভিডিও-অডিওর মান একটুও কমে না।
object Mux {
    private const val BUF_SIZE = 4 * 1024 * 1024

    // ফাইলে প্রথম যে ট্র্যাকের টাইপ prefix দিয়ে শুরু ("video/" বা "audio/"), তার ইনডেক্স; না থাকলে -1
    private fun trackOf(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    private fun open(f: File): MediaExtractor {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.absolutePath)
        } catch (e: Exception) {
            ex.release()
            throw IOException("Cannot read the downloaded media (" + (e.message ?: "unknown error") + ")")
        }
        return ex
    }

    private fun flagsOf(ex: MediaExtractor): Int =
        if (ex.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0

    // ভিডিও ফাইলের ভিডিও ট্র্যাক আর অডিও ফাইলের অডিও ট্র্যাক এক MP4 ফাইলে জোড়া লাগানো
    fun merge(video: File, audio: File, out: File) {
        val ve = open(video)
        val ae = try {
            open(audio)
        } catch (e: IOException) {
            ve.release()
            throw e
        }
        var muxer: MediaMuxer? = null
        try {
            val vi = trackOf(ve, "video/")
            val ai = trackOf(ae, "audio/")
            if (vi < 0) throw IOException("No video track found in the downloaded stream")
            if (ai < 0) throw IOException("No audio track found in the downloaded stream")
            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val videoOut = m.addTrack(ve.getTrackFormat(vi))
            val audioOut = m.addTrack(ae.getTrackFormat(ai))
            ve.selectTrack(vi)
            ae.selectTrack(ai)
            m.start()

            val buf = ByteBuffer.allocate(BUF_SIZE)
            val info = MediaCodec.BufferInfo()
            // দুই ট্র্যাকের নমুনা সময় অনুযায়ী মিশিয়ে লেখা হয়, যাতে প্লেয়ারে সিক করা সহজ হয়
            while (true) {
                val vt = ve.sampleTime
                val at = ae.sampleTime
                if (vt < 0 && at < 0) break
                val useVideo = vt >= 0 && (at < 0 || vt <= at)
                val ex = if (useVideo) ve else ae
                val track = if (useVideo) videoOut else audioOut
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) {
                    ex.advance()
                    continue
                }
                info.set(0, size, ex.sampleTime, flagsOf(ex))
                m.writeSampleData(track, buf, info)
                ex.advance()
            }
            m.stop()
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("Could not merge video and audio (" + (e.message ?: "unsupported format") + ")")
        } finally {
            try {
                muxer?.release()
            } catch (e: Exception) {
                // রিলিজ করতে না পারলে কিছু করার নেই
            }
            ve.release()
            ae.release()
        }
    }

    // যেকোনো ভিডিও/অডিও ফাইল থেকে শুধু অডিও ট্র্যাক আলাদা করে out-এ লেখে।
    // ফেরত দেয় ফাইলের এক্সটেনশন: সাধারণত "m4a", Opus/Vorbis অডিও হলে "webm"
    fun extractAudio(src: File, out: File): String {
        val ex = open(src)
        var muxer: MediaMuxer? = null
        try {
            val ai = trackOf(ex, "audio/")
            if (ai < 0) throw IOException("This file has no audio track")
            val format = ex.getTrackFormat(ai)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            val webm = mime == "audio/opus" || mime == "audio/vorbis"
            val container = if (webm) MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            val m = MediaMuxer(out.absolutePath, container)
            muxer = m
            val track = m.addTrack(format)
            ex.selectTrack(ai)
            m.start()

            val buf = ByteBuffer.allocate(BUF_SIZE)
            val info = MediaCodec.BufferInfo()
            while (true) {
                if (ex.sampleTime < 0) break
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                info.set(0, size, ex.sampleTime, flagsOf(ex))
                m.writeSampleData(track, buf, info)
                ex.advance()
            }
            m.stop()
            return if (webm) "webm" else "m4a"
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException("Could not extract audio (" + (e.message ?: "unsupported audio format") + ")")
        } finally {
            try {
                muxer?.release()
            } catch (e: Exception) {
                // রিলিজ করতে না পারলে কিছু করার নেই
            }
            ex.release()
        }
    }
}
