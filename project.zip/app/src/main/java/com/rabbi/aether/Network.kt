package com.rabbi.aether

import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import okhttp3.Authenticator
import okhttp3.Credentials
import okhttp3.Dns
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route
import okhttp3.dnsoverhttps.DnsOverHttps
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.Executor
import java.util.concurrent.TimeUnit

// কানেকশনের সেটিংস: প্রক্সি (HTTP/SOCKS5) আর DNS over HTTPS।
// ডাউনলোড ইঞ্জিনের HTTP ক্লায়েন্টে এগুলো বসে, আর ব্রাউজারে প্রক্সিটা বসে WebView-এর ProxyController দিয়ে।
object Net {

    fun proxyActive(s: AppSettings): Boolean =
        s.proxyType != 0 && s.proxyHost.isNotBlank() && s.proxyPort in 1..65535

    // সেটিংসের নেটওয়ার্ক অংশ বদলালে এই লেখাটা বদলায়, তখন ক্লায়েন্ট নতুন করে বানানো হয়
    fun signature(s: AppSettings): String =
        listOf(s.dohProvider, s.dohCustom, s.proxyType, s.proxyHost, s.proxyPort, s.proxyUser, s.proxyPass)
            .joinToString("|")

    fun configure(b: OkHttpClient.Builder, s: AppSettings): OkHttpClient.Builder {
        if (proxyActive(s)) {
            val type = if (s.proxyType == 2) Proxy.Type.SOCKS else Proxy.Type.HTTP
            // হোস্টের নাম প্রক্সিই খুঁজে নেয় (DNS লিক হয় না), তাই এখানে অমীমাংসিত ঠিকানা দেওয়া হয়
            b.proxy(Proxy(type, InetSocketAddress.createUnresolved(s.proxyHost.trim(), s.proxyPort)))
            if (s.proxyType == 1 && s.proxyUser.isNotBlank()) {
                val user = s.proxyUser
                val pass = s.proxyPass
                b.proxyAuthenticator(object : Authenticator {
                    override fun authenticate(route: Route?, response: Response): Request? {
                        // একবার পাঠিয়ে ব্যর্থ হলে আর চেষ্টা করা হয় না
                        if (response.request.header("Proxy-Authorization") != null) return null
                        return response.request.newBuilder()
                            .header("Proxy-Authorization", Credentials.basic(user, pass))
                            .build()
                    }
                })
            }
        } else {
            val dns = dohDns(s)
            if (dns != null) b.dns(dns)
        }
        return b
    }

    // DoH বন্ধ থাকলে বা ঠিকানা ভুল হলে null (তখন সিস্টেম DNS)
    private fun dohDns(s: AppSettings): Dns? {
        val url: String
        val bootstrap: List<String>
        when (s.dohProvider) {
            1 -> {
                url = "https://cloudflare-dns.com/dns-query"
                bootstrap = listOf("1.1.1.1", "1.0.0.1")
            }
            2 -> {
                url = "https://dns.google/dns-query"
                bootstrap = listOf("8.8.8.8", "8.8.4.4")
            }
            3 -> {
                url = "https://dns.quad9.net/dns-query"
                bootstrap = listOf("9.9.9.9", "149.112.112.112")
            }
            4 -> {
                url = s.dohCustom.trim()
                bootstrap = emptyList()
            }
            else -> return null
        }
        val httpUrl = url.toHttpUrlOrNull() ?: return null
        if (httpUrl.scheme != "https") return null
        val boot = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .build()
        val builder = DnsOverHttps.Builder().client(boot).url(httpUrl)
        // DoH সার্ভারের নিজের নাম খুঁজতে সিস্টেম DNS লাগে না, তাই আগে থেকে দেওয়া IP ব্যবহার হয়
        if (bootstrap.isNotEmpty()) builder.bootstrapDnsHosts(bootstrap.map { InetAddress.getByName(it) })
        val doh = builder.build()
        return object : Dns {
            override fun lookup(hostname: String): List<InetAddress> {
                return try {
                    doh.lookup(hostname)
                } catch (e: Exception) {
                    // DoH সার্ভারে পৌঁছানো না গেলে সিস্টেম DNS-এ ফিরে যাওয়া, যাতে ডাউনলোড পুরোপুরি বন্ধ না হয়
                    Dns.SYSTEM.lookup(hostname)
                }
            }
        }
    }

    // ব্রাউজারের (WebView) জন্য প্রক্সি বসানো বা তুলে নেওয়া। ব্রাউজার খোলার সময় আর প্রক্সি সেটিংস বদলালে ডাকা হয়
    fun applyWebProxy() {
        val s = Settings.state.value
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return
            val controller = ProxyController.getInstance()
            val direct = Executor { r -> r.run() }
            if (proxyActive(s)) {
                val scheme = if (s.proxyType == 2) "socks5" else "http"
                val config = ProxyConfig.Builder()
                    .addProxyRule(scheme + "://" + s.proxyHost.trim() + ":" + s.proxyPort)
                    .build()
                controller.setProxyOverride(config, direct, Runnable { })
            } else {
                controller.clearProxyOverride(direct, Runnable { })
            }
        } catch (e: Exception) {
            // এই ফোনের ওয়েবভিউ প্রক্সি সাপোর্ট না করলে ব্রাউজার আগের মতোই চলবে
        }
    }
}
