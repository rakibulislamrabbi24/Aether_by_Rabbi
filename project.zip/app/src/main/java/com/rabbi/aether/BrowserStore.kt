package com.rabbi.aether

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebStorage
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class BookmarkItem(val title: String, val url: String)
data class HistoryItem(val title: String, val url: String, val time: Long)

// ব্রাউজারের বুকমার্ক, হিস্ট্রি আর খোলা ট্যাবের তালিকা ফোনে সেভ রাখে (JSON ফাইলে)
object BrowserStore {
    private const val MAX_HISTORY = 300

    private lateinit var dir: File
    val bookmarks = mutableStateListOf<BookmarkItem>()
    val history = mutableStateListOf<HistoryItem>()
    private var tabUrls: List<String> = emptyList()
    private var tabCurrent = 0

    fun init(ctx: Context) {
        dir = ctx.applicationContext.filesDir
        try {
            val arr = readArray("bookmarks.json")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    bookmarks.add(BookmarkItem(o.optString("t"), o.getString("u")))
                }
            }
        } catch (e: Exception) {
            // ফাইল নষ্ট থাকলে খালি তালিকা নিয়েই শুরু
        }
        try {
            val arr = readArray("history.json")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    history.add(HistoryItem(o.optString("t"), o.getString("u"), o.optLong("ts")))
                }
            }
        } catch (e: Exception) {
        }
        try {
            val f = File(dir, "tabs.json")
            if (f.exists()) {
                val o = JSONObject(f.readText())
                val arr = o.optJSONArray("urls")
                if (arr != null) tabUrls = List(arr.length()) { arr.optString(it) }
                tabCurrent = o.optInt("cur", 0)
            }
        } catch (e: Exception) {
        }
    }

    // ---------- ট্যাব ----------

    fun savedTabs(): List<String> = tabUrls

    fun savedCurrent(): Int = tabCurrent

    fun saveTabs(urls: List<String>, current: Int) {
        tabUrls = urls
        tabCurrent = current
        try {
            val o = JSONObject()
            o.put("urls", JSONArray(urls))
            o.put("cur", current)
            File(dir, "tabs.json").writeText(o.toString())
        } catch (e: Exception) {
        }
    }

    // ---------- বুকমার্ক ----------

    fun isBookmarked(url: String): Boolean = bookmarks.any { it.url == url }

    fun addBookmark(title: String, url: String) {
        if (url.isBlank() || isBookmarked(url)) return
        bookmarks.add(0, BookmarkItem(title.ifBlank { url }, url))
        saveBookmarks()
    }

    fun removeBookmark(url: String) {
        bookmarks.removeAll { it.url == url }
        saveBookmarks()
    }

    private fun saveBookmarks() {
        try {
            val arr = JSONArray()
            for (b in bookmarks) arr.put(JSONObject().put("t", b.title).put("u", b.url))
            File(dir, "bookmarks.json").writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    // ---------- হিস্ট্রি ----------

    fun addHistory(title: String, url: String) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return
        val first = history.firstOrNull()
        if (first != null && first.url == url) {
            // একই পেজ আবার লোড হলে শুধু শিরোনাম ও সময় নতুন করা
            history[0] = HistoryItem(title.ifBlank { first.title }, url, System.currentTimeMillis())
        } else {
            history.add(0, HistoryItem(title.ifBlank { url }, url, System.currentTimeMillis()))
            while (history.size > MAX_HISTORY) history.removeAt(history.size - 1)
        }
        saveHistory()
    }

    fun clearHistory() {
        history.clear()
        saveHistory()
    }

    private fun saveHistory() {
        try {
            val arr = JSONArray()
            for (h in history) arr.put(JSONObject().put("t", h.title).put("u", h.url).put("ts", h.time))
            File(dir, "history.json").writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    // হিস্ট্রি, কুকি ও সাইটের ডেটা মোছা (বুকমার্ক থেকে যায়)
    fun clearBrowsingData() {
        clearHistory()
        try {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
        } catch (e: Exception) {
        }
    }

    private fun readArray(name: String): JSONArray? {
        val f = File(dir, name)
        return if (f.exists()) JSONArray(f.readText()) else null
    }
}
