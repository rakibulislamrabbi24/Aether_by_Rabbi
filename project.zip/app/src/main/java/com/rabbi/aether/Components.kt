package com.rabbi.aether

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Android
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

const val APP_VERSION = "0.8.1"

enum class FileKind { VIDEO, AUDIO, IMAGE, ARCHIVE, DOC, APK, OTHER }

// ফাইলের এক্সটেনশন দেখে ধরন বোঝা (আইকনের জন্য)
fun kindOf(name: String): FileKind {
    return when (name.substringAfterLast('.', "").lowercase()) {
        "mp4", "mkv", "webm", "mov", "avi", "flv", "3gp", "m4v", "ts", "m3u8" -> FileKind.VIDEO
        "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac" -> FileKind.AUDIO
        "jpg", "jpeg", "png", "gif", "webp", "bmp", "svg" -> FileKind.IMAGE
        "zip", "rar", "7z", "tar", "gz", "bz2", "xz" -> FileKind.ARCHIVE
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "epub" -> FileKind.DOC
        "apk", "xapk", "apks" -> FileKind.APK
        else -> FileKind.OTHER
    }
}

fun iconFor(kind: FileKind): ImageVector = when (kind) {
    FileKind.VIDEO -> Icons.Rounded.Movie
    FileKind.AUDIO -> Icons.Rounded.MusicNote
    FileKind.IMAGE -> Icons.Rounded.Image
    FileKind.ARCHIVE -> Icons.Rounded.Folder
    FileKind.DOC -> Icons.Rounded.Description
    FileKind.APK -> Icons.Rounded.Android
    FileKind.OTHER -> Icons.Rounded.InsertDriveFile
}

// ফাইলের ধরন অনুযায়ী আইকন, গোল-কোণা চৌকো ব্যাকগ্রাউন্ডে
@Composable
fun FileIcon(kind: FileKind, container: Color, content: Color) {
    Box(
        modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp)).background(container),
        contentAlignment = Alignment.Center
    ) {
        Icon(iconFor(kind), contentDescription = null, tint = content)
    }
}

// গোল ব্যাকগ্রাউন্ডওয়ালা আইকন বাটন
@Composable
fun TonalIconButton(icon: ImageVector, description: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        modifier = Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = cs.onPrimaryContainer)
    }
}

// সেটিংসের গ্রুপ কার্ড
@Composable
fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
    ) {
        Column(content = content)
    }
}

@Composable
fun GroupTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 28.dp, top = 20.dp, bottom = 8.dp)
    )
}

// সেটিংসের একটা সারি: বাঁয়ে আইকন, মাঝে লেখা, ডানে সুইচ বা অন্য কিছু
@Composable
fun SettingRow(
    icon: ImageVector,
    title: String,
    subtitle: String?,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    val base = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    Row(
        modifier = base.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(CircleShape).background(cs.primaryContainer),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = cs.onPrimaryContainer)
        }
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (subtitle != null) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

// একাধিক অপশন থেকে একটা বাছাই করার ডায়ালগ
@Composable
fun <T> ChoiceDialog(
    title: String,
    options: List<Pair<T, String>>,
    selected: T,
    cancelText: String,
    onSelect: (T) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onSelect(value)
                                onDismiss()
                            }
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = value == selected,
                            onClick = {
                                onSelect(value)
                                onDismiss()
                            }
                        )
                        Text(label)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text(cancelText) } }
    )
}
