package com.rabbi.aether

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.util.Locale

// নতুন ডাউনলোডের অনুরোধ: লিংক আর (ব্রাউজার থেকে এলে) সাইটের শর্তের তথ্য
data class DownloadRequest(
    val url: String,
    val referer: String? = null,
    val cookie: String? = null,
    val userAgent: String? = null,
    val suggestedName: String? = null
)

// ডাউনলোড শুরুর আগে দেখানো পপআপ (1DM-এর মতো): নাম, সাইজ ও ধরন, সেভ ফোল্ডার, Wi-Fi শর্ত, কানেকশন সংখ্যা
@Composable
fun AddDownloadDialog(req: DownloadRequest, onDismiss: () -> Unit) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme

    var peek by remember(req) { mutableStateOf<Engine.PeekResult?>(null) }
    var name by remember(req) { mutableStateOf(req.suggestedName ?: "") }
    var nameEdited by remember(req) { mutableStateOf(false) }
    var folder by remember(req) { mutableStateOf<String?>(null) }
    var wifiOnly by remember(req) { mutableStateOf(false) }
    var parts by remember(req) { mutableStateOf(0) }
    var variant by remember(req) { mutableStateOf<String?>(null) }   // বাছা কোয়ালিটির প্লেলিস্ট; null = অটো
    var audioOnly by remember(req) { mutableStateOf(false) }
    // 0 = কোনো ডায়ালগ নেই, 1 = ফোল্ডার, 2 = কানেকশন, 3 = কোয়ালিটি
    var sub by remember { mutableStateOf(0) }

    // ফাইলের তথ্য নিয়ে আসা (নেটওয়ার্কে একটা ছোট রিকোয়েস্ট)
    LaunchedEffect(req) {
        val r = Engine.peek(req.url, req.referer, req.cookie, req.userAgent, req.suggestedName)
        peek = r
        if (!nameEdited) name = r.name
    }

    val p = peek
    val err = p?.error
    val hasStream = p?.hls == true
    val kindOfName = kindOf(name)
    val canAudioOnly = hasStream || kindOfName == FileKind.VIDEO || (p?.mime ?: "").startsWith("video/")
    val qualityList = p?.options ?: emptyList()
    val selectedQuality = qualityList.firstOrNull { it.url == variant }
    // শুধু অডিও চালু থাকলে ফাইল M4A হিসেবে সেভ হবে, তাই আইকন, ধরন ও ফোল্ডার সেই হিসাবে দেখানো হয়
    val effName = if (audioOnly) name.substringBeforeLast('.', name).ifBlank { "audio" } + ".m4a" else name
    val kind = kindOf(effName)

    fun setAudioOnly(on: Boolean) {
        audioOnly = on
        if (!nameEdited) {
            val orig = peek?.name
            name = if (on) name.substringBeforeLast('.', name).ifBlank { "audio" } + ".m4a" else (orig ?: name)
        }
    }
    val host = Uri.parse(req.url).host ?: req.url
    val duplicate = Engine.exists(req.url)
    val sizeText = when {
        p == null -> s.checkingInfo
        p.hls -> s.streamLabel
        p.total > 0 -> fmtBytes(p.total)
        else -> s.sizeUnknown
    }
    val resolved = Engine.pathFor(effName.ifBlank { "file" }, folder)
    val pathText = if (folder == null) "$resolved · ${s.autoTag}" else resolved

    fun submit(startNow: Boolean) {
        val ok = Engine.add(
            req.url,
            referer = req.referer,
            cookie = req.cookie,
            userAgent = req.userAgent,
            name = name.trim().ifBlank { null },
            folder = folder,
            wifiOnly = wifiOnly,
            maxParts = parts,
            startNow = startNow,
            variantUrl = if (audioOnly) null else variant,
            audioOnly = audioOnly
        )
        if (ok) {
            if (!startNow) Toast.makeText(ctx, s.queuedLater, Toast.LENGTH_SHORT).show()
            onDismiss()
        } else {
            Toast.makeText(ctx, s.invalidLink, Toast.LENGTH_SHORT).show()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(s.addPopupTitle) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // ধরনের আইকন, ধরন ও সাইজ
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FileIcon(kind = kind, container = cs.primaryContainer, content = cs.onPrimaryContainer)
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            s.kindName(kind) + " · " + sizeText,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            host,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (p == null) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    }
                }

                // নাম এডিট
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameEdited = true
                    },
                    label = { Text(s.fileNameLabel) },
                    maxLines = 3,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                if (duplicate) {
                    Text(s.duplicateBody, style = MaterialTheme.typography.bodySmall, color = cs.error)
                }
                if (err != null) {
                    Text(s.infoFailed(err), style = MaterialTheme.typography.bodySmall, color = cs.error)
                }

                // কোয়ালিটি: স্ট্রিমে একাধিক কোয়ালিটি থাকলে বাছাই করা যায়
                if (qualityList.isNotEmpty() && !audioOnly) {
                    OptionRow(
                        icon = Icons.Rounded.HighQuality,
                        title = s.qualityRowLabel,
                        value = if (selectedQuality != null) qualityText(selectedQuality) else s.qualityAuto,
                        onClick = { sub = 3 }
                    )
                }
                // শুধু অডিও: ভিডিও ফাইল বা স্ট্রিম হলে
                if (canAudioOnly) {
                    OptionRow(
                        icon = Icons.Rounded.MusicNote,
                        title = s.audioOnlyTitle,
                        value = s.audioOnlySub,
                        onClick = { setAudioOnly(!audioOnly) },
                        trailing = { Switch(checked = audioOnly, onCheckedChange = { setAudioOnly(it) }) }
                    )
                }
                // সেভ ফোল্ডার
                OptionRow(
                    icon = Icons.Rounded.Folder,
                    title = s.saveToLabel,
                    value = pathText,
                    onClick = { sub = 1 }
                )
                // কানেকশন সংখ্যা (HLS স্ট্রিমে সেগমেন্ট আলাদা নিয়মে নামে, তাই দেখানো হয় না)
                if (p?.hls != true) {
                    OptionRow(
                        icon = Icons.Rounded.Speed,
                        title = s.connectionsLabel,
                        value = s.connLabel(parts),
                        onClick = { sub = 2 }
                    )
                }
                // শুধু এই ফাইলের জন্য Wi-Fi শর্ত
                OptionRow(
                    icon = Icons.Rounded.Wifi,
                    title = s.wifiOnlyFile,
                    value = null,
                    onClick = { wifiOnly = !wifiOnly },
                    trailing = { Switch(checked = wifiOnly, onCheckedChange = { wifiOnly = it }) }
                )
            }
        },
        confirmButton = {
            Button(onClick = { submit(true) }) {
                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(s.download)
            }
        },
        dismissButton = {
            Row {
                TextButton(onClick = onDismiss) { Text(s.cancel) }
                TextButton(onClick = { submit(false) }) { Text(s.addToQueue) }
            }
        }
    )

    when (sub) {
        1 -> ChoiceDialog<String?>(
            title = s.saveFolderTitle,
            options = listOf<Pair<String?, String>>(null to s.folderAuto) + FOLDER_CATS.map { it to s.catLabel(it) },
            selected = folder,
            cancelText = s.cancel,
            onSelect = { v -> folder = v },
            onDismiss = { sub = 0 }
        )
        3 -> ChoiceDialog<String?>(
            title = s.qualityRowLabel,
            options = listOf<Pair<String?, String>>(null to s.qualityAuto) + qualityList.map { it.url to qualityText(it) },
            selected = variant,
            cancelText = s.cancel,
            onSelect = { v -> variant = v },
            onDismiss = { sub = 0 }
        )
        2 -> ChoiceDialog(
            title = s.connectionsLabel,
            options = listOf(0, 1, 2, 4, 8).map { it to s.connLabel(it) },
            selected = parts,
            cancelText = s.cancel,
            onSelect = { v -> parts = v },
            onDismiss = { sub = 0 }
        )
    }
}

// পপআপের ভেতরের ছোট সারি: আইকন, শিরোনাম, মান (বা ডানে সুইচ)
@Composable
private fun OptionRow(
    icon: ImageVector,
    title: String,
    value: String?,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    val cs = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = cs.primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
            if (value != null) {
                Text(value, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        if (trailing != null) {
            Spacer(Modifier.width(8.dp))
            trailing()
        }
    }
}

// কোয়ালিটির লেখা: "1080p · 4.2 Mbps"
private fun qualityText(o: StreamOption): String {
    val bits = ArrayList<String>()
    if (o.height > 0) bits.add("${o.height}p")
    if (o.bandwidth > 0) bits.add(String.format(Locale.US, "%.1f Mbps", o.bandwidth / 1_000_000.0))
    return if (bits.isEmpty()) "Stream" else bits.joinToString(" · ")
}
