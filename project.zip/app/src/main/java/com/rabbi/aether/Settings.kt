package com.rabbi.aether

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class AppSettings(
    val wifiOnly: Boolean = false,
    val speedLimitKb: Int = 0,        // 0 = সীমাহীন (KB/s)
    val scheduleEnabled: Boolean = false,
    val scheduleStartMin: Int = 120,  // 02:00
    val scheduleEndMin: Int = 420,    // 07:00
    val clipboardWatch: Boolean = true,
    val theme: Int = 0,               // 0 = সিস্টেম, 1 = লাইট, 2 = ডার্ক
    val bangla: Boolean = false,      // ডিফল্ট English
    val maxParallel: Int = 3,         // একসাথে সর্বোচ্চ কয়টা ডাউনলোড চলবে
    val notifyDone: Boolean = true,   // ডাউনলোড শেষে নোটিফিকেশন
    val saveMode: Int = 1,            // 0 = Downloads/Aether, 1 = ধরন অনুযায়ী সাব-ফোল্ডার, 2 = শুধু Downloads
    val hlsQuality: Int = 0,           // 0 = সেরা, 1 = 720p পর্যন্ত, 2 = 480p পর্যন্ত, 3 = সর্বনিম্ন
    val adBlock: Boolean = true,      // ব্রাউজারে বিজ্ঞাপন ব্লক
    val searchEngine: Int = 0,         // 0 = Google, 1 = DuckDuckGo, 2 = Bing
    val dohProvider: Int = 0,         // 0 = বন্ধ, 1 = Cloudflare, 2 = Google, 3 = Quad9, 4 = নিজের ঠিকানা
    val dohCustom: String = "",
    val proxyType: Int = 0,           // 0 = বন্ধ, 1 = HTTP, 2 = SOCKS5
    val proxyHost: String = "",
    val proxyPort: Int = 0,
    val proxyUser: String = "",
    val proxyPass: String = ""
)

object Settings {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("aether_settings", Context.MODE_PRIVATE)
        // v0.8.2: ফাইলের ধরন অনুযায়ী আলাদা ফোল্ডার এখন ডিফল্ট (একবারই বসানো হয়, পরে নিজে বদলালে বদলানোই থাকবে)
        if (!prefs.getBoolean("autoFolders082", false)) {
            prefs.edit().putInt("saveMode", 1).putBoolean("autoFolders082", true).apply()
        }
        val d = AppSettings()
        _state.value = AppSettings(
            wifiOnly = prefs.getBoolean("wifiOnly", d.wifiOnly),
            speedLimitKb = prefs.getInt("speedLimitKb", d.speedLimitKb),
            scheduleEnabled = prefs.getBoolean("scheduleEnabled", d.scheduleEnabled),
            scheduleStartMin = prefs.getInt("scheduleStartMin", d.scheduleStartMin),
            scheduleEndMin = prefs.getInt("scheduleEndMin", d.scheduleEndMin),
            clipboardWatch = prefs.getBoolean("clipboardWatch", d.clipboardWatch),
            theme = prefs.getInt("theme", d.theme),
            bangla = prefs.getBoolean("lang_bn", d.bangla),
            maxParallel = prefs.getInt("maxParallel", d.maxParallel),
            notifyDone = prefs.getBoolean("notifyDone", d.notifyDone),
            saveMode = prefs.getInt("saveMode", d.saveMode),
            hlsQuality = prefs.getInt("hlsQuality", d.hlsQuality),
            adBlock = prefs.getBoolean("adBlock", d.adBlock),
            searchEngine = prefs.getInt("searchEngine", d.searchEngine),
            dohProvider = prefs.getInt("dohProvider", d.dohProvider),
            dohCustom = prefs.getString("dohCustom", d.dohCustom) ?: d.dohCustom,
            proxyType = prefs.getInt("proxyType", d.proxyType),
            proxyHost = prefs.getString("proxyHost", d.proxyHost) ?: d.proxyHost,
            proxyPort = prefs.getInt("proxyPort", d.proxyPort),
            proxyUser = prefs.getString("proxyUser", d.proxyUser) ?: d.proxyUser,
            proxyPass = prefs.getString("proxyPass", d.proxyPass) ?: d.proxyPass
        )
    }

    fun update(f: (AppSettings) -> AppSettings) {
        val n = f(_state.value)
        _state.value = n
        prefs.edit()
            .putBoolean("wifiOnly", n.wifiOnly)
            .putInt("speedLimitKb", n.speedLimitKb)
            .putBoolean("scheduleEnabled", n.scheduleEnabled)
            .putInt("scheduleStartMin", n.scheduleStartMin)
            .putInt("scheduleEndMin", n.scheduleEndMin)
            .putBoolean("clipboardWatch", n.clipboardWatch)
            .putInt("theme", n.theme)
            .putBoolean("lang_bn", n.bangla)
            .putInt("maxParallel", n.maxParallel)
            .putBoolean("notifyDone", n.notifyDone)
            .putInt("saveMode", n.saveMode)
            .putInt("hlsQuality", n.hlsQuality)
            .putBoolean("adBlock", n.adBlock)
            .putInt("searchEngine", n.searchEngine)
            .putInt("dohProvider", n.dohProvider)
            .putString("dohCustom", n.dohCustom)
            .putInt("proxyType", n.proxyType)
            .putString("proxyHost", n.proxyHost)
            .putInt("proxyPort", n.proxyPort)
            .putString("proxyUser", n.proxyUser)
            .putString("proxyPass", n.proxyPass)
            .apply()
        Engine.onSettingsChanged()
    }
}
