package com.rdm.pro

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.widget.Toast

@Composable
fun SettingsScreen(st: AppSettings, onBack: () -> Unit) {
    val s = LocalStr.current
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    // 0 = কোনো ডায়ালগ নেই, 1 = স্পিড লিমিট, 2 = থিম, 3 = ভাষা, 4 = একসাথে ডাউনলোড, 5 = সেভ জায়গা, 6 = স্ট্রিম কোয়ালিটি
    var dialog by remember { mutableStateOf(0) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 16.dp, top = 12.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, contentDescription = s.back) }
            Text(s.settings, style = MaterialTheme.typography.titleLarge)
        }

        GroupTitle(s.groupDownloads)
        SettingsCard {
            SettingRow(
                icon = Icons.Rounded.Wifi,
                title = s.wifiOnlyTitle,
                subtitle = s.wifiOnlySub,
                onClick = { Settings.update { it.copy(wifiOnly = !it.wifiOnly) } },
                trailing = {
                    Switch(checked = st.wifiOnly, onCheckedChange = { v -> Settings.update { it.copy(wifiOnly = v) } })
                }
            )
            SettingRow(
                icon = Icons.Rounded.Speed,
                title = s.speedLimitTitle,
                subtitle = s.speedLabel(st.speedLimitKb),
                onClick = { dialog = 1 }
            )
            SettingRow(
                icon = Icons.Rounded.Layers,
                title = s.queueTitle,
                subtitle = s.queueLabel(st.maxParallel),
                onClick = { dialog = 4 }
            )
            SettingRow(
                icon = Icons.Rounded.Folder,
                title = s.saveLocationTitle,
                subtitle = s.saveModeLabel(st.saveMode),
                onClick = { dialog = 5 }
            )
            SettingRow(
                icon = Icons.Rounded.HighQuality,
                title = s.streamQualityTitle,
                subtitle = s.qualityLabel(st.hlsQuality),
                onClick = { dialog = 6 }
            )
            SettingRow(
                icon = Icons.Rounded.Schedule,
                title = s.scheduleTitle,
                subtitle = s.scheduleSub,
                onClick = { Settings.update { it.copy(scheduleEnabled = !it.scheduleEnabled) } },
                trailing = {
                    Switch(
                        checked = st.scheduleEnabled,
                        onCheckedChange = { v -> Settings.update { it.copy(scheduleEnabled = v) } }
                    )
                }
            )
            if (st.scheduleEnabled) {
                TimeRow(s.startTime, st.scheduleStartMin) { m -> Settings.update { it.copy(scheduleStartMin = m) } }
                TimeRow(s.endTime, st.scheduleEndMin) { m -> Settings.update { it.copy(scheduleEndMin = m) } }
                Text(
                    s.scheduleHint,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    modifier = Modifier.padding(start = 70.dp, end = 16.dp, top = 2.dp, bottom = 12.dp)
                )
            }
            SettingRow(
                icon = Icons.Rounded.Notifications,
                title = s.notifyDoneTitle,
                subtitle = s.notifyDoneSub,
                onClick = { Settings.update { it.copy(notifyDone = !it.notifyDone) } },
                trailing = {
                    Switch(
                        checked = st.notifyDone,
                        onCheckedChange = { v -> Settings.update { it.copy(notifyDone = v) } }
                    )
                }
            )
            SettingRow(
                icon = Icons.Rounded.ContentPaste,
                title = s.clipboardTitle,
                subtitle = s.clipboardSub,
                onClick = { Settings.update { it.copy(clipboardWatch = !it.clipboardWatch) } },
                trailing = {
                    Switch(
                        checked = st.clipboardWatch,
                        onCheckedChange = { v -> Settings.update { it.copy(clipboardWatch = v) } }
                    )
                }
            )
        }

        GroupTitle(s.groupBrowser)
        SettingsCard {
            SettingRow(
                icon = Icons.Rounded.Block,
                title = s.adBlockTitle,
                subtitle = s.adBlockSub,
                onClick = { Settings.update { it.copy(adBlock = !it.adBlock) } },
                trailing = {
                    Switch(checked = st.adBlock, onCheckedChange = { v -> Settings.update { it.copy(adBlock = v) } })
                }
            )
            SettingRow(
                icon = Icons.Rounded.Search,
                title = s.searchEngineTitle,
                subtitle = s.engineLabel(st.searchEngine),
                onClick = { dialog = 7 }
            )
            SettingRow(
                icon = Icons.Rounded.DeleteSweep,
                title = s.clearBrowsingTitle,
                subtitle = s.clearBrowsingSub,
                onClick = { dialog = 8 }
            )
        }

        GroupTitle(s.groupAppearance)
        SettingsCard {
            SettingRow(
                icon = Icons.Rounded.Palette,
                title = s.themeTitle,
                subtitle = s.themeLabel(st.theme),
                onClick = { dialog = 2 }
            )
            SettingRow(
                icon = Icons.Rounded.Language,
                title = s.languageTitle,
                subtitle = if (st.bangla) "বাংলা" else "English",
                onClick = { dialog = 3 }
            )
        }

        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                s.appName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp,
                color = cs.primary
            )
            Text(
                s.byline,
                style = MaterialTheme.typography.labelMedium,
                letterSpacing = 3.sp,
                color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(6.dp))
            Text(
                s.versionLabel + " " + APP_VERSION,
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant
            )
        }
    }

    when (dialog) {
        1 -> ChoiceDialog(
            title = s.speedLimitTitle,
            options = listOf(
                0 to s.unlimited,
                256 to "256 KB/s",
                512 to "512 KB/s",
                1024 to "1 MB/s",
                2048 to "2 MB/s",
                5120 to "5 MB/s"
            ),
            selected = st.speedLimitKb,
            cancelText = s.cancel,
            onSelect = { kb -> Settings.update { it.copy(speedLimitKb = kb) } },
            onDismiss = { dialog = 0 }
        )
        2 -> ChoiceDialog(
            title = s.themeTitle,
            options = listOf(0 to s.themeSystem, 1 to s.themeLight, 2 to s.themeDark),
            selected = st.theme,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(theme = v) } },
            onDismiss = { dialog = 0 }
        )
        4 -> ChoiceDialog(
            title = s.queueTitle,
            options = listOf(1, 2, 3, 4, 5).map { it to s.queueLabel(it) },
            selected = st.maxParallel,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(maxParallel = v) } },
            onDismiss = { dialog = 0 }
        )
        5 -> ChoiceDialog(
            title = s.saveLocationTitle,
            options = listOf(0, 1, 2).map { it to s.saveModeLabel(it) },
            selected = st.saveMode,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(saveMode = v) } },
            onDismiss = { dialog = 0 }
        )
        6 -> ChoiceDialog(
            title = s.streamQualityTitle,
            options = listOf(0, 1, 2, 3).map { it to s.qualityLabel(it) },
            selected = st.hlsQuality,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(hlsQuality = v) } },
            onDismiss = { dialog = 0 }
        )
        7 -> ChoiceDialog(
            title = s.searchEngineTitle,
            options = listOf(0, 1, 2).map { it to s.engineLabel(it) },
            selected = st.searchEngine,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(searchEngine = v) } },
            onDismiss = { dialog = 0 }
        )
        8 -> AlertDialog(
            onDismissRequest = { dialog = 0 },
            title = { Text(s.clearBrowsingTitle) },
            text = { Text(s.clearBrowsingConfirm) },
            confirmButton = {
                TextButton(onClick = {
                    BrowserStore.clearBrowsingData()
                    Toast.makeText(ctx, s.browsingCleared, Toast.LENGTH_SHORT).show()
                    dialog = 0
                }) { Text(s.clearAction, color = cs.error) }
            },
            dismissButton = { TextButton(onClick = { dialog = 0 }) { Text(s.cancel) } }
        )
        3 -> ChoiceDialog(
            title = s.languageTitle,
            options = listOf(false to "English", true to "বাংলা"),
            selected = st.bangla,
            cancelText = s.cancel,
            onSelect = { v -> Settings.update { it.copy(bangla = v) } },
            onDismiss = { dialog = 0 }
        )
    }
}

// শিডিউলের সময় বদলানোর সারি: − সময় +  (৩০ মিনিট করে)
@Composable
fun TimeRow(label: String, minutes: Int, onChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 70.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        IconButton(onClick = { onChange((minutes - 30 + 1440) % 1440) }) {
            Icon(Icons.Rounded.Remove, contentDescription = null)
        }
        Text(
            fmtTime(minutes),
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.widthIn(min = 56.dp)
        )
        IconButton(onClick = { onChange((minutes + 30) % 1440) }) {
            Icon(Icons.Rounded.Add, contentDescription = null)
        }
    }
}
