package com.rdm.pro

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class AppSettings(
    val wifiOnly: Boolean = false,
    val speedLimitKb: Int = 0,        // 0 = সীমাহীন (KB/s)
    val scheduleEnabled: Boolean = false,
    val scheduleStartMin: Int = 120,  // 02:00
    val scheduleEndMin: Int = 420,    // 07:00
    val clipboardWatch: Boolean = true,
    val theme: Int = 0,               // 0 = সিস্টেম, 1 = লাইট, 2 = ডার্ক
    val bangla: Boolean = true
)

object Settings {
    private lateinit var prefs: SharedPreferences
    private val _state = MutableStateFlow(AppSettings())
    val state: StateFlow<AppSettings> = _state

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences("rdm_settings", Context.MODE_PRIVATE)
        val d = AppSettings()
        _state.value = AppSettings(
            wifiOnly = prefs.getBoolean("wifiOnly", d.wifiOnly),
            speedLimitKb = prefs.getInt("speedLimitKb", d.speedLimitKb),
            scheduleEnabled = prefs.getBoolean("scheduleEnabled", d.scheduleEnabled),
            scheduleStartMin = prefs.getInt("scheduleStartMin", d.scheduleStartMin),
            scheduleEndMin = prefs.getInt("scheduleEndMin", d.scheduleEndMin),
            clipboardWatch = prefs.getBoolean("clipboardWatch", d.clipboardWatch),
            theme = prefs.getInt("theme", d.theme),
            bangla = prefs.getBoolean("bangla", d.bangla)
        )
    }

    fun update(f: (AppSettings) -> AppSettings) {
        val n = f(_state.value)
        _state.value = n
        prefs.edit()
            .putBoolean("wifiOnly", n.wifiOnly)
            .putInt("speedLimitKb", n.speedLimitKb)
            .putBoolean("scheduleEnabled", n.scheduleEnabled)
            .putInt("scheduleStartMin", n.scheduleStartMin)
            .putInt("scheduleEndMin", n.scheduleEndMin)
            .putBoolean("clipboardWatch", n.clipboardWatch)
            .putInt("theme", n.theme)
            .putBoolean("bangla", n.bangla)
            .apply()
        Engine.onSettingsChanged()
    }
}
