package com.rdm.pro

// পরিচিত বিজ্ঞাপন ও ট্র্যাকার সার্ভারের তালিকা। এই সার্ভার থেকে আসা রিকোয়েস্ট ব্রাউজারে ব্লক করা হয়।
// (তালিকা ছোট ও সরল, তাই সব বিজ্ঞাপন ধরবে না। দরকারমতো এখানে ডোমেইন যোগ করা যায়।)
object AdBlock {
    private val domains: Set<String> = hashSetOf(
        // Google
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "googletagservices.com", "2mdn.net", "google-analytics.com",
        // বড় অ্যাড এক্সচেঞ্জ ও নেটওয়ার্ক
        "amazon-adsystem.com", "adnxs.com", "rubiconproject.com", "pubmatic.com", "openx.net",
        "criteo.com", "criteo.net", "taboola.com", "outbrain.com", "revcontent.com", "mgid.com",
        "adform.net", "smartadserver.com", "advertising.com", "adsrvr.org", "casalemedia.com",
        "contextweb.com", "yieldmo.com", "teads.tv", "33across.com", "sharethrough.com",
        "lijit.com", "indexww.com", "bidswitch.net", "adskeeper.com", "adsco.re",
        // ট্র্যাকার
        "moatads.com", "scorecardresearch.com", "quantserve.com", "hotjar.com", "mc.yandex.ru",
        // পপ-আপ/পুশ বিজ্ঞাপন নেটওয়ার্ক
        "popads.net", "popcash.net", "propellerads.com", "adsterra.com", "exoclick.com", "exosrv.com",
        "juicyads.com", "trafficjunky.net", "clickadu.com", "hilltopads.net", "adcash.com",
        "bidvertiser.com", "a-ads.com", "ad-maven.com", "admaven.com", "monetag.com",
        "onclickalgo.com", "onclkds.com", "richads.com", "tsyndicate.com", "plugrush.com",
        "ero-advertising.com", "an.yandex.ru", "yandexadexchange.net"
    )

    // "a.b.doubleclick.net" হলে প্রথমে পুরো হোস্ট, তারপর একটা একটা করে বাঁ দিকের অংশ বাদ দিয়ে মেলানো হয়
    fun isBlocked(host: String?): Boolean {
        var h = host?.lowercase() ?: return false
        while (true) {
            if (h in domains) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }
}
