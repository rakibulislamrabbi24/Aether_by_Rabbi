package com.rdm.pro

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import org.json.JSONArray
import org.json.JSONTokener
import java.net.URLDecoder
import java.net.URLEncoder

// ব্রাউজারে পাওয়া একটা মিডিয়া ফাইল
data class MediaHit(val url: String, val referer: String, val label: String)

// WebView আর বর্তমান পেজের লিংক ধরে রাখে (রিকম্পোজ হলেও যাতে হারিয়ে না যায়)
private class BrowserState {
    @Volatile var page: String = ""
    var web: WebView? = null
}

private val mediaExt = setOf(
    "mp4", "m4v", "webm", "mkv", "mov", "avi", "flv", "3gp",
    "mp3", "m4a", "aac", "ogg", "opus", "wav", "flac"
)

// লিংকের শেষে মিডিয়া এক্সটেনশন থাকলে সেটা মিডিয়া ধরা হবে
private fun looksLikeMedia(url: String): Boolean {
    if (!url.startsWith("http://") && !url.startsWith("https://")) return false
    val path = url.substringBefore('?').substringBefore('#').lowercase()
    return path.substringAfterLast('.', "") in mediaExt
}

private fun labelOf(url: String): String {
    val seg = Uri.parse(url).lastPathSegment ?: return url
    return runCatching { URLDecoder.decode(seg, "UTF-8") }.getOrDefault(seg)
}

private fun normalizeInput(text: String): String {
    val x = text.trim()
    if (x.startsWith("http://") || x.startsWith("https://")) return x
    if (!x.contains(' ') && x.contains('.')) return "https://$x"
    return "https://www.google.com/search?q=" + URLEncoder.encode(x, "UTF-8")
}

// পেজের <video>/<audio> ট্যাগ থেকে লিংক বের করার জাভাস্ক্রিপ্ট
private const val DETECT_JS =
    "(function(){var r=[];" +
        "document.querySelectorAll('video,audio').forEach(function(v){" +
        "if(v.currentSrc)r.push(v.currentSrc);if(v.src)r.push(v.src);" +
        "v.querySelectorAll('source').forEach(function(x){if(x.src)r.push(x.src)})});" +
        "return JSON.stringify(r);})()"

@Composable
fun BrowserScreen(onClose: () -> Unit) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val bs = remember { BrowserState() }
    val found = remember { mutableStateListOf<MediaHit>() }
    var addr by remember { mutableStateOf("") }
    var progress by remember { mutableStateOf(100) }
    var showList by remember { mutableStateOf(false) }

    fun addHit(url: String, referer: String) {
        if (found.size >= 60) return
        if (found.none { it.url == url }) found.add(MediaHit(url, referer, labelOf(url)))
    }

    fun go() {
        bs.web?.loadUrl(normalizeInput(addr))
    }

    fun downloadHit(hit: MediaHit) {
        val cookie = CookieManager.getInstance().getCookie(hit.url)
        val ua = bs.web?.settings?.userAgentString
        Engine.add(hit.url, referer = hit.referer, cookie = cookie, userAgent = ua)
        Toast.makeText(ctx, s.downloadStarted, Toast.LENGTH_SHORT).show()
    }

    BackHandler {
        val w = bs.web
        if (w != null && w.canGoBack()) w.goBack() else onClose()
    }
    DisposableEffect(Unit) {
        onDispose {
            bs.web?.destroy()
            bs.web = null
        }
    }

    val cs = MaterialTheme.colorScheme
    Column(modifier = Modifier.fillMaxSize()) {
        // ঠিকানা বার
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, contentDescription = s.close) }
            OutlinedTextField(
                value = addr,
                onValueChange = { addr = it },
                placeholder = { Text(s.addressHint) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(onGo = { go() }),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(4.dp))
            IconButton(onClick = { go() }) { Icon(Icons.Rounded.ArrowForward, contentDescription = s.go) }
        }
        if (progress < 100) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
        }

        // ওয়েব পেজ
        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            progress = newProgress
                        }
                    }

                    webViewClient = object : WebViewClient() {
                        // http/https ছাড়া অন্য লিংক (intent://, market:// ইত্যাদি) ব্লক
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val scheme = request?.url?.scheme ?: return false
                            return scheme != "http" && scheme != "https"
                        }

                        // পেজ যা যা লোড করে তার মধ্যে মিডিয়া ফাইল থাকলে ধরে ফেলা (ব্যাকগ্রাউন্ড থ্রেডে চলে)
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            val u = request?.url?.toString()
                            if (u != null && looksLikeMedia(u)) {
                                val ref = request?.requestHeaders?.get("Referer") ?: bs.page
                                Handler(Looper.getMainLooper()).post { addHit(u, ref) }
                            }
                            return null
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            if (url != null) {
                                bs.page = url
                                addr = url
                            }
                            found.clear()
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            val v = view ?: return
                            // পেজ শেষ হওয়ার পর এবং একটু পরে আবার <video> ট্যাগ খুঁজে দেখা
                            val task = Runnable { detectInPage(v) { hit -> addHit(hit, bs.page) } }
                            task.run()
                            v.postDelayed(task, 2500)
                            v.postDelayed(task, 6000)
                        }
                    }

                    // সাধারণ ডাউনলোড লিংকে (zip, apk, pdf ইত্যাদি) ট্যাপ করলে সরাসরি RDM Pro-তে যাবে
                    setDownloadListener { url, userAgent, _, _, _ ->
                        val cookie = CookieManager.getInstance().getCookie(url)
                        Engine.add(url, referer = bs.page, cookie = cookie, userAgent = userAgent)
                        Toast.makeText(c, s.downloadStarted, Toast.LENGTH_SHORT).show()
                    }

                    bs.web = this
                    loadUrl("https://www.google.com")
                }
            }
        )

        // নিচের বার: আইকন বাটন
        Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                IconButton(onClick = { bs.web?.let { if (it.canGoBack()) it.goBack() } }) {
                    Icon(Icons.Rounded.ArrowBack, contentDescription = s.back)
                }
                IconButton(onClick = { bs.web?.let { if (it.canGoForward()) it.goForward() } }) {
                    Icon(Icons.Rounded.ArrowForward, contentDescription = s.forward)
                }
                IconButton(onClick = { bs.web?.loadUrl("https://www.google.com") }) {
                    Icon(Icons.Rounded.Home, contentDescription = s.home)
                }
                IconButton(onClick = { bs.web?.reload() }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = s.reload)
                }
                // মিডিয়া বাটন: পাওয়া ফাইলের সংখ্যা ব্যাজে দেখায়
                Box {
                    IconButton(onClick = { showList = true }, enabled = found.isNotEmpty()) {
                        Icon(Icons.Rounded.Movie, contentDescription = s.mediaButton)
                    }
                    if (found.isNotEmpty()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(top = 4.dp, end = 4.dp)
                                .size(18.dp)
                                .clip(CircleShape)
                                .background(cs.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "${found.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = cs.onPrimary
                            )
                        }
                    }
                }
            }
        }
    }

    if (showList) {
        AlertDialog(
            onDismissRequest = { showList = false },
            title = { Text(s.mediaFound) },
            confirmButton = { TextButton(onClick = { showList = false }) { Text(s.close) } },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(found, key = { it.url }) { hit ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FileIcon(
                                kind = kindOf(hit.label),
                                container = cs.primaryContainer,
                                content = cs.onPrimaryContainer
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    hit.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    Uri.parse(hit.url).host ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = {
                                downloadHit(hit)
                                showList = false
                            }) { Icon(Icons.Rounded.Download, contentDescription = s.download) }
                        }
                    }
                }
            }
        )
    }
}

// পেজের ভেতরের <video>/<audio> ট্যাগ থেকে লিংক বের করে (blob: লিংক বাদ)
private fun detectInPage(view: WebView, onHit: (String) -> Unit) {
    view.evaluateJavascript(DETECT_JS) { res ->
        try {
            val text = JSONTokener(res).nextValue() as? String
            if (text != null) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val u = arr.getString(i)
                    if (u.startsWith("http://") || u.startsWith("https://")) onHit(u)
                }
            }
        } catch (e: Exception) {
            // পেজ থেকে পড়া না গেলে কিছু করার নেই
        }
    }
}
