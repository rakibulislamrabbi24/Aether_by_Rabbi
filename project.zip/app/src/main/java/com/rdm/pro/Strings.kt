package com.rdm.pro

import androidx.compose.runtime.staticCompositionLocalOf

// অ্যাপের সব লেখা এখানে — বাংলা ও ইংরেজি দুই ভাষায়
class Strings(private val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e

    // মূল স্ক্রিন
    val settings = t("সেটিংস", "Settings")
    val back = t("পেছনে", "Back")
    val downloadLink = t("ডাউনলোড লিংক", "Download link")
    val paste = t("পেস্ট", "Paste")
    val download = t("ডাউনলোড", "Download")
    val invalidLink = t("সঠিক http/https লিংক দিন", "Enter a valid http/https link")
    val emptyState = t(
        "এখনও কোনো ডাউনলোড নেই।\nউপরে লিংক পেস্ট করুন, অথবা ব্রাউজার থেকে লিংক শেয়ার করুন।",
        "No downloads yet.\nPaste a link above, or share a link from your browser to RDM Pro."
    )
    val clipFound = t("ক্লিপবোর্ডে লিংক পাওয়া গেছে", "Link found in clipboard")
    val dismiss = t("বাদ দিন", "Dismiss")

    // ব্রাউজার
    val browser = t("ব্রাউজার", "Browser")
    val addressHint = t("লিংক বা সার্চ লিখুন", "Enter link or search")
    val go = t("যান", "Go")
    val forward = t("সামনে", "Forward")
    val reload = t("রিলোড", "Reload")
    val close = t("বন্ধ করুন", "Close")
    fun mediaButton(n: Int) = t("মিডিয়া ($n)", "Media ($n)")
    val mediaFound = t("পাওয়া মিডিয়া", "Detected media")
    val downloadStarted = t("ডাউনলোড শুরু হয়েছে", "Download started")

    // কার্ডের বাটন
    val pause = t("থামান", "Pause")
    val resume = t("চালু করুন", "Resume")
    val retry = t("আবার চেষ্টা", "Retry")
    val open = t("খুলুন", "Open")
    val remove = t("মুছুন", "Remove")
    val noAppToOpen = t("এই ফাইল খোলার মতো অ্যাপ পাওয়া যায়নি", "No app found to open this file")

    // স্ট্যাটাস লাইন
    val starting = t("শুরু হচ্ছে…", "Starting…")
    val saving = t("Downloads-এ সেভ হচ্ছে…", "Saving to Downloads…")
    val waitWifi = t("Wi-Fi-এর জন্য অপেক্ষা করছে", "Waiting for Wi-Fi")
    fun waitSchedule(time: String) = t("শিডিউলের অপেক্ষায় ($time-এ শুরু হবে)", "Waiting for schedule (starts at $time)")
    fun paused(done: String, total: String) = t("থামানো · $done / $total", "Paused · $done / $total")
    fun completed(total: String) = t("সম্পূর্ণ · $total · Downloads/RDM Pro", "Completed · $total · Downloads/RDM Pro")
    fun failed(err: String?, done: String, total: String) =
        t("ব্যর্থ: ${err ?: "অজানা সমস্যা"} · $done / $total", "Failed: ${err ?: "unknown error"} · $done / $total")
    fun parts(n: Int) = t("$n পার্ট", "$n parts")
    fun eta(x: String) = t("বাকি $x", "ETA $x")

    // নোটিফিকেশন
    fun notifActive(n: Int, speed: String) = t("$n টি চলছে · $speed", "$n active · $speed")
    fun notifWaiting(n: Int) = t("$n টি অপেক্ষায় আছে", "$n waiting")

    // সেটিংস স্ক্রিন
    val wifiOnlyTitle = t("শুধু Wi-Fi-তে ডাউনলোড", "Download on Wi-Fi only")
    val wifiOnlySub = t(
        "মোবাইল ডাটায় ডাউনলোড চলবে না। Wi-Fi এলে নিজে থেকে চালু হবে।",
        "No downloads on mobile data. They resume automatically when Wi-Fi is back."
    )
    val speedLimitTitle = t("স্পিড লিমিট", "Speed limit")
    val unlimited = t("সীমাহীন", "Unlimited")
    val scheduleTitle = t("ডাউনলোড শিডিউল", "Download schedule")
    val scheduleSub = t(
        "শুধু নির্দিষ্ট সময়ের মধ্যে ডাউনলোড চলবে। রাতে ফোন চার্জে দিয়ে ব্যবহার করা ভালো।",
        "Downloads run only inside this time window. Best used overnight while charging."
    )
    val scheduleHint = t(
        "শিডিউল ঠিকমতো চলতে ফোনের সেটিংসে RDM Pro-র ব্যাটারি অপশন 'No restrictions' রাখুন।",
        "For the schedule to work reliably, set RDM Pro's battery option to 'No restrictions'."
    )
    val startTime = t("শুরু", "Start")
    val endTime = t("শেষ", "End")
    val clipboardTitle = t("ক্লিপবোর্ডের লিংক ধরা", "Detect links in clipboard")
    val clipboardSub = t(
        "লিংক কপি করে অ্যাপ খুললেই ডাউনলোডের অপশন দেখাবে।",
        "Offers to download a link when you copy one and open the app."
    )
    val themeTitle = t("থিম", "Theme")
    val themeSystem = t("সিস্টেম অনুযায়ী", "System default")
    val themeLight = t("লাইট", "Light")
    val themeDark = t("ডার্ক", "Dark")
    val languageTitle = t("ভাষা", "Language")
}

val LocalStr = staticCompositionLocalOf { Strings(true) }
