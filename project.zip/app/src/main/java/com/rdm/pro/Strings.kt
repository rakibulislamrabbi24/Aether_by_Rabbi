package com.rdm.pro

import androidx.compose.runtime.staticCompositionLocalOf

// অ্যাপের সব লেখা এখানে — ইংরেজি (ডিফল্ট) ও বাংলা দুই ভাষায়
class Strings(private val bn: Boolean) {
    private fun t(b: String, e: String) = if (bn) b else e

    // সাধারণ
    val back = t("পেছনে", "Back")
    val close = t("বন্ধ করুন", "Close")
    val cancel = t("বাতিল", "Cancel")
    val dismiss = t("বাদ দিন", "Dismiss")

    // হোম স্ক্রিন
    val addDownload = t("ডাউনলোড যোগ করুন", "Add download")
    val downloadLink = t("ডাউনলোড লিংক", "Download link")
    val paste = t("পেস্ট", "Paste")
    val download = t("ডাউনলোড", "Download")
    val invalidLink = t("সঠিক http/https লিংক দিন", "Enter a valid http/https link")
    val browser = t("ব্রাউজার", "Browser")
    val settings = t("সেটিংস", "Settings")
    val tabAll = t("সব", "All")
    val tabActive = t("চলমান", "Active")
    val tabDone = t("সম্পূর্ণ", "Done")
    val idle = t("নিষ্ক্রিয়", "Idle")
    fun summary(active: Int, waiting: Int, done: Int) =
        t("$active চলছে · $waiting অপেক্ষায় · $done সম্পূর্ণ", "$active active · $waiting waiting · $done done")
    val pauseAll = t("সব থামান", "Pause all")
    val resumeAll = t("সব চালু করুন", "Resume all")
    val clearDone = t("সম্পূর্ণগুলো মুছুন", "Clear completed")
    val emptyTitle = t("এখনও কোনো ডাউনলোড নেই", "No downloads yet")
    val emptySub = t(
        "+ চেপে লিংক যোগ করুন, অথবা ব্রাউজার থেকে লিংক শেয়ার করুন।",
        "Tap + to add a link, or share a link from your browser."
    )
    val emptyFilter = t("এখানে কিছু নেই", "Nothing here")
    val clipFound = t("ক্লিপবোর্ডে লিংক পাওয়া গেছে", "Link found in clipboard")

    // কার্ডের বাটন (আইকনের বর্ণনা)
    val pause = t("থামান", "Pause")
    val resume = t("চালু করুন", "Resume")
    val retry = t("আবার চেষ্টা", "Retry")
    val open = t("খুলুন", "Open")
    val remove = t("মুছুন", "Remove")
    val noAppToOpen = t("এই ফাইল খোলার মতো অ্যাপ পাওয়া যায়নি", "No app found to open this file")

    // বিস্তারিত ডায়ালগ
    val linkLabel = t("লিংক", "Link")
    val sizeLabel = t("সাইজ", "Size")
    val statusLabel = t("অবস্থা", "Status")
    val savedToLabel = t("সেভ হয়েছে", "Saved to")
    val copyLink = t("লিংক কপি", "Copy link")
    val rename = t("নাম বদলান", "Rename")
    val renameTitle = t("ফাইলের নাম বদলান", "Rename file")
    val save = t("সেভ", "Save")
    val fileNameLabel = t("ফাইলের নাম", "File name")
    val fileNameOptional = t("ফাইলের নাম (ঐচ্ছিক)", "File name (optional)")
    val typeLabel = t("ধরন", "Type")
    val typeStream = t("স্ট্রিম (HLS)", "Stream (HLS)")
    val typeFile = t("সাধারণ ফাইল", "Regular file")
    val duplicateTitle = t("লিংকটা আগে থেকেই আছে", "Already in your list")
    val duplicateBody = t("এই লিংক ডাউনলোডের তালিকায় আগেই আছে। আবার যোগ করবেন?", "This link is already in your downloads. Add it again?")
    val addAnyway = t("তবুও যোগ করুন", "Add anyway")
    val searchHint = t("ডাউনলোড খুঁজুন", "Search downloads")
    val sortTitle = t("সাজান", "Sort")
    val sortNewest = t("নতুন আগে", "Newest first")
    val sortOldest = t("পুরনো আগে", "Oldest first")
    val sortName = t("নাম (A–Z)", "Name (A–Z)")
    val sortSize = t("সাইজ (বড় আগে)", "Size (largest first)")
    val linkCopied = t("লিংক কপি হয়েছে", "Link copied")

    // স্ট্যাটাস লাইন
    val starting = t("শুরু হচ্ছে…", "Starting…")
    val saving = t("Downloads-এ সেভ হচ্ছে…", "Saving to Downloads…")
    val waitWifi = t("Wi-Fi-এর জন্য অপেক্ষা করছে", "Waiting for Wi-Fi")
    val waitQueue = t("কিউতে অপেক্ষা করছে", "Waiting in queue")
    fun segments(done: Int, total: Int) = t("$done/$total সেগমেন্ট", "$done/$total segments")
    fun failedShort(err: String?) = t("ব্যর্থ: ${err ?: "অজানা সমস্যা"}", "Failed: ${err ?: "unknown error"}")
    fun waitSchedule(time: String) = t("শিডিউলের অপেক্ষায় ($time-এ শুরু হবে)", "Waiting for schedule (starts at $time)")
    fun paused(done: String, total: String) = t("থামানো · $done / $total", "Paused · $done / $total")
    fun completed(total: String) = t("সম্পূর্ণ · $total", "Completed · $total")
    fun failed(err: String?, done: String, total: String) =
        t("ব্যর্থ: ${err ?: "অজানা সমস্যা"} · $done / $total", "Failed: ${err ?: "unknown error"} · $done / $total")
    fun parts(n: Int) = t("$n পার্ট", "$n parts")
    fun eta(x: String) = t("বাকি $x", "ETA $x")

    // নোটিফিকেশন
    fun notifActive(n: Int, speed: String) = t("$n টি চলছে · $speed", "$n active · $speed")
    fun notifWaiting(n: Int) = t("$n টি অপেক্ষায় আছে", "$n waiting")

    // ব্রাউজার
    val addressHint = t("লিংক বা সার্চ লিখুন", "Search or enter link")
    val go = t("যান", "Go")
    val forward = t("সামনে", "Forward")
    val reload = t("রিলোড", "Reload")
    val home = t("হোম", "Home")
    val mediaFound = t("পাওয়া মিডিয়া", "Detected media")
    val mediaButton = t("মিডিয়া", "Media")
    val downloadStarted = t("ডাউনলোড শুরু হয়েছে", "Download started")

    // সেটিংস
    val groupDownloads = t("ডাউনলোড", "Downloads")
    val groupAppearance = t("চেহারা", "Appearance")
    val queueTitle = t("একসাথে ডাউনলোড", "Simultaneous downloads")
    fun queueLabel(n: Int) = t("সর্বোচ্চ $n টি", "Up to $n at a time")
    val saveLocationTitle = t("সেভ করার জায়গা", "Save location")
    fun saveModeLabel(m: Int) = when (m) {
        1 -> t("Downloads/RDM Pro/ধরন অনুযায়ী ফোল্ডার", "Downloads/RDM Pro/<type> folders")
        2 -> "Downloads"
        else -> "Downloads/RDM Pro"
    }
    val streamQualityTitle = t("স্ট্রিমের কোয়ালিটি (HLS)", "Stream quality (HLS)")
    fun qualityLabel(q: Int) = when (q) {
        1 -> t("৭২০p পর্যন্ত", "Up to 720p")
        2 -> t("৪৮০p পর্যন্ত", "Up to 480p")
        3 -> t("সর্বনিম্ন (ডাটা বাঁচায়)", "Lowest (saves data)")
        else -> t("সেরা", "Best")
    }
    val notifyDoneTitle = t("শেষ হলে নোটিফিকেশন", "Notify when finished")
    val notifyDoneSub = t("ডাউনলোড শেষ বা ব্যর্থ হলে আলাদা নোটিফিকেশন আসবে।", "Get a notification when a download finishes or fails.")
    val wifiOnlyTitle = t("শুধু Wi-Fi-তে ডাউনলোড", "Download on Wi-Fi only")
    val wifiOnlySub = t(
        "মোবাইল ডাটায় ডাউনলোড চলবে না। Wi-Fi এলে নিজে থেকে চালু হবে।",
        "No downloads on mobile data. They resume automatically when Wi-Fi is back."
    )
    val speedLimitTitle = t("স্পিড লিমিট", "Speed limit")
    val unlimited = t("সীমাহীন", "Unlimited")
    fun speedLabel(kb: Int) = when {
        kb <= 0 -> unlimited
        kb >= 1024 -> "${kb / 1024} MB/s"
        else -> "$kb KB/s"
    }
    val scheduleTitle = t("ডাউনলোড শিডিউল", "Download schedule")
    val scheduleSub = t(
        "শুধু নির্দিষ্ট সময়ের মধ্যে ডাউনলোড চলবে।",
        "Downloads run only inside this time window."
    )
    val scheduleHint = t(
        "শিডিউল ঠিকমতো চলতে ফোনের সেটিংসে RDM Pro-র ব্যাটারি অপশন 'No restrictions' রাখুন।",
        "For the schedule to work reliably, set RDM Pro's battery option to 'No restrictions'."
    )
    val startTime = t("শুরু", "Start")
    val endTime = t("শেষ", "End")
    val clipboardTitle = t("ক্লিপবোর্ডের লিংক ধরা", "Detect links in clipboard")
    val clipboardSub = t(
        "লিংক কপি করে অ্যাপ খুললেই ডাউনলোডের অপশন দেখাবে।",
        "Offers to download a link when you copy one and open the app."
    )
    val themeTitle = t("থিম", "Theme")
    val themeSystem = t("সিস্টেম অনুযায়ী", "System default")
    val themeLight = t("লাইট", "Light")
    val themeDark = t("ডার্ক", "Dark")
    fun themeLabel(i: Int) = when (i) {
        1 -> themeLight
        2 -> themeDark
        else -> themeSystem
    }
    val languageTitle = t("ভাষা", "Language")
    val versionLabel = t("সংস্করণ", "Version")
}

val LocalStr = staticCompositionLocalOf { Strings(false) }
