package com.rdm.pro

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

// ডাউনলোড চলার সময় অ্যাপ যাতে ব্যাকগ্রাউন্ডে বন্ধ না হয়ে যায়, তার জন্য Foreground Service
class DownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "downloads"
        const val NOTIF_ID = 1001
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        startForeground(
            NOTIF_ID,
            buildNotification("Starting…", 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        scope.launch {
            Engine.items.collect { list ->
                val active = list.filter {
                    it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING
                }
                if (active.isEmpty()) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    var speed = 0L
                    var done = 0L
                    var total = 0L
                    var allKnown = true
                    for (d in active) {
                        speed += d.speedBps
                        if (d.totalBytes > 0) {
                            done += d.downloadedBytes
                            total += d.totalBytes
                        } else {
                            allKnown = false
                        }
                    }
                    val percent = if (total > 0) (done * 100 / total).toInt() else 0
                    val text = "${active.size} active · ${fmtBytes(speed)}/s"
                    val n = buildNotification(text, percent, !allKnown || total == 0L)
                    getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
                }
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(text: String, percent: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("RDM Pro")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setProgress(100, percent, indeterminate)
            .setContentIntent(open)
            .build()
    }
}
