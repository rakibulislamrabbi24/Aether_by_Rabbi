package com.rdm.pro

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

// ডাউনলোড চলার সময় (বা Wi-Fi/শিডিউলের অপেক্ষায় থাকার সময়) অ্যাপ যাতে বন্ধ না হয়ে যায়, তার জন্য Foreground Service
class DownloadService : Service() {

    companion object {
        const val CHANNEL_ID = "downloads"
        const val DONE_CHANNEL_ID = "done"
        const val NOTIF_ID = 1001
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        val s0 = Strings(Settings.state.value.bangla)
        startForeground(
            NOTIF_ID,
            buildNotification(s0.starting, 0, true, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        scope.launch {
            Engine.items.collect { list ->
                val running = list.filter {
                    it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING
                }
                val waiting = list.filter { it.status == Status.WAITING }
                if (running.isEmpty() && waiting.isEmpty()) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return@collect
                }
                val s = Strings(Settings.state.value.bangla)
                val n: Notification
                if (running.isNotEmpty()) {
                    var speed = 0L
                    var done = 0L
                    var total = 0L
                    var allKnown = true
                    for (d in running) {
                        speed += d.speedBps
                        if (d.totalBytes > 0) {
                            done += d.downloadedBytes
                            total += d.totalBytes
                        } else {
                            allKnown = false
                        }
                    }
                    val percent = if (total > 0) (done * 100 / total).toInt() else 0
                    n = buildNotification(
                        s.notifActive(running.size, fmtBytes(speed) + "/s"),
                        percent,
                        !allKnown || total == 0L,
                        true
                    )
                } else {
                    n = buildNotification(s.notifWaiting(waiting.size), 0, false, false)
                }
                getSystemService(NotificationManager::class.java).notify(NOTIF_ID, n)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private fun buildNotification(
        text: String,
        percent: Int,
        indeterminate: Boolean,
        showProgress: Boolean
    ): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("Aether")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .setContentIntent(open)
        if (showProgress) b.setProgress(100, percent, indeterminate)
        return b.build()
    }
}
