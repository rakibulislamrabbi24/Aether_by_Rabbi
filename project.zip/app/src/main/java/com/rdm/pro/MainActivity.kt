package com.rdm.pro

import android.Manifest
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val sharedLink = mutableStateOf("")
    private val clipLink = mutableStateOf("")
    private var lastClipStamp = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readSharedIntent(intent)
        setContent {
            val st by Settings.state.collectAsState()
            val dark = when (st.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            val strings = remember(st.bangla) { Strings(st.bangla) }
            MaterialTheme(colorScheme = if (dark) darkColorScheme() else lightColorScheme()) {
                CompositionLocalProvider(LocalStr provides strings) {
                    Surface(modifier = Modifier.fillMaxSize()) {
                        // 0 = মূল স্ক্রিন, 1 = সেটিংস, 2 = ব্রাউজার
                        var screen by remember { mutableStateOf(0) }
                        when (screen) {
                            1 -> SettingsScreen(st) { screen = 0 }
                            2 -> BrowserScreen { screen = 0 }
                            else -> RdmScreen(
                                sharedLink, clipLink, st,
                                onOpenSettings = { screen = 1 },
                                onOpenBrowser = { screen = 2 }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android 10+ এ ক্লিপবোর্ড পড়া যায় শুধু অ্যাপ সামনে (ফোকাসে) থাকলে
        if (hasFocus && Settings.state.value.clipboardWatch) checkClipboard()
    }

    private fun checkClipboard() {
        try {
            val cm = getSystemService(ClipboardManager::class.java)
            val desc = cm.primaryClipDescription ?: return
            if (!desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) return
            val stamp = desc.timestamp
            if (stamp == lastClipStamp) return // একই কপি দ্বিতীয়বার দেখাবে না
            lastClipStamp = stamp
            val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
            val link = Regex("https?://\\S+").find(text)?.value ?: return
            clipLink.value = link
        } catch (e: Exception) {
            // ক্লিপবোর্ড পড়া না গেলে কিছু করার নেই
        }
    }

    // ব্রাউজার বা অন্য অ্যাপ থেকে "Share → RDM Pro" করলে লিংকটা ইনপুটে বসে যাবে
    private fun readSharedIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            sharedLink.value = Regex("https?://\\S+").find(text)?.value ?: text
        }
    }
}

// ---------------------------------------------------------------------------
// মূল স্ক্রিন
// ---------------------------------------------------------------------------

@Composable
fun RdmScreen(
    shared: MutableState<String>,
    clip: MutableState<String>,
    st: AppSettings,
    onOpenSettings: () -> Unit,
    onOpenBrowser: () -> Unit
) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val downloads by Engine.items.collectAsState()
    var url by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(shared.value) {
        if (shared.value.isNotBlank()) url = shared.value
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "RDM Pro",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onOpenBrowser) { Text(s.browser) }
            TextButton(onClick = onOpenSettings) { Text(s.settings) }
        }
        Spacer(Modifier.height(8.dp))

        // ক্লিপবোর্ডে লিংক পাওয়া গেলে এই কার্ড দেখাবে
        val clipUrl = clip.value
        if (clipUrl.isNotBlank() && downloads.none { it.url == clipUrl }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(s.clipFound, style = MaterialTheme.typography.titleSmall)
                    Text(
                        clipUrl,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row {
                        TextButton(onClick = {
                            Engine.add(clipUrl)
                            clip.value = ""
                        }) { Text(s.download) }
                        TextButton(onClick = { clip.value = "" }) { Text(s.dismiss) }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text(s.downloadLink) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                TextButton(onClick = { url = clipboard.getText()?.text ?: url }) { Text(s.paste) }
            }
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (Engine.add(url)) {
                    url = ""
                    shared.value = ""
                } else {
                    Toast.makeText(ctx, s.invalidLink, Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(s.download) }
        Spacer(Modifier.height(12.dp))

        if (downloads.isEmpty()) {
            Text(s.emptyState, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(downloads, key = { it.id }) { d -> DownloadCard(d, st.scheduleStartMin) }
            }
        }
    }
}

@Composable
fun DownloadCard(d: DownloadItem, scheduleStartMin: Int) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val known = d.totalBytes > 0
    val frac = if (known) (d.downloadedBytes.toFloat() / d.totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
    val running = d.status == Status.DOWNLOADING || d.status == Status.QUEUED || d.status == Status.SAVING

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                d.fileName,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            if (d.status != Status.COMPLETED) {
                if (known) {
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                } else if (running) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
            }
            Text(
                statusLine(d, s, scheduleStartMin),
                style = MaterialTheme.typography.bodySmall,
                color = if (d.status == Status.FAILED) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                when (d.status) {
                    Status.QUEUED, Status.DOWNLOADING, Status.SAVING, Status.WAITING ->
                        TextButton(onClick = { Engine.pause(d.id) }) { Text(s.pause) }
                    Status.PAUSED ->
                        TextButton(onClick = { Engine.resume(d.id) }) { Text(s.resume) }
                    Status.FAILED ->
                        TextButton(onClick = { Engine.resume(d.id) }) { Text(s.retry) }
                    Status.COMPLETED ->
                        TextButton(onClick = { openFile(ctx, d, s) }) { Text(s.open) }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { Engine.remove(d.id) }) { Text(s.remove) }
            }
        }
    }
}

fun fmtTime(minutes: Int): String =
    String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

fun statusLine(d: DownloadItem, s: Strings, scheduleStartMin: Int): String {
    val done = fmtBytes(d.downloadedBytes)
    val total = if (d.totalBytes > 0) fmtBytes(d.totalBytes) else "?"
    return when (d.status) {
        Status.QUEUED -> s.starting
        Status.DOWNLOADING -> {
            val pct = if (d.totalBytes > 0) " (${d.downloadedBytes * 100 / d.totalBytes}%)" else ""
            val eta = if (d.speedBps > 0 && d.totalBytes > 0)
                " · " + s.eta(fmtEta((d.totalBytes - d.downloadedBytes) / d.speedBps))
            else ""
            val parts = if (d.partProgress.size > 1) " · " + s.parts(d.partProgress.size) else ""
            "$done / $total$pct · ${fmtBytes(d.speedBps)}/s$eta$parts"
        }
        Status.PAUSED -> s.paused(done, total)
        Status.WAITING ->
            if (d.waitReason == "schedule") s.waitSchedule(fmtTime(scheduleStartMin)) else s.waitWifi
        Status.SAVING -> s.saving
        Status.COMPLETED -> s.completed(total)
        Status.FAILED -> s.failed(d.error, done, total)
    }
}

fun openFile(ctx: Context, d: DownloadItem, s: Strings) {
    val uri = d.savedUri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), d.mimeType)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, s.noAppToOpen, Toast.LENGTH_SHORT).show()
    }
}

// ---------------------------------------------------------------------------
// সেটিংস স্ক্রিন
// ---------------------------------------------------------------------------

@Composable
fun SettingsScreen(st: AppSettings, onBack: () -> Unit) {
    val s = LocalStr.current
    BackHandler(onBack = onBack)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← " + s.back) }
        }
        Text(s.settings, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        // Wi-Fi only
        SwitchRow(s.wifiOnlyTitle, s.wifiOnlySub, st.wifiOnly) { v ->
            Settings.update { it.copy(wifiOnly = v) }
        }

        // ক্লিপবোর্ড
        SwitchRow(s.clipboardTitle, s.clipboardSub, st.clipboardWatch) { v ->
            Settings.update { it.copy(clipboardWatch = v) }
        }

        // স্পিড লিমিট
        SectionTitle(s.speedLimitTitle)
        val limits = listOf(
            0 to s.unlimited,
            256 to "256 KB/s",
            512 to "512 KB/s",
            1024 to "1 MB/s",
            2048 to "2 MB/s",
            5120 to "5 MB/s"
        )
        limits.forEach { (kb, label) ->
            RadioRow(label, st.speedLimitKb == kb) { Settings.update { it.copy(speedLimitKb = kb) } }
        }

        // শিডিউল
        Spacer(Modifier.height(12.dp))
        SwitchRow(s.scheduleTitle, s.scheduleSub, st.scheduleEnabled) { v ->
            Settings.update { it.copy(scheduleEnabled = v) }
        }
        if (st.scheduleEnabled) {
            TimeStepper(s.startTime, st.scheduleStartMin) { m -> Settings.update { it.copy(scheduleStartMin = m) } }
            TimeStepper(s.endTime, st.scheduleEndMin) { m -> Settings.update { it.copy(scheduleEndMin = m) } }
            Text(
                s.scheduleHint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        // থিম
        Spacer(Modifier.height(12.dp))
        SectionTitle(s.themeTitle)
        RadioRow(s.themeSystem, st.theme == 0) { Settings.update { it.copy(theme = 0) } }
        RadioRow(s.themeLight, st.theme == 1) { Settings.update { it.copy(theme = 1) } }
        RadioRow(s.themeDark, st.theme == 2) { Settings.update { it.copy(theme = 2) } }

        // ভাষা
        Spacer(Modifier.height(12.dp))
        SectionTitle(s.languageTitle)
        RadioRow("বাংলা", st.bangla) { Settings.update { it.copy(bangla = true) } }
        RadioRow("English", !st.bangla) { Settings.update { it.copy(bangla = false) } }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
    )
}

@Composable
fun SwitchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            if (sub != null) {
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

// ৩০ মিনিট করে কমানো/বাড়ানোর বাটন
@Composable
fun TimeStepper(label: String, minutes: Int, onChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, modifier = Modifier.weight(1f))
        OutlinedButton(onClick = { onChange((minutes - 30 + 1440) % 1440) }) { Text("−") }
        Text(
            fmtTime(minutes),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 14.dp)
        )
        OutlinedButton(onClick = { onChange((minutes + 30) % 1440) }) { Text("+") }
    }
}
