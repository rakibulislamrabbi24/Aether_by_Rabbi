package com.rdm.pro

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val sharedLink = mutableStateOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readSharedIntent(intent)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    RdmScreen(sharedLink)
                }
            }
        }
    }

    // ব্রাউজার বা অন্য অ্যাপ থেকে "Share → RDM Pro" করলে লিংকটা ইনপুটে বসে যাবে
    private fun readSharedIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            sharedLink.value = Regex("https?://\\S+").find(text)?.value ?: text
        }
    }
}

@Composable
fun RdmScreen(shared: MutableState<String>) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val downloads by Engine.items.collectAsState()
    var url by remember { mutableStateOf("") }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    LaunchedEffect(shared.value) {
        if (shared.value.isNotBlank()) url = shared.value
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("RDM Pro", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Download link") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            trailingIcon = {
                TextButton(onClick = { url = clipboard.getText()?.text ?: url }) { Text("Paste") }
            }
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                if (Engine.add(url)) {
                    url = ""
                    shared.value = ""
                } else {
                    Toast.makeText(ctx, "Enter a valid http/https link", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Download") }
        Spacer(Modifier.height(12.dp))

        if (downloads.isEmpty()) {
            Text(
                "No downloads yet.\nPaste a link above, or share a link from your browser to RDM Pro.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(downloads, key = { it.id }) { d -> DownloadCard(d) }
            }
        }
    }
}

@Composable
fun DownloadCard(d: DownloadItem) {
    val ctx = LocalContext.current
    val known = d.totalBytes > 0
    val frac = if (known) (d.downloadedBytes.toFloat() / d.totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
    val running = d.status == Status.DOWNLOADING || d.status == Status.QUEUED || d.status == Status.SAVING

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                d.fileName,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(8.dp))
            if (d.status != Status.COMPLETED) {
                if (known) {
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                } else if (running) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
            }
            Text(
                statusLine(d),
                style = MaterialTheme.typography.bodySmall,
                color = if (d.status == Status.FAILED) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                when (d.status) {
                    Status.QUEUED, Status.DOWNLOADING, Status.SAVING ->
                        TextButton(onClick = { Engine.pause(d.id) }) { Text("Pause") }
                    Status.PAUSED ->
                        TextButton(onClick = { Engine.resume(d.id) }) { Text("Resume") }
                    Status.FAILED ->
                        TextButton(onClick = { Engine.resume(d.id) }) { Text("Retry") }
                    Status.COMPLETED ->
                        TextButton(onClick = { openFile(ctx, d) }) { Text("Open") }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { Engine.remove(d.id) }) { Text("Remove") }
            }
        }
    }
}

fun statusLine(d: DownloadItem): String {
    val done = fmtBytes(d.downloadedBytes)
    val total = if (d.totalBytes > 0) fmtBytes(d.totalBytes) else "?"
    return when (d.status) {
        Status.QUEUED -> "Starting…"
        Status.DOWNLOADING -> {
            val pct = if (d.totalBytes > 0) " (${d.downloadedBytes * 100 / d.totalBytes}%)" else ""
            val eta = if (d.speedBps > 0 && d.totalBytes > 0)
                " · ETA " + fmtEta((d.totalBytes - d.downloadedBytes) / d.speedBps)
            else ""
            val parts = if (d.partProgress.size > 1) " · ${d.partProgress.size} parts" else ""
            "$done / $total$pct · ${fmtBytes(d.speedBps)}/s$eta$parts"
        }
        Status.PAUSED -> "Paused · $done / $total"
        Status.SAVING -> "Saving to Downloads…"
        Status.COMPLETED -> "Completed · $total · Downloads/RDM Pro"
        Status.FAILED -> "Failed: ${d.error ?: "unknown error"} · $done / $total"
    }
}

fun openFile(ctx: Context, d: DownloadItem) {
    val uri = d.savedUri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), d.mimeType)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "No app found to open this file", Toast.LENGTH_SHORT).show()
    }
}
