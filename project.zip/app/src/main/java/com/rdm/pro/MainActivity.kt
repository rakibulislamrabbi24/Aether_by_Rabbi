package com.rdm.pro

import android.Manifest
import android.app.Activity
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings as SettingsIcon
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val sharedLink = mutableStateOf("")
    private val clipLink = mutableStateOf("")
    private var lastClipStamp = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        readSharedIntent(intent)
        setContent {
            val st by Settings.state.collectAsState()
            val dark = when (st.theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            val strings = remember(st.bangla) { Strings(st.bangla) }
            val scheme = if (dark) DarkColors else LightColors

            // স্ট্যাটাস বার ও নেভিগেশন বার অ্যাপের ব্যাকগ্রাউন্ডের সাথে মেলানো
            val view = LocalView.current
            SideEffect {
                val w = (view.context as Activity).window
                w.statusBarColor = scheme.surface.toArgb()
                w.navigationBarColor = scheme.surface.toArgb()
                val c = WindowCompat.getInsetsController(w, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
            }

            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(LocalStr provides strings) {
                    Surface(modifier = Modifier.fillMaxSize(), color = scheme.background) {
                        // 0 = হোম, 1 = সেটিংস, 2 = ব্রাউজার
                        var screen by remember { mutableStateOf(0) }
                        when (screen) {
                            1 -> SettingsScreen(st) { screen = 0 }
                            2 -> BrowserScreen { screen = 0 }
                            else -> HomeScreen(
                                shared = sharedLink,
                                clip = clipLink,
                                scheduleStartMin = st.scheduleStartMin,
                                onBrowser = { screen = 2 },
                                onSettings = { screen = 1 }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android 10+ এ ক্লিপবোর্ড পড়া যায় শুধু অ্যাপ সামনে (ফোকাসে) থাকলে
        if (hasFocus && Settings.state.value.clipboardWatch) checkClipboard()
    }

    private fun checkClipboard() {
        try {
            val cm = getSystemService(ClipboardManager::class.java)
            val desc = cm.primaryClipDescription ?: return
            if (!desc.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) return
            val stamp = desc.timestamp
            if (stamp == lastClipStamp) return // একই কপি দ্বিতীয়বার দেখাবে না
            lastClipStamp = stamp
            val text = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: return
            val link = Regex("https?://\\S+").find(text)?.value ?: return
            clipLink.value = link
        } catch (e: Exception) {
            // ক্লিপবোর্ড পড়া না গেলে কিছু করার নেই
        }
    }

    // ব্রাউজার বা অন্য অ্যাপ থেকে "Share → Aether" করলে লিংকটা যোগ করার ডায়ালগে বসে যাবে
    private fun readSharedIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
            sharedLink.value = Regex("https?://\\S+").find(text)?.value ?: text
        }
    }
}

// ---------------------------------------------------------------------------
// হোম স্ক্রিন
// ---------------------------------------------------------------------------

@Composable
fun HomeScreen(
    shared: MutableState<String>,
    clip: MutableState<String>,
    scheduleStartMin: Int,
    onBrowser: () -> Unit,
    onSettings: () -> Unit
) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val clipboard = LocalClipboardManager.current
    val downloads by Engine.items.collectAsState()
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var addText by remember { mutableStateOf("") }
    var nameText by remember { mutableStateOf("") }
    var dupUrl by remember { mutableStateOf<String?>(null) }
    var detailId by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    // অন্য অ্যাপ থেকে লিংক শেয়ার করলে যোগ করার ডায়ালগ নিজেই খুলবে
    LaunchedEffect(shared.value) {
        if (shared.value.isNotBlank()) {
            addText = shared.value
            showAdd = true
            shared.value = ""
        }
    }

    val activeCount = downloads.count {
        it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING
    }
    val waitingCount = downloads.count { it.status == Status.WAITING }
    val doneCount = downloads.count { it.status == Status.COMPLETED }
    val stoppedCount = downloads.count { it.status == Status.PAUSED || it.status == Status.FAILED }
    val speed = downloads.filter { it.status == Status.DOWNLOADING }.sumOf { it.speedBps }
    val q = query.trim().lowercase()
    val byTab = when (tab) {
        1 -> downloads.filter { it.status != Status.COMPLETED }
        2 -> downloads.filter { it.status == Status.COMPLETED }
        else -> downloads
    }
    val bySearch = if (q.isEmpty()) byTab else byTab.filter {
        it.fileName.lowercase().contains(q) || it.url.lowercase().contains(q)
    }
    val shown = when (sort) {
        1 -> bySearch.reversed()
        2 -> bySearch.sortedBy { it.fileName.lowercase() }
        3 -> bySearch.sortedByDescending { it.totalBytes }
        else -> bySearch
    }

    Scaffold(
        containerColor = cs.background,
        floatingActionButton = {
            FloatingActionButton(onClick = {
                addText = ""
                nameText = ""
                showAdd = true
            }) {
                Icon(Icons.Rounded.Add, contentDescription = s.addDownload)
            }
        }
    ) { pad ->
        Column(modifier = Modifier.fillMaxSize().padding(pad)) {

            // উপরের বার: লোগো, নাম, ব্রাউজার ও সেটিংস আইকন
            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.size(38.dp).clip(RoundedCornerShape(11.dp)).background(cs.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null, tint = cs.onPrimary)
                }
                Spacer(Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        s.appName,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        s.byline,
                        style = MaterialTheme.typography.labelSmall,
                        color = cs.onSurfaceVariant,
                        letterSpacing = 3.sp
                    )
                }
                IconButton(onClick = onBrowser) { Icon(Icons.Rounded.Public, contentDescription = s.browser) }
                IconButton(onClick = onSettings) { Icon(Icons.Rounded.SettingsIcon, contentDescription = s.settings) }
            }

            if (downloads.isNotEmpty()) {
                SummaryCard(speed, activeCount, waitingCount, doneCount, stoppedCount)
                Row(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text(s.searchHint) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Rounded.Close, contentDescription = s.dismiss)
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(28.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Box {
                        IconButton(onClick = { sortMenu = true }) {
                            Icon(Icons.Rounded.Sort, contentDescription = s.sortTitle)
                        }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            listOf(0 to s.sortNewest, 1 to s.sortOldest, 2 to s.sortName, 3 to s.sortSize)
                                .forEach { (v, label) ->
                                    DropdownMenuItem(
                                        text = { Text(label) },
                                        onClick = {
                                            sort = v
                                            sortMenu = false
                                        },
                                        leadingIcon = {
                                            if (sort == v) Icon(Icons.Rounded.Check, contentDescription = null)
                                        }
                                    )
                                }
                        }
                    }
                }
                Spacer(Modifier.height(4.dp))
                TabRow(selectedTabIndex = tab, containerColor = Color.Transparent) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text(s.tabAll) })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text(s.tabActive) })
                    Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text(s.tabDone) })
                }
            }

            // ক্লিপবোর্ডে লিংক পাওয়া গেলে এই কার্ড দেখাবে
            val clipUrl = clip.value
            if (clipUrl.isNotBlank() && downloads.none { it.url == clipUrl }) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cs.secondaryContainer),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, tint = cs.onSecondaryContainer)
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                s.clipFound,
                                style = MaterialTheme.typography.titleSmall,
                                color = cs.onSecondaryContainer
                            )
                            Text(
                                clipUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = cs.onSecondaryContainer.copy(alpha = 0.8f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(onClick = {
                            Engine.add(clipUrl)
                            clip.value = ""
                        }) { Icon(Icons.Rounded.Download, contentDescription = s.download, tint = cs.onSecondaryContainer) }
                        IconButton(onClick = { clip.value = "" }) {
                            Icon(Icons.Rounded.Close, contentDescription = s.dismiss, tint = cs.onSecondaryContainer)
                        }
                    }
                }
            }

            if (shown.isEmpty()) {
                EmptyState(downloads.isEmpty())
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(shown, key = { it.id }) { d ->
                        DownloadCard(d, scheduleStartMin) { detailId = d.id }
                    }
                }
            }
        }
    }

    // লিংক যোগ করার ডায়ালগ
    if (showAdd) {
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text(s.addDownload) },
            text = {
                Column {
                    OutlinedTextField(
                        value = addText,
                        onValueChange = { addText = it },
                        label = { Text(s.downloadLink) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        trailingIcon = {
                            IconButton(onClick = { addText = clipboard.getText()?.text ?: addText }) {
                                Icon(Icons.Rounded.ContentPaste, contentDescription = s.paste)
                            }
                        }
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = nameText,
                        onValueChange = { nameText = it },
                        label = { Text(s.fileNameOptional) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (Engine.exists(addText)) {
                        dupUrl = addText // আগে থেকেই আছে: জিজ্ঞেস করে নেওয়া
                    } else if (Engine.add(addText, name = nameText.ifBlank { null })) {
                        showAdd = false
                        addText = ""
                        nameText = ""
                    } else {
                        Toast.makeText(ctx, s.invalidLink, Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(s.download)
                }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text(s.cancel) } }
        )
    }

    // একই লিংক আবার যোগ করতে গেলে সতর্কতা
    val du = dupUrl
    if (du != null) {
        AlertDialog(
            onDismissRequest = { dupUrl = null },
            title = { Text(s.duplicateTitle) },
            text = { Text(s.duplicateBody) },
            confirmButton = {
                TextButton(onClick = {
                    Engine.add(du, name = nameText.ifBlank { null })
                    dupUrl = null
                    showAdd = false
                    addText = ""
                    nameText = ""
                }) { Text(s.addAnyway) }
            },
            dismissButton = { TextButton(onClick = { dupUrl = null }) { Text(s.cancel) } }
        )
    }

    // ডাউনলোডের বিস্তারিত
    val detail = detailId?.let { id -> downloads.firstOrNull { it.id == id } }
    if (detail != null) {
        DetailsDialog(detail, scheduleStartMin) { detailId = null }
    }
}

// উপরের বড় কার্ড: মোট স্পিড, সংখ্যা ও সবার জন্য বাটন
@Composable
fun SummaryCard(speed: Long, active: Int, waiting: Int, done: Int, stopped: Int) {
    val s = LocalStr.current
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = cs.primaryContainer),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.padding(start = 20.dp, end = 8.dp, top = 14.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    if (active > 0) fmtBytes(speed) + "/s" else s.idle,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = cs.onPrimaryContainer
                )
                Text(
                    s.summary(active, waiting, done),
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
            if (active + waiting > 0) {
                IconButton(onClick = { Engine.pauseAll() }) {
                    Icon(Icons.Rounded.Pause, contentDescription = s.pauseAll, tint = cs.onPrimaryContainer)
                }
            }
            if (stopped > 0) {
                IconButton(onClick = { Engine.resumeAll() }) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = s.resumeAll, tint = cs.onPrimaryContainer)
                }
            }
            if (done > 0) {
                IconButton(onClick = { Engine.clearCompleted() }) {
                    Icon(Icons.Rounded.DeleteSweep, contentDescription = s.clearDone, tint = cs.onPrimaryContainer)
                }
            }
        }
    }
}

@Composable
fun ColumnScope.EmptyState(noDownloadsAtAll: Boolean) {
    val s = LocalStr.current
    val cs = MaterialTheme.colorScheme
    Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Box(
                modifier = Modifier.size(96.dp).clip(CircleShape).background(cs.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.Download,
                    contentDescription = null,
                    modifier = Modifier.size(44.dp),
                    tint = cs.onPrimaryContainer
                )
            }
            Spacer(Modifier.height(16.dp))
            Text(
                if (noDownloadsAtAll) s.emptyTitle else s.emptyFilter,
                style = MaterialTheme.typography.titleMedium
            )
            if (noDownloadsAtAll) {
                Spacer(Modifier.height(6.dp))
                Text(
                    s.emptySub,
                    style = MaterialTheme.typography.bodyMedium,
                    color = cs.onSurfaceVariant
                )
            }
        }
    }
}

// একটা ডাউনলোডের কার্ড
@Composable
fun DownloadCard(d: DownloadItem, scheduleStartMin: Int, onClick: () -> Unit) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val failed = d.status == Status.FAILED
    val known = d.totalBytes > 0
    val frac = if (known) (d.downloadedBytes.toFloat() / d.totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
    val running = d.status == Status.DOWNLOADING || d.status == Status.QUEUED || d.status == Status.SAVING
    val shape = RoundedCornerShape(20.dp)

    Card(
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = cs.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().clip(shape).clickable(onClick = onClick)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            FileIcon(
                kind = kindOf(d.fileName),
                container = if (failed) cs.errorContainer else cs.primaryContainer,
                content = if (failed) cs.onErrorContainer else cs.onPrimaryContainer
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    d.fileName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (d.status != Status.COMPLETED) {
                    Spacer(Modifier.height(8.dp))
                    val bar = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                    if (known) {
                        LinearProgressIndicator(progress = { frac }, modifier = bar, trackColor = cs.surface)
                    } else if (running) {
                        LinearProgressIndicator(modifier = bar, trackColor = cs.surface)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    statusLine(d, s, scheduleStartMin),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (failed) cs.error else cs.onSurfaceVariant
                )
            }
            Spacer(Modifier.width(8.dp))
            when (d.status) {
                Status.QUEUED, Status.DOWNLOADING, Status.SAVING, Status.WAITING ->
                    TonalIconButton(Icons.Rounded.Pause, s.pause) { Engine.pause(d.id) }
                Status.PAUSED ->
                    TonalIconButton(Icons.Rounded.PlayArrow, s.resume) { Engine.resume(d.id) }
                Status.FAILED ->
                    TonalIconButton(Icons.Rounded.Refresh, s.retry) { Engine.resume(d.id) }
                Status.COMPLETED ->
                    TonalIconButton(Icons.Rounded.OpenInNew, s.open) { openFile(ctx, d, s) }
            }
        }
    }
}

@Composable
fun DetailsDialog(d: DownloadItem, scheduleStartMin: Int, onDismiss: () -> Unit) {
    val s = LocalStr.current
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var renaming by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf(d.fileName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(d.fileName, maxLines = 3, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailLine(s.statusLabel, statusLine(d, s, scheduleStartMin))
                if (d.totalBytes > 0) DetailLine(s.sizeLabel, fmtBytes(d.totalBytes))
                DetailLine(s.typeLabel, if (d.isHls) s.typeStream else s.typeFile)
                if (d.status == Status.COMPLETED) DetailLine(s.savedToLabel, d.savedPath ?: "Download/Aether")
                DetailLine(s.linkLabel, d.url)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(s.close) } },
        dismissButton = {
            Row {
                IconButton(onClick = {
                    clipboard.setText(AnnotatedString(d.url))
                    Toast.makeText(ctx, s.linkCopied, Toast.LENGTH_SHORT).show()
                }) { Icon(Icons.Rounded.ContentCopy, contentDescription = s.copyLink) }
                IconButton(onClick = {
                    newName = d.fileName
                    renaming = true
                }) { Icon(Icons.Rounded.Edit, contentDescription = s.rename) }
                IconButton(onClick = {
                    Engine.remove(d.id)
                    onDismiss()
                }) {
                    Icon(
                        Icons.Rounded.Delete,
                        contentDescription = s.remove,
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    )

    if (renaming) {
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text(s.renameTitle) },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = { Text(s.fileNameLabel) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newName.isNotBlank()) Engine.rename(d.id, newName)
                    renaming = false
                }) { Text(s.save) }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text(s.cancel) } }
        )
    }
}

@Composable
fun DetailLine(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, maxLines = 4, overflow = TextOverflow.Ellipsis)
    }
}

fun fmtTime(minutes: Int): String =
    String.format(Locale.US, "%02d:%02d", minutes / 60, minutes % 60)

fun statusLine(d: DownloadItem, s: Strings, scheduleStartMin: Int): String {
    val done = fmtBytes(d.downloadedBytes)
    val approx = if (d.isHls && d.status != Status.COMPLETED) "~" else ""
    val total = if (d.totalBytes > 0) approx + fmtBytes(d.totalBytes) else "?"
    return when (d.status) {
        Status.QUEUED -> s.starting
        Status.DOWNLOADING -> {
            val pct = if (d.totalBytes > 0) " (${minOf(100L, d.downloadedBytes * 100 / d.totalBytes)}%)" else ""
            val eta = if (d.speedBps > 0 && d.totalBytes > 0)
                " · " + s.eta(fmtEta((d.totalBytes - d.downloadedBytes).coerceAtLeast(0) / d.speedBps))
            else ""
            val extra = when {
                d.isHls && d.segTotal > 0 -> " · " + s.segments(d.segDone, d.segTotal)
                d.partProgress.size > 1 -> " · " + s.parts(d.partProgress.size)
                else -> ""
            }
            "$done / $total$pct · ${fmtBytes(d.speedBps)}/s$eta$extra"
        }
        Status.PAUSED -> s.paused(done, total)
        Status.WAITING -> when (d.waitReason) {
            "schedule" -> s.waitSchedule(fmtTime(scheduleStartMin))
            "queue" -> s.waitQueue
            else -> s.waitWifi
        }
        Status.SAVING -> s.saving
        Status.COMPLETED -> s.completed(total)
        Status.FAILED -> s.failed(d.error, done, total)
    }
}

fun openFile(ctx: Context, d: DownloadItem, s: Strings) {
    val uri = d.savedUri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), d.mimeType)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, s.noAppToOpen, Toast.LENGTH_SHORT).show()
    }
}
