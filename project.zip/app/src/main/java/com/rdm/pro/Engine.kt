package com.rdm.pro

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.Calendar
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicLongArray
import javax.crypto.Cipher
import javax.crypto.CipherOutputStream
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class Status { QUEUED, DOWNLOADING, PAUSED, WAITING, SAVING, COMPLETED, FAILED }

data class DownloadItem(
    val id: String,
    val url: String,
    val fileName: String,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val partProgress: List<Long> = emptyList(),
    val supportsRanges: Boolean = false,
    val status: Status = Status.QUEUED,
    val speedBps: Long = 0L,
    val error: String? = null,
    val savedUri: String? = null,
    val mimeType: String = "application/octet-stream",
    val waitReason: String? = null, // "wifi" বা "schedule" (Status.WAITING হলে)
    val referer: String? = null,    // ব্রাউজার থেকে আসা ডাউনলোডের জন্য
    val cookie: String? = null,
    val userAgent: String? = null,
    val isHls: Boolean = false,        // .m3u8 স্ট্রিম
    val segTotal: Int = 0,             // HLS: মোট সেগমেন্ট
    val segDone: Int = 0,              // HLS: নামানো সেগমেন্ট
    val nameLocked: Boolean = false,   // ব্যবহারকারী নিজে নাম দিয়েছে
    val savedPath: String? = null      // যেমন Download/Aether/Videos
)

// ---------- ছোট ফরম্যাটিং ফাংশন (UI আর নোটিফিকেশন দুই জায়গায় ব্যবহার হয়) ----------

fun fmtBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    do {
        v /= 1024.0
        i++
    } while (v >= 1024.0 && i < units.size - 1)
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun fmtEta(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

// ---------- স্পিড লিমিটার (সব ডাউনলোড মিলিয়ে একটাই সীমা) ----------

object Limiter {
    @Volatile var bytesPerSec: Long = 0L
    private var nextFree = 0L

    @Synchronized
    private fun reserve(bytes: Int): Long {
        val limit = bytesPerSec
        if (limit <= 0L) {
            nextFree = 0L
            return 0L
        }
        val now = System.nanoTime()
        val start = maxOf(now, nextFree)
        nextFree = start + bytes.toLong() * 1_000_000_000L / limit
        return (start - now) / 1_000_000L
    }

    suspend fun acquire(bytes: Int) {
        val wait = reserve(bytes)
        if (wait > 0L) delay(wait)
    }
}

// ---------- মূল ইঞ্জিন ----------

object Engine {
    private const val MAX_PARTS = 8
    private const val MIN_PART_BYTES = 2L * 1024 * 1024
    private const val MAX_RETRIES = 5
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"

    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items

    // HTTP/1.1 জোর করে দেওয়া হয়েছে, যাতে প্রতিটা পার্ট আলাদা কানেকশন পায় (HTTP/2 হলে সব এক কানেকশনে চলে যেত)
    private val client = OkHttpClient.Builder()
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private class Active {
        @Volatile var job: Job? = null
        @Volatile var cancelRequested = false
        val calls = CopyOnWriteArraySet<Call>()

        fun cancelAll() {
            job?.cancel()
            calls.forEach { it.cancel() }
        }
    }

    private val actives = ConcurrentHashMap<String, Active>()

    private class Probe(val name: String, val total: Long, val ranges: Boolean, val mime: String, val hls: Boolean)

    // ---------- শুরু ----------

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        _items.value = load().map {
            // অ্যাপ বন্ধ হওয়ার আগে চলমান থাকা ডাউনলোডগুলো Paused অবস্থায় ফিরবে
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING)
                it.copy(status = Status.PAUSED, speedBps = 0L)
            else it
        }
        Limiter.bytesPerSec = Settings.state.value.speedLimitKb * 1024L
        registerNetworkWatcher()
        // প্রতি ৩০ সেকেন্ডে শিডিউল/নেটওয়ার্ক অবস্থা মিলিয়ে দেখা
        scope.launch {
            while (true) {
                delay(30_000)
                reevaluate()
            }
        }
        scope.launch { reevaluate() }
    }

    fun onSettingsChanged() {
        Limiter.bytesPerSec = Settings.state.value.speedLimitKb * 1024L
        scope.launch { reevaluate() }
    }

    // ---------- Wi-Fi ও শিডিউল ----------

    private fun registerNetworkWatcher() {
        try {
            val cm = appContext.getSystemService(ConnectivityManager::class.java)
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    scope.launch { reevaluate() }
                }

                override fun onLost(network: Network) {
                    scope.launch { reevaluate() }
                }

                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    scope.launch { reevaluate() }
                }
            })
        } catch (e: Exception) {
            // নেটওয়ার্ক নজরদারি চালু না হলে ৩০ সেকেন্ডের টিকারই কাজ চালাবে
        }
    }

    private fun onWifi(): Boolean {
        return try {
            val cm = appContext.getSystemService(ConnectivityManager::class.java)
            val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        } catch (e: Exception) {
            false
        }
    }

    private fun inSchedule(s: AppSettings): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val a = s.scheduleStartMin
        val b = s.scheduleEndMin
        return when {
            a == b -> true
            a < b -> now >= a && now < b
            else -> now >= a || now < b // রাত পেরিয়ে যাওয়া সময় (যেমন 23:00–06:00)
        }
    }

    // এখন ডাউনলোড চালানো যাবে না হলে কারণ ফেরত দেয়, চালানো যাবে হলে null
    private fun blockReason(): String? {
        val s = Settings.state.value
        if (s.wifiOnly && !onWifi()) return "wifi"
        if (s.scheduleEnabled && !inSchedule(s)) return "schedule"
        return null
    }

    private fun maxParallel(): Int = Settings.state.value.maxParallel.coerceAtLeast(1)

    // এখন কয়টা ডাউনলোড সত্যিই চলছে (কিউর সীমা মাপার জন্য)
    private fun runningCount(except: String? = null): Int = _items.value.count {
        it.id != except &&
            (it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING)
    }

    @Synchronized
    private fun reevaluate() {
        val reason = blockReason()
        if (reason != null) {
            for (item in _items.value) {
                if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED) {
                    holdForReason(item.id, reason)
                } else if (item.status == Status.WAITING && item.waitReason != reason) {
                    update(item.id) { it.copy(waitReason = reason) }
                }
            }
            return
        }
        // কিউ: সবচেয়ে পুরনো যোগ করা ডাউনলোড আগে চলবে (তালিকায় নতুনটা উপরে থাকে, তাই উল্টো দিক থেকে)
        for (item in _items.value.asReversed()) {
            if (item.status != Status.WAITING) continue
            if (runningCount() < maxParallel()) {
                start(item.id)
            } else if (item.waitReason != "queue") {
                update(item.id) { it.copy(waitReason = "queue") }
            }
        }
    }

    @Synchronized
    private fun holdForReason(id: String, reason: String) {
        val a = actives[id]
        if (a != null) {
            a.cancelRequested = true
            scope.launch { a.cancelAll() }
        }
        update(id) { it.copy(status = Status.WAITING, waitReason = reason, speedBps = 0L) }
        saveAsync()
    }

    // ---------- UI থেকে ডাকা ফাংশন ----------

    @Synchronized
    fun add(
        rawUrl: String,
        referer: String? = null,
        cookie: String? = null,
        userAgent: String? = null,
        name: String? = null
    ): Boolean {
        val url = rawUrl.trim()
        val http = url.toHttpUrlOrNull() ?: return false
        val custom = !name.isNullOrBlank()
        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            url = http.toString(),
            fileName = if (custom) cleanName(name ?: "") else nameFromUrl(url),
            referer = referer,
            cookie = cookie,
            userAgent = userAgent,
            isHls = http.encodedPath.lowercase().endsWith(".m3u8"),
            nameLocked = custom
        )
        _items.update { listOf(item) + it }
        saveAsync()
        start(item.id)
        return true
    }

    // একই লিংক আগে থেকে তালিকায় আছে কিনা
    fun exists(rawUrl: String): Boolean {
        val u = rawUrl.trim().toHttpUrlOrNull()?.toString() ?: return false
        return _items.value.any { it.url == u }
    }

    // ফাইলের নাম বদলানো (সম্পূর্ণ হয়ে গেলে ফোনের ফাইলের নামও বদলায়)
    @Synchronized
    fun rename(id: String, newName: String) {
        val item = get(id) ?: return
        var clean = cleanName(newName)
        if (!clean.contains('.')) {
            val ext = item.fileName.substringAfterLast('.', "")
            if (ext.isNotEmpty() && ext.length <= 8) clean = "$clean.$ext"
        }
        if (clean == item.fileName) return
        update(id) { it.copy(fileName = clean, nameLocked = true) }
        saveAsync()
        val uriStr = item.savedUri
        if (item.status == Status.COMPLETED && uriStr != null) {
            scope.launch {
                var ok = false
                try {
                    val v = ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME, clean) }
                    ok = appContext.contentResolver.update(Uri.parse(uriStr), v, null, null) > 0
                } catch (e: Exception) {
                    ok = false
                }
                if (!ok) {
                    update(id) { it.copy(fileName = item.fileName) }
                    save()
                }
            }
        }
    }

    @Synchronized
    fun pause(id: String) {
        val a = actives[id]
        if (a != null) {
            a.cancelRequested = true
            scope.launch { a.cancelAll() }
        }
        update(id) {
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED ||
                it.status == Status.SAVING || it.status == Status.WAITING
            ) it.copy(status = Status.PAUSED, waitReason = null, speedBps = 0L)
            else it
        }
        saveAsync()
        scope.launch { reevaluate() } // জায়গা খালি হলে কিউর পরের ডাউনলোড শুরু হবে
    }

    @Synchronized
    fun resume(id: String) {
        val item = get(id) ?: return
        if (item.status == Status.PAUSED || item.status == Status.FAILED) start(id)
    }

    // সব চলমান/অপেক্ষমান ডাউনলোড থামানো
    fun pauseAll() {
        for (item in _items.value) {
            if (item.status == Status.DOWNLOADING || item.status == Status.QUEUED ||
                item.status == Status.SAVING || item.status == Status.WAITING
            ) pause(item.id)
        }
    }

    // থামানো বা ব্যর্থ সব ডাউনলোড আবার চালু করা
    fun resumeAll() {
        for (item in _items.value) {
            if (item.status == Status.PAUSED || item.status == Status.FAILED) resume(item.id)
        }
    }

    // সম্পূর্ণ হওয়া সব এন্ট্রি তালিকা থেকে সরানো (ডাউনলোড হওয়া ফাইল থেকে যাবে)
    fun clearCompleted() {
        for (item in _items.value) {
            if (item.status == Status.COMPLETED) remove(item.id)
        }
    }

    @Synchronized
    fun remove(id: String) {
        val a = actives[id]
        if (a != null) {
            a.cancelRequested = true
            scope.launch { a.cancelAll() }
        }
        val item = get(id)
        _items.update { list -> list.filterNot { it.id == id } }
        scope.launch {
            a?.job?.join()
            if (item != null && item.status != Status.COMPLETED) {
                tmpFile(id).delete()
                hlsDir(id).deleteRecursively()
            }
            save()
            reevaluate()
        }
    }

    // ---------- ডাউনলোড চালু ----------

    @Synchronized
    private fun start(id: String) {
        val prev = actives[id]
        if (prev != null && !prev.cancelRequested) return // আগে থেকেই চলছে

        val reason = blockReason()
        if (reason != null) {
            // Wi-Fi নেই বা শিডিউলের সময় না হলে অপেক্ষায় থাকবে (সার্ভিস চালু রেখে)
            update(id) { it.copy(status = Status.WAITING, waitReason = reason, error = null, speedBps = 0L) }
            saveAsync()
            startService()
            return
        }

        if (runningCount(id) >= maxParallel()) {
            // একসাথে চলার সীমা পূর্ণ: কিউতে অপেক্ষা (নিজেকে গুনবে না)
            update(id) { it.copy(status = Status.WAITING, waitReason = "queue", error = null, speedBps = 0L) }
            saveAsync()
            startService()
            return
        }

        val active = Active()
        actives[id] = active
        update(id) { it.copy(status = Status.QUEUED, error = null, speedBps = 0L) }
        active.job = scope.launch {
            prev?.job?.join() // আগের (থামানো) কাজ পুরোপুরি শেষ হওয়া পর্যন্ত অপেক্ষা
            execute(id, active)
        }
        startService()
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, DownloadService::class.java))
        } catch (e: Exception) {
            // ব্যাকগ্রাউন্ড থেকে শুরু করা না গেলে ডাউনলোড তবুও চলবে, শুধু নোটিফিকেশন থাকবে না
        }
    }

    private suspend fun execute(id: String, active: Active) {
        var counters: AtomicLongArray? = null
        try {
            if (get(id) == null) return
            setStatus(id, active, Status.DOWNLOADING)

            // ১) প্রথমবার হলে ফাইলের সাইজ, নাম আর Range সাপোর্ট জেনে নেওয়া
            var item = get(id) ?: return
            if (item.isHls) {
                runHls(id, item, active)
                return
            }
            if (item.partProgress.isEmpty()) {
                val p = probe(item, active)
                if (p.hls) {
                    // লিংকটা আসলে HLS প্লেলিস্ট
                    update(id) { it.copy(isHls = true) }
                    runHls(id, get(id) ?: return, active)
                    return
                }
                val parts =
                    if (p.ranges && p.total > 0) (p.total / MIN_PART_BYTES).coerceIn(1L, MAX_PARTS.toLong()).toInt()
                    else 1
                update(id) {
                    it.copy(
                        fileName = if (it.nameLocked) lockedName(it.fileName, p.name) else p.name,
                        totalBytes = p.total,
                        supportsRanges = p.ranges,
                        mimeType = p.mime,
                        partProgress = List(parts) { 0L }
                    )
                }
                save()
                item = get(id) ?: return
            }

            // ২) টেম্প ফাইল ঠিক করা
            val tmp = tmpFile(id)
            val resumable = item.supportsRanges && item.totalBytes > 0
            var progress = item.partProgress
            if (resumable) {
                if (!tmp.exists() || tmp.length() != item.totalBytes) {
                    progress = List(progress.size) { 0L }
                    tmp.delete()
                    val free = tmp.parentFile?.usableSpace ?: Long.MAX_VALUE
                    if (item.totalBytes > free) throw IllegalStateException("Not enough storage space")
                    RandomAccessFile(tmp, "rw").use { it.setLength(item.totalBytes) }
                }
            } else {
                // Range সাপোর্ট না থাকলে Resume সম্ভব না, তাই শুরু থেকে নামাতে হবে
                progress = listOf(0L)
                tmp.delete()
            }

            val parts = progress.size
            val c = AtomicLongArray(parts)
            for (i in 0 until parts) c.set(i, progress[i])
            counters = c
            flush(id, c)

            val partSize = if (resumable) (item.totalBytes + parts - 1) / parts else 0L
            val snapshot = item

            // ৩) সব পার্ট একসাথে নামানো
            coroutineScope {
                val ticker = launch { tick(id, c) }
                val workers = (0 until parts).map { i ->
                    async { downloadPart(snapshot, resumable, tmp, i, partSize, c, active) }
                }
                workers.awaitAll()
                ticker.cancel()
            }
            flush(id, c)

            // ৪) Downloads ফোল্ডারে সেভ
            setStatus(id, active, Status.SAVING)
            val finalItem = get(id) ?: return
            val saved = saveToDownloads(finalItem, tmp)
            tmp.delete()

            var sum = 0L
            for (i in 0 until parts) sum += c.get(i)
            update(id) {
                val total = if (it.totalBytes > 0) it.totalBytes else sum
                it.copy(
                    status = Status.COMPLETED,
                    savedUri = saved.first.toString(),
                    savedPath = saved.second,
                    totalBytes = total,
                    downloadedBytes = total,
                    speedBps = 0L,
                    error = null
                )
            }
            save()
            notifyFinished(id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            if (actives[id] === active && !active.cancelRequested) {
                update(id) {
                    it.copy(status = Status.FAILED, error = e.message ?: e.javaClass.simpleName, speedBps = 0L)
                }
                notifyFinished(id)
            }
        } finally {
            counters?.let { flush(id, it) }
            save()
            actives.remove(id, active)
            scope.launch { reevaluate() } // শেষ বা থামলে কিউর পরের ডাউনলোড শুরু
        }
    }

    // ---------- নেটওয়ার্ক ----------

    // ডাউনলোডের সব রিকোয়েস্টে একই হেডার যায় (ব্রাউজার থেকে এলে Referer ও Cookie সহ)
    private fun Request.Builder.applyHeaders(item: DownloadItem): Request.Builder {
        header("User-Agent", item.userAgent ?: UA)
        header("Accept-Encoding", "identity")
        item.referer?.let { header("Referer", it) }
        item.cookie?.let { header("Cookie", it) }
        return this
    }

    private fun checkHttp(resp: Response) {
        if (resp.isSuccessful) return
        val c = resp.code
        if (c == 408 || c == 429 || c in 500..599) throw IOException("HTTP $c") // আবার চেষ্টা করা হবে
        throw IllegalStateException("HTTP $c") // 404, 403 ইত্যাদিতে আবার চেষ্টা করে লাভ নেই
    }

    private fun probe(item: DownloadItem, active: Active): Probe {
        val req = Request.Builder()
            .url(item.url)
            .applyHeaders(item)
            .header("Range", "bytes=0-0")
            .build()
        val call = client.newCall(req)
        active.calls.add(call)
        return try {
            call.execute().use { resp ->
                checkHttp(resp)
                var total = -1L
                var ranges = false
                if (resp.code == 206) {
                    val t = resp.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull()
                    if (t != null && t > 0) {
                        total = t
                        ranges = true
                    }
                } else {
                    total = resp.body?.contentLength() ?: -1L
                }
                val ct = resp.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
                var name = cleanName(
                    nameFromDisposition(resp.header("Content-Disposition"))
                        ?: nameFromUrl(resp.request.url.toString())
                )
                if (!name.contains('.') && ct != null) {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(ct)
                    if (ext != null) name = "$name.$ext"
                }
                val mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                    ?: ct
                    ?: "application/octet-stream"
                Probe(name, total, ranges, mime, ct != null && ct.contains("mpegurl"))
            }
        } finally {
            active.calls.remove(call)
        }
    }

    private suspend fun downloadPart(
        item: DownloadItem,
        resumable: Boolean,
        tmp: File,
        index: Int,
        partSize: Long,
        counters: AtomicLongArray,
        active: Active
    ) {
        val start = if (resumable) index * partSize else 0L
        val end = if (resumable) minOf(item.totalBytes - 1, start + partSize - 1) else -1L
        var attempt = 0
        while (true) {
            if (!resumable) counters.set(index, 0L)
            val from = start + counters.get(index)
            if (resumable && from > end) return // এই পার্ট আগেই শেষ
            try {
                val builder = Request.Builder()
                    .url(item.url)
                    .applyHeaders(item)
                if (resumable) builder.header("Range", "bytes=$from-$end")
                val call = client.newCall(builder.build())
                active.calls.add(call)
                try {
                    call.execute().use { resp ->
                        checkHttp(resp)
                        if (resumable && resp.code != 206) {
                            throw IllegalStateException("Server stopped supporting ranges (HTTP ${resp.code})")
                        }
                        val body = resp.body ?: throw IOException("Empty response")
                        RandomAccessFile(tmp, "rw").use { raf ->
                            if (!resumable) raf.setLength(0)
                            raf.seek(from)
                            val buf = ByteArray(64 * 1024)
                            body.byteStream().use { input ->
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    val limit = Limiter.bytesPerSec
                                    val maxRead = if (limit > 0L) (limit / 8).coerceIn(2048L, 65536L).toInt() else buf.size
                                    var n = input.read(buf, 0, maxRead)
                                    if (n < 0) break
                                    if (resumable) {
                                        val remaining = end + 1 - (start + counters.get(index))
                                        if (remaining <= 0) break
                                        if (n > remaining) n = remaining.toInt()
                                    }
                                    raf.write(buf, 0, n)
                                    counters.addAndGet(index, n.toLong())
                                    Limiter.acquire(n)
                                }
                            }
                        }
                    }
                } finally {
                    active.calls.remove(call)
                }
                if (resumable && start + counters.get(index) <= end) throw IOException("Connection closed early")
                if (!resumable && item.totalBytes > 0 && counters.get(index) != item.totalBytes) {
                    throw IOException("Connection closed early")
                }
                return
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive() // থামানো হলে এখানেই বের হয়ে যাবে
                attempt++
                if (attempt > MAX_RETRIES) throw e
                delay(minOf(16000L, 1000L shl (attempt - 1))) // 1s, 2s, 4s, 8s, 16s
            }
        }
    }

    // প্রতি আধা সেকেন্ডে UI-র জন্য প্রগ্রেস ও স্পিড হিসাব করে
    private suspend fun tick(id: String, c: AtomicLongArray) {
        var lastSum = 0L
        for (i in 0 until c.length()) lastSum += c.get(i)
        var lastTime = System.nanoTime()
        var speed = 0.0
        var lastSave = System.currentTimeMillis()
        while (true) {
            delay(500)
            val now = System.nanoTime()
            val parts = List(c.length()) { c.get(it) }
            val sum = parts.sum()
            val dt = (now - lastTime).coerceAtLeast(1L)
            val inst = (sum - lastSum) * 1_000_000_000.0 / dt
            speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
            lastSum = sum
            lastTime = now
            update(id) { it.copy(downloadedBytes = sum, partProgress = parts, speedBps = speed.toLong()) }
            if (System.currentTimeMillis() - lastSave > 2000) {
                save()
                lastSave = System.currentTimeMillis()
            }
        }
    }

    // ---------- HLS (.m3u8) ----------

    private class HlsSeg(val url: String, val seq: Long, val keyUri: String?, val iv: ByteArray?)
    private class HlsPlan(val segs: List<HlsSeg>, val initUrl: String?)
    private class Variant(val url: String, val bandwidth: Long, val height: Int)

    private const val HLS_WORKERS = 5

    private fun hlsDir(id: String): File = File(tmpFile(id).parentFile, id + "_hls")

    private fun resolveUrl(base: String, ref: String): String =
        base.toHttpUrlOrNull()?.resolve(ref)?.toString() ?: ref

    // #EXT-X-KEY:METHOD=AES-128,URI="..." এর মতো লাইনের অ্যাট্রিবিউট আলাদা করা
    private fun parseAttrs(text: String): Map<String, String> {
        val m = HashMap<String, String>()
        Regex("([A-Z0-9-]+)=(\"[^\"]*\"|[^,]*)").findAll(text).forEach {
            m[it.groupValues[1]] = it.groupValues[2].trim().trim('"')
        }
        return m
    }

    private fun hexToIv(hex: String): ByteArray {
        var h = hex.trim().removePrefix("0x").removePrefix("0X")
        if (h.length > 32) h = h.takeLast(32)
        h = h.padStart(32, '0')
        return ByteArray(16) { i -> h.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
    }

    // IV না থাকলে সেগমেন্টের ক্রমিক নম্বরই IV (১৬ বাইট, big-endian)
    private fun seqIv(seq: Long): ByteArray {
        val iv = ByteArray(16)
        for (i in 0 until 8) iv[15 - i] = ((seq shr (8 * i)) and 0xFFL).toByte()
        return iv
    }

    private fun fetchText(url: String, item: DownloadItem, active: Active): String {
        val call = client.newCall(Request.Builder().url(url).applyHeaders(item).build())
        active.calls.add(call)
        return try {
            call.execute().use { resp ->
                checkHttp(resp)
                resp.body?.string() ?: throw IOException("Empty playlist")
            }
        } finally {
            active.calls.remove(call)
        }
    }

    private fun fetchBytes(url: String, item: DownloadItem, active: Active): ByteArray {
        val call = client.newCall(Request.Builder().url(url).applyHeaders(item).build())
        active.calls.add(call)
        return try {
            call.execute().use { resp ->
                checkHttp(resp)
                resp.body?.bytes() ?: throw IOException("Empty response")
            }
        } finally {
            active.calls.remove(call)
        }
    }

    // মাস্টার প্লেলিস্ট থেকে সেটিংসের কোয়ালিটি অনুযায়ী একটা ভ্যারিয়েন্ট বাছা
    private fun pickVariant(master: String, base: String, quality: Int): String {
        val lines = master.lines()
        val vars = ArrayList<Variant>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i].trim()
            if (l.startsWith("#EXT-X-STREAM-INF:")) {
                val a = parseAttrs(l.substringAfter(':'))
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].trim().startsWith("#"))) j++
                if (j < lines.size) {
                    val bw = a["BANDWIDTH"]?.toLongOrNull() ?: 0L
                    val h = a["RESOLUTION"]?.substringAfter('x', "")?.toIntOrNull() ?: 0
                    vars.add(Variant(resolveUrl(base, lines[j].trim()), bw, h))
                }
                i = j
            }
            i++
        }
        if (vars.isEmpty()) throw IllegalStateException("No playable variants in playlist")
        val sorted = vars.sortedBy { it.bandwidth }
        return when (quality) {
            3 -> sorted.first().url
            1, 2 -> {
                val limit = if (quality == 1) 720 else 480
                val ok = sorted.filter { it.height in 1..limit }
                if (ok.isNotEmpty()) ok.last().url
                else if (vars.any { it.height > 0 }) sorted.first().url
                else sorted.last().url
            }
            else -> sorted.last().url
        }
    }

    private fun parseMedia(text: String, base: String): HlsPlan {
        var mediaSeq = 0L
        var keyUri: String? = null
        var keyIv: ByteArray? = null
        var initUrl: String? = null
        var ended = false
        val segs = ArrayList<HlsSeg>()
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.isEmpty()) continue
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                mediaSeq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
            } else if (l.startsWith("#EXT-X-KEY:")) {
                val a = parseAttrs(l.substringAfter(':'))
                val method = a["METHOD"]
                if (method == "NONE") {
                    keyUri = null
                    keyIv = null
                } else if (method == "AES-128") {
                    val u = a["URI"] ?: throw IllegalStateException("Encrypted stream without key URI")
                    keyUri = resolveUrl(base, u)
                    val ivHex = a["IV"]
                    keyIv = if (ivHex != null) hexToIv(ivHex) else null
                } else {
                    throw IllegalStateException("Unsupported stream encryption ($method)")
                }
            } else if (l.startsWith("#EXT-X-MAP:")) {
                val a = parseAttrs(l.substringAfter(':'))
                if (a.containsKey("BYTERANGE")) throw IllegalStateException("Byte-range streams are not supported")
                val u = a["URI"]
                if (u != null) initUrl = resolveUrl(base, u)
            } else if (l.startsWith("#EXT-X-BYTERANGE")) {
                throw IllegalStateException("Byte-range streams are not supported")
            } else if (l.startsWith("#EXT-X-ENDLIST")) {
                ended = true
            } else if (!l.startsWith("#")) {
                segs.add(HlsSeg(resolveUrl(base, l), mediaSeq + segs.size, keyUri, keyIv))
            }
        }
        if (!ended) throw IllegalStateException("Live streams are not supported")
        if (segs.isEmpty()) throw IllegalStateException("Playlist has no segments")
        return HlsPlan(segs, initUrl)
    }

    // একটা সেগমেন্ট ফাইলে নামানো (এনক্রিপ্টেড হলে সাথে সাথে ডিক্রিপ্ট করে লেখা)
    private suspend fun downloadSegment(
        item: DownloadItem,
        url: String,
        dest: File,
        key: ByteArray?,
        iv: ByteArray?,
        active: Active,
        bytesDone: AtomicLong
    ) {
        val part = File(dest.parentFile, dest.name + ".part")
        var attempt = 0
        while (true) {
            var counted = 0L
            try {
                val call = client.newCall(Request.Builder().url(url).applyHeaders(item).build())
                active.calls.add(call)
                try {
                    call.execute().use { resp ->
                        checkHttp(resp)
                        val body = resp.body ?: throw IOException("Empty response")
                        val fos = FileOutputStream(part)
                        val out: OutputStream = if (key != null && iv != null) {
                            val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
                            CipherOutputStream(fos, cipher)
                        } else fos
                        out.use { o ->
                            val buf = ByteArray(32 * 1024)
                            body.byteStream().use { input ->
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    val limit = Limiter.bytesPerSec
                                    val maxRead =
                                        if (limit > 0L) (limit / 8).coerceIn(2048L, 32768L).toInt() else buf.size
                                    val n = input.read(buf, 0, maxRead)
                                    if (n < 0) break
                                    o.write(buf, 0, n)
                                    counted += n
                                    bytesDone.addAndGet(n.toLong())
                                    Limiter.acquire(n)
                                }
                            }
                        }
                    }
                } finally {
                    active.calls.remove(call)
                }
                if (!part.renameTo(dest)) throw IOException("Cannot save segment")
                return
            } catch (e: IOException) {
                bytesDone.addAndGet(-counted)
                currentCoroutineContext().ensureActive()
                attempt++
                if (attempt > MAX_RETRIES) throw e
                delay(minOf(16000L, 1000L shl (attempt - 1)))
            }
        }
    }

    private suspend fun tickHls(id: String, bytes: AtomicLong, segDone: AtomicInteger, segTotal: Int) {
        var lastBytes = bytes.get()
        var lastTime = System.nanoTime()
        var speed = 0.0
        var lastSave = System.currentTimeMillis()
        while (true) {
            delay(500)
            val now = System.nanoTime()
            val b = bytes.get()
            val sd = segDone.get()
            val dt = (now - lastTime).coerceAtLeast(1L)
            val inst = (b - lastBytes) * 1_000_000_000.0 / dt
            speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
            lastBytes = b
            lastTime = now
            // মোট সাইজ আন্দাজ: এ পর্যন্ত নামা সাইজ ÷ নামা সেগমেন্ট × মোট সেগমেন্ট
            val est = if (sd > 0) b * segTotal / sd else -1L
            update(id) {
                it.copy(
                    downloadedBytes = b,
                    totalBytes = if (est > 0) maxOf(est, b) else it.totalBytes,
                    segDone = sd,
                    speedBps = speed.toLong()
                )
            }
            if (System.currentTimeMillis() - lastSave > 2000) {
                save()
                lastSave = System.currentTimeMillis()
            }
        }
    }

    private suspend fun runHls(id: String, itemIn: DownloadItem, active: Active) {
        var item = itemIn

        // ১) প্লেলিস্ট আনা; মাস্টার হলে কোয়ালিটি অনুযায়ী ভ্যারিয়েন্ট বাছা
        var playlistUrl = item.url
        var text = fetchText(playlistUrl, item, active)
        if (!text.contains("#EXTM3U")) throw IllegalStateException("Not a valid HLS playlist")
        if (text.contains("#EXT-X-STREAM-INF")) {
            playlistUrl = pickVariant(text, playlistUrl, Settings.state.value.hlsQuality)
            text = fetchText(playlistUrl, item, active)
        }
        val plan = parseMedia(text, playlistUrl)

        // ২) ফাইলের নাম ও টাইপ ঠিক করা (সাধারণ স্ট্রিম .ts, fMP4 হলে .mp4)
        val fmp4 = plan.initUrl != null
        val ext = if (fmp4) "mp4" else "ts"
        val mime = if (fmp4) "video/mp4" else "video/mp2t"
        val generic = setOf("index", "playlist", "master", "chunklist", "stream", "video", "manifest", "main")
        val base = item.fileName.substringBeforeLast('.', item.fileName)
        val finalName = when {
            item.nameLocked && item.fileName.contains('.') -> item.fileName
            item.nameLocked -> item.fileName + "." + ext
            base.lowercase() in generic -> "video-" + id.take(4) + "." + ext
            else -> cleanName("$base.$ext")
        }
        update(id) {
            it.copy(
                fileName = finalName,
                mimeType = mime,
                supportsRanges = false,
                partProgress = listOf(0L),
                segTotal = plan.segs.size,
                isHls = true
            )
        }
        save()
        item = get(id) ?: return

        // ৩) সেগমেন্টের ফোল্ডার; আগে নামানো সম্পূর্ণ সেগমেন্ট থাকলে Resume-এ বাদ যাবে
        val dir = hlsDir(id)
        dir.mkdirs()
        dir.listFiles()?.forEach { if (it.name.endsWith(".part")) it.delete() }
        val bytesDone = AtomicLong(0L)
        val segDone = AtomicInteger(0)
        val initFile = File(dir, "init")
        if (plan.initUrl != null && initFile.exists()) bytesDone.addAndGet(initFile.length())
        for (i in plan.segs.indices) {
            val f = File(dir, "seg_$i")
            if (f.exists()) {
                segDone.incrementAndGet()
                bytesDone.addAndGet(f.length())
            }
        }

        val keyCache = ConcurrentHashMap<String, ByteArray>()
        val snapshot = item

        try {
            coroutineScope {
                val ticker = launch { tickHls(id, bytesDone, segDone, plan.segs.size) }
                if (plan.initUrl != null && !initFile.exists()) {
                    downloadSegment(snapshot, plan.initUrl, initFile, null, null, active, bytesDone)
                }
                val next = AtomicInteger(0)
                val workers = (0 until minOf(HLS_WORKERS, plan.segs.size)).map {
                    async {
                        while (true) {
                            val i = next.getAndIncrement()
                            if (i >= plan.segs.size) break
                            val dest = File(dir, "seg_$i")
                            if (dest.exists()) continue
                            val seg = plan.segs[i]
                            var key: ByteArray? = null
                            if (seg.keyUri != null) {
                                key = keyCache[seg.keyUri] ?: fetchBytes(seg.keyUri, snapshot, active)
                                keyCache[seg.keyUri] = key
                            }
                            val iv = if (key != null) (seg.iv ?: seqIv(seg.seq)) else null
                            downloadSegment(snapshot, seg.url, dest, key, iv, active, bytesDone)
                            segDone.incrementAndGet()
                        }
                    }
                }
                workers.awaitAll()
                ticker.cancel()
            }
        } finally {
            update(id) { it.copy(downloadedBytes = bytesDone.get(), segDone = segDone.get(), speedBps = 0L) }
        }

        // ৪) সেগমেন্টগুলো ক্রমানুসারে জোড়া লাগিয়ে একটা ফাইল বানানো
        setStatus(id, active, Status.SAVING)
        val joined = tmpFile(id)
        joined.delete()
        FileOutputStream(joined).use { o ->
            val buf = ByteArray(256 * 1024)
            val files = ArrayList<File>()
            if (plan.initUrl != null) files.add(initFile)
            for (i in plan.segs.indices) files.add(File(dir, "seg_$i"))
            for (f in files) {
                currentCoroutineContext().ensureActive()
                f.inputStream().use { input ->
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                    }
                }
            }
        }

        // ৫) Downloads ফোল্ডারে সেভ ও পরিষ্কার
        val finalItem = get(id) ?: return
        val saved = saveToDownloads(finalItem, joined)
        val size = joined.length()
        joined.delete()
        dir.deleteRecursively()
        update(id) {
            it.copy(
                status = Status.COMPLETED,
                savedUri = saved.first.toString(),
                savedPath = saved.second,
                totalBytes = size,
                downloadedBytes = size,
                segDone = plan.segs.size,
                speedBps = 0L,
                error = null
            )
        }
        save()
        notifyFinished(id)
    }

    // ---------- Downloads ফোল্ডারে সেভ ----------

    // সেটিংসের "Save location" অনুযায়ী ফোল্ডার ঠিক করা
    private fun relativePathFor(item: DownloadItem): String {
        val root = Environment.DIRECTORY_DOWNLOADS
        return when (Settings.state.value.saveMode) {
            2 -> root
            1 -> root + "/Aether/" + when (kindOf(item.fileName)) {
                FileKind.VIDEO -> "Videos"
                FileKind.AUDIO -> "Music"
                FileKind.IMAGE -> "Images"
                FileKind.ARCHIVE -> "Archives"
                FileKind.DOC -> "Documents"
                FileKind.APK -> "Apps"
                FileKind.OTHER -> "Other"
            }
            else -> root + "/Aether"
        }
    }

    private suspend fun saveToDownloads(item: DownloadItem, tmp: File): Pair<Uri, String> {
        val resolver = appContext.contentResolver
        val relPath = relativePathFor(item)
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, item.fileName)
            put(MediaStore.Downloads.MIME_TYPE, item.mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, relPath)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Cannot create file in Downloads")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Cannot open output file")
            out.use { o ->
                tmp.inputStream().use { input ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                    }
                }
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return Pair(uri, relPath)
    }

    // ---------- ছোট সাহায্যকারী ----------

    private fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    private fun update(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    // শুধু বর্তমান কাজ হলেই স্ট্যাটাস বদলাবে (আগের থামানো কাজ যেন নতুনটার স্ট্যাটাস নষ্ট না করে)
    private fun setStatus(id: String, active: Active, status: Status) {
        if (actives[id] !== active) return
        update(id) { it.copy(status = status, error = null, waitReason = null, speedBps = if (status == Status.DOWNLOADING) it.speedBps else 0L) }
        save()
    }

    private fun flush(id: String, c: AtomicLongArray) {
        val parts = List(c.length()) { c.get(it) }
        update(id) { it.copy(downloadedBytes = parts.sum(), partProgress = parts, speedBps = 0L) }
    }

    private fun tmpFile(id: String): File {
        val base = appContext.getExternalFilesDir(null) ?: appContext.filesDir
        val dir = File(base, "tmp")
        dir.mkdirs()
        return File(dir, "$id.tmp")
    }

    private fun nameFromUrl(url: String): String {
        val seg = url.toHttpUrlOrNull()?.pathSegments?.lastOrNull { it.isNotBlank() }
        val decoded = seg?.let { s -> runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault(s) }
        return cleanName(decoded ?: "download")
    }

    private fun nameFromDisposition(cd: String?): String? {
        if (cd == null) return null
        val star = Regex("filename\\*\\s*=\\s*([^']*)'[^']*'([^;]+)", RegexOption.IGNORE_CASE).find(cd)
        if (star != null) {
            val charset = star.groupValues[1].ifBlank { "UTF-8" }
            val raw = star.groupValues[2].trim().trim('"')
            return runCatching { URLDecoder.decode(raw, charset) }.getOrNull()
        }
        val plain = Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
        return plain?.groupValues?.get(1)?.trim()
    }

    private fun cleanName(raw: String): String {
        var n = raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.')
        if (n.length > 120) {
            val ext = n.substringAfterLast('.', "")
            n = if (ext.length in 1..8) n.take(110) + "." + ext else n.take(120)
        }
        return n.ifBlank { "download" }
    }

    // ব্যবহারকারীর দেওয়া নামে এক্সটেনশন না থাকলে সার্ভারের ফাইলের এক্সটেনশন জুড়ে দেওয়া
    private fun lockedName(user: String, probed: String): String {
        if (user.contains('.')) return user
        val ext = probed.substringAfterLast('.', "")
        return if (ext.isNotEmpty() && ext.length <= 8) "$user.$ext" else user
    }

    // ডাউনলোড শেষ বা ব্যর্থ হলে আলাদা নোটিফিকেশন
    private fun notifyFinished(id: String) {
        try {
            if (!Settings.state.value.notifyDone) return
            val item = get(id) ?: return
            val s = Strings(Settings.state.value.bangla)
            val ok = item.status == Status.COMPLETED
            val tap = if (ok && item.savedUri != null) {
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse(item.savedUri), item.mimeType)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                Intent(appContext, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            val pi = PendingIntent.getActivity(
                appContext,
                item.id.hashCode(),
                tap,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(appContext, DownloadService.DONE_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle(item.fileName)
                .setContentText(if (ok) s.completed(fmtBytes(item.totalBytes)) else s.failedShort(item.error))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
            appContext.getSystemService(NotificationManager::class.java).notify(item.id.hashCode(), n)
        } catch (e: Exception) {
            // নোটিফিকেশন না দেখানো গেলে ডাউনলোডে কোনো ক্ষতি নেই
        }
    }

    // ---------- সেভ / লোড (JSON ফাইল) ----------

    private fun saveAsync() {
        scope.launch { save() }
    }

    @Synchronized
    private fun save() {
        try {
            val arr = JSONArray()
            _items.value.forEach { arr.put(it.toJson()) }
            val f = File(appContext.filesDir, "downloads.json")
            val t = File(appContext.filesDir, "downloads.json.tmp")
            t.writeText(arr.toString())
            if (!t.renameTo(f)) {
                f.delete()
                t.renameTo(f)
            }
        } catch (e: Exception) {
        }
    }

    private fun load(): List<DownloadItem> {
        return try {
            val f = File(appContext.filesDir, "downloads.json")
            if (!f.exists()) emptyList()
            else {
                val arr = JSONArray(f.readText())
                List(arr.length()) { arr.getJSONObject(it).toItem() }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun DownloadItem.toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("url", url)
        o.put("fileName", fileName)
        o.put("total", totalBytes)
        o.put("downloaded", downloadedBytes)
        o.put("parts", JSONArray(partProgress))
        o.put("ranges", supportsRanges)
        o.put("status", status.name)
        o.put("error", error ?: JSONObject.NULL)
        o.put("savedUri", savedUri ?: JSONObject.NULL)
        o.put("mime", mimeType)
        o.put("wait", waitReason ?: JSONObject.NULL)
        o.put("referer", referer ?: JSONObject.NULL)
        o.put("cookie", cookie ?: JSONObject.NULL)
        o.put("ua", userAgent ?: JSONObject.NULL)
        o.put("hls", isHls)
        o.put("segTotal", segTotal)
        o.put("segDone", segDone)
        o.put("nameLocked", nameLocked)
        o.put("path", savedPath ?: JSONObject.NULL)
        return o
    }

    private fun JSONObject.toItem(): DownloadItem {
        val arr = optJSONArray("parts")
        val parts = if (arr == null) emptyList() else List(arr.length()) { arr.getLong(it) }
        return DownloadItem(
            id = getString("id"),
            url = getString("url"),
            fileName = getString("fileName"),
            totalBytes = optLong("total", -1L),
            downloadedBytes = optLong("downloaded", 0L),
            partProgress = parts,
            supportsRanges = optBoolean("ranges", false),
            status = runCatching { Status.valueOf(getString("status")) }.getOrDefault(Status.PAUSED),
            error = if (isNull("error")) null else optString("error"),
            savedUri = if (isNull("savedUri")) null else optString("savedUri"),
            mimeType = optString("mime", "application/octet-stream"),
            waitReason = if (isNull("wait")) null else optString("wait"),
            referer = if (isNull("referer")) null else optString("referer"),
            cookie = if (isNull("cookie")) null else optString("cookie"),
            userAgent = if (isNull("ua")) null else optString("ua"),
            isHls = optBoolean("hls", false),
            segTotal = optInt("segTotal", 0),
            segDone = optInt("segDone", 0),
            nameLocked = optBoolean("nameLocked", false),
            savedPath = if (isNull("path")) null else optString("path")
        )
    }
}
