package com.rdm.pro

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import okhttp3.Call
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.URLDecoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArraySet
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLongArray

enum class Status { QUEUED, DOWNLOADING, PAUSED, SAVING, COMPLETED, FAILED }

data class DownloadItem(
    val id: String,
    val url: String,
    val fileName: String,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val partProgress: List<Long> = emptyList(),
    val supportsRanges: Boolean = false,
    val status: Status = Status.QUEUED,
    val speedBps: Long = 0L,
    val error: String? = null,
    val savedUri: String? = null,
    val mimeType: String = "application/octet-stream"
)

// ---------- ছোট ফরম্যাটিং ফাংশন (UI আর নোটিফিকেশন দুই জায়গায় ব্যবহার হয়) ----------

fun fmtBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = -1
    do {
        v /= 1024.0
        i++
    } while (v >= 1024.0 && i < units.size - 1)
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun fmtEta(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
    else String.format(Locale.US, "%02d:%02d", m, sec)
}

// ---------- মূল ইঞ্জিন ----------

object Engine {
    private const val MAX_PARTS = 8
    private const val MIN_PART_BYTES = 2L * 1024 * 1024
    private const val MAX_RETRIES = 5
    private const val UA =
        "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0 Mobile Safari/537.36"

    private lateinit var appContext: Context
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items

    // HTTP/1.1 জোর করে দেওয়া হয়েছে, যাতে প্রতিটা পার্ট আলাদা কানেকশন পায় (HTTP/2 হলে সব এক কানেকশনে চলে যেত)
    private val client = OkHttpClient.Builder()
        .protocols(listOf(Protocol.HTTP_1_1))
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private class Active {
        @Volatile var job: Job? = null
        @Volatile var cancelRequested = false
        val calls = CopyOnWriteArraySet<Call>()

        fun cancelAll() {
            job?.cancel()
            calls.forEach { it.cancel() }
        }
    }

    private val actives = ConcurrentHashMap<String, Active>()

    private class Probe(val name: String, val total: Long, val ranges: Boolean, val mime: String)

    // ---------- শুরু ----------

    fun init(context: Context) {
        if (::appContext.isInitialized) return
        appContext = context.applicationContext
        _items.value = load().map {
            // অ্যাপ বন্ধ হওয়ার আগে চলমান থাকা ডাউনলোডগুলো Paused অবস্থায় ফিরবে
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING)
                it.copy(status = Status.PAUSED, speedBps = 0L)
            else it
        }
    }

    // ---------- UI থেকে ডাকা ফাংশন ----------

    fun add(rawUrl: String): Boolean {
        val url = rawUrl.trim()
        val http = url.toHttpUrlOrNull() ?: return false
        val item = DownloadItem(id = UUID.randomUUID().toString(), url = http.toString(), fileName = nameFromUrl(url))
        _items.update { listOf(item) + it }
        saveAsync()
        start(item.id)
        return true
    }

    fun pause(id: String) {
        val a = actives[id] ?: return
        a.cancelRequested = true
        update(id) {
            if (it.status == Status.DOWNLOADING || it.status == Status.QUEUED || it.status == Status.SAVING)
                it.copy(status = Status.PAUSED, speedBps = 0L)
            else it
        }
        scope.launch { a.cancelAll() }
    }

    fun resume(id: String) {
        val item = get(id) ?: return
        if (item.status == Status.PAUSED || item.status == Status.FAILED) start(id)
    }

    fun remove(id: String) {
        val a = actives[id]
        if (a != null) {
            a.cancelRequested = true
            scope.launch { a.cancelAll() }
        }
        val item = get(id)
        _items.update { list -> list.filterNot { it.id == id } }
        scope.launch {
            a?.job?.join()
            if (item != null && item.status != Status.COMPLETED) tmpFile(id).delete()
            save()
        }
    }

    // ---------- ডাউনলোড চালু ----------

    private fun start(id: String) {
        val prev = actives[id]
        if (prev != null && !prev.cancelRequested) return // আগে থেকেই চলছে

        val active = Active()
        actives[id] = active
        update(id) { it.copy(status = Status.QUEUED, error = null, speedBps = 0L) }
        active.job = scope.launch {
            prev?.job?.join() // আগের (থামানো) কাজ পুরোপুরি শেষ হওয়া পর্যন্ত অপেক্ষা
            execute(id, active)
        }
        startService()
    }

    private fun startService() {
        try {
            ContextCompat.startForegroundService(appContext, Intent(appContext, DownloadService::class.java))
        } catch (e: Exception) {
            // ব্যাকগ্রাউন্ড থেকে শুরু করা না গেলে ডাউনলোড তবুও চলবে, শুধু নোটিফিকেশন থাকবে না
        }
    }

    private suspend fun execute(id: String, active: Active) {
        var counters: AtomicLongArray? = null
        try {
            if (get(id) == null) return
            setStatus(id, active, Status.DOWNLOADING)

            // ১) প্রথমবার হলে ফাইলের সাইজ, নাম আর Range সাপোর্ট জেনে নেওয়া
            var item = get(id) ?: return
            if (item.partProgress.isEmpty()) {
                val p = probe(item, active)
                val parts =
                    if (p.ranges && p.total > 0) (p.total / MIN_PART_BYTES).coerceIn(1L, MAX_PARTS.toLong()).toInt()
                    else 1
                update(id) {
                    it.copy(
                        fileName = p.name,
                        totalBytes = p.total,
                        supportsRanges = p.ranges,
                        mimeType = p.mime,
                        partProgress = List(parts) { 0L }
                    )
                }
                save()
                item = get(id) ?: return
            }

            // ২) টেম্প ফাইল ঠিক করা
            val tmp = tmpFile(id)
            val resumable = item.supportsRanges && item.totalBytes > 0
            var progress = item.partProgress
            if (resumable) {
                if (!tmp.exists() || tmp.length() != item.totalBytes) {
                    progress = List(progress.size) { 0L }
                    tmp.delete()
                    val free = tmp.parentFile?.usableSpace ?: Long.MAX_VALUE
                    if (item.totalBytes > free) throw IllegalStateException("Not enough storage space")
                    RandomAccessFile(tmp, "rw").use { it.setLength(item.totalBytes) }
                }
            } else {
                // Range সাপোর্ট না থাকলে Resume সম্ভব না, তাই শুরু থেকে নামাতে হবে
                progress = listOf(0L)
                tmp.delete()
            }

            val parts = progress.size
            val c = AtomicLongArray(parts)
            for (i in 0 until parts) c.set(i, progress[i])
            counters = c
            flush(id, c)

            val partSize = if (resumable) (item.totalBytes + parts - 1) / parts else 0L
            val snapshot = item

            // ৩) সব পার্ট একসাথে নামানো
            coroutineScope {
                val ticker = launch { tick(id, c) }
                val workers = (0 until parts).map { i ->
                    async { downloadPart(snapshot, resumable, tmp, i, partSize, c, active) }
                }
                workers.awaitAll()
                ticker.cancel()
            }
            flush(id, c)

            // ৪) Downloads ফোল্ডারে সেভ
            setStatus(id, active, Status.SAVING)
            val finalItem = get(id) ?: return
            val uri = saveToDownloads(finalItem, tmp)
            tmp.delete()

            var sum = 0L
            for (i in 0 until parts) sum += c.get(i)
            update(id) {
                val total = if (it.totalBytes > 0) it.totalBytes else sum
                it.copy(
                    status = Status.COMPLETED,
                    savedUri = uri.toString(),
                    totalBytes = total,
                    downloadedBytes = total,
                    speedBps = 0L,
                    error = null
                )
            }
            save()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            if (actives[id] === active) {
                update(id) {
                    it.copy(status = Status.FAILED, error = e.message ?: e.javaClass.simpleName, speedBps = 0L)
                }
            }
        } finally {
            counters?.let { flush(id, it) }
            save()
            actives.remove(id, active)
        }
    }

    // ---------- নেটওয়ার্ক ----------

    private fun checkHttp(resp: Response) {
        if (resp.isSuccessful) return
        val c = resp.code
        if (c == 408 || c == 429 || c in 500..599) throw IOException("HTTP $c") // আবার চেষ্টা করা হবে
        throw IllegalStateException("HTTP $c") // 404, 403 ইত্যাদিতে আবার চেষ্টা করে লাভ নেই
    }

    private fun probe(item: DownloadItem, active: Active): Probe {
        val req = Request.Builder()
            .url(item.url)
            .header("User-Agent", UA)
            .header("Accept-Encoding", "identity")
            .header("Range", "bytes=0-0")
            .build()
        val call = client.newCall(req)
        active.calls.add(call)
        return try {
            call.execute().use { resp ->
                checkHttp(resp)
                var total = -1L
                var ranges = false
                if (resp.code == 206) {
                    val t = resp.header("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull()
                    if (t != null && t > 0) {
                        total = t
                        ranges = true
                    }
                } else {
                    total = resp.body?.contentLength() ?: -1L
                }
                val ct = resp.header("Content-Type")?.substringBefore(';')?.trim()?.lowercase()
                var name = cleanName(
                    nameFromDisposition(resp.header("Content-Disposition"))
                        ?: nameFromUrl(resp.request.url.toString())
                )
                if (!name.contains('.') && ct != null) {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(ct)
                    if (ext != null) name = "$name.$ext"
                }
                val mime = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
                    ?: ct
                    ?: "application/octet-stream"
                Probe(name, total, ranges, mime)
            }
        } finally {
            active.calls.remove(call)
        }
    }

    private suspend fun downloadPart(
        item: DownloadItem,
        resumable: Boolean,
        tmp: File,
        index: Int,
        partSize: Long,
        counters: AtomicLongArray,
        active: Active
    ) {
        val start = if (resumable) index * partSize else 0L
        val end = if (resumable) minOf(item.totalBytes - 1, start + partSize - 1) else -1L
        var attempt = 0
        while (true) {
            if (!resumable) counters.set(index, 0L)
            val from = start + counters.get(index)
            if (resumable && from > end) return // এই পার্ট আগেই শেষ
            try {
                val builder = Request.Builder()
                    .url(item.url)
                    .header("User-Agent", UA)
                    .header("Accept-Encoding", "identity")
                if (resumable) builder.header("Range", "bytes=$from-$end")
                val call = client.newCall(builder.build())
                active.calls.add(call)
                try {
                    call.execute().use { resp ->
                        checkHttp(resp)
                        if (resumable && resp.code != 206) {
                            throw IllegalStateException("Server stopped supporting ranges (HTTP ${resp.code})")
                        }
                        val body = resp.body ?: throw IOException("Empty response")
                        RandomAccessFile(tmp, "rw").use { raf ->
                            if (!resumable) raf.setLength(0)
                            raf.seek(from)
                            val buf = ByteArray(64 * 1024)
                            body.byteStream().use { input ->
                                while (true) {
                                    currentCoroutineContext().ensureActive()
                                    var n = input.read(buf)
                                    if (n < 0) break
                                    if (resumable) {
                                        val remaining = end + 1 - (start + counters.get(index))
                                        if (remaining <= 0) break
                                        if (n > remaining) n = remaining.toInt()
                                    }
                                    raf.write(buf, 0, n)
                                    counters.addAndGet(index, n.toLong())
                                }
                            }
                        }
                    }
                } finally {
                    active.calls.remove(call)
                }
                if (resumable && start + counters.get(index) <= end) throw IOException("Connection closed early")
                if (!resumable && item.totalBytes > 0 && counters.get(index) != item.totalBytes) {
                    throw IOException("Connection closed early")
                }
                return
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive() // থামানো হলে এখানেই বের হয়ে যাবে
                attempt++
                if (attempt > MAX_RETRIES) throw e
                delay(minOf(16000L, 1000L shl (attempt - 1))) // 1s, 2s, 4s, 8s, 16s
            }
        }
    }

    // প্রতি আধা সেকেন্ডে UI-র জন্য প্রগ্রেস ও স্পিড হিসাব করে
    private suspend fun tick(id: String, c: AtomicLongArray) {
        var lastSum = 0L
        for (i in 0 until c.length()) lastSum += c.get(i)
        var lastTime = System.nanoTime()
        var speed = 0.0
        var lastSave = System.currentTimeMillis()
        while (true) {
            delay(500)
            val now = System.nanoTime()
            val parts = List(c.length()) { c.get(it) }
            val sum = parts.sum()
            val dt = (now - lastTime).coerceAtLeast(1L)
            val inst = (sum - lastSum) * 1_000_000_000.0 / dt
            speed = if (speed == 0.0) inst else speed * 0.7 + inst * 0.3
            lastSum = sum
            lastTime = now
            update(id) { it.copy(downloadedBytes = sum, partProgress = parts, speedBps = speed.toLong()) }
            if (System.currentTimeMillis() - lastSave > 2000) {
                save()
                lastSave = System.currentTimeMillis()
            }
        }
    }

    // ---------- Downloads ফোল্ডারে সেভ ----------

    private suspend fun saveToDownloads(item: DownloadItem, tmp: File): Uri {
        val resolver = appContext.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, item.fileName)
            put(MediaStore.Downloads.MIME_TYPE, item.mimeType)
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/RDM Pro")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("Cannot create file in Downloads")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Cannot open output file")
            out.use { o ->
                tmp.inputStream().use { input ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n)
                    }
                }
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Throwable) {
            runCatching { resolver.delete(uri, null, null) }
            throw e
        }
        return uri
    }

    // ---------- ছোট সাহায্যকারী ----------

    private fun get(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    private fun update(id: String, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
    }

    // শুধু বর্তমান কাজ হলেই স্ট্যাটাস বদলাবে (আগের থামানো কাজ যেন নতুনটার স্ট্যাটাস নষ্ট না করে)
    private fun setStatus(id: String, active: Active, status: Status) {
        if (actives[id] !== active) return
        update(id) { it.copy(status = status, error = null, speedBps = if (status == Status.DOWNLOADING) it.speedBps else 0L) }
        save()
    }

    private fun flush(id: String, c: AtomicLongArray) {
        val parts = List(c.length()) { c.get(it) }
        update(id) { it.copy(downloadedBytes = parts.sum(), partProgress = parts, speedBps = 0L) }
    }

    private fun tmpFile(id: String): File {
        val base = appContext.getExternalFilesDir(null) ?: appContext.filesDir
        val dir = File(base, "tmp")
        dir.mkdirs()
        return File(dir, "$id.tmp")
    }

    private fun nameFromUrl(url: String): String {
        val seg = url.toHttpUrlOrNull()?.pathSegments?.lastOrNull { it.isNotBlank() }
        val decoded = seg?.let { s -> runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault(s) }
        return cleanName(decoded ?: "download")
    }

    private fun nameFromDisposition(cd: String?): String? {
        if (cd == null) return null
        val star = Regex("filename\\*\\s*=\\s*([^']*)'[^']*'([^;]+)", RegexOption.IGNORE_CASE).find(cd)
        if (star != null) {
            val charset = star.groupValues[1].ifBlank { "UTF-8" }
            val raw = star.groupValues[2].trim().trim('"')
            return runCatching { URLDecoder.decode(raw, charset) }.getOrNull()
        }
        val plain = Regex("filename\\s*=\\s*\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(cd)
        return plain?.groupValues?.get(1)?.trim()
    }

    private fun cleanName(raw: String): String {
        var n = raw.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.')
        if (n.length > 120) {
            val ext = n.substringAfterLast('.', "")
            n = if (ext.length in 1..8) n.take(110) + "." + ext else n.take(120)
        }
        return n.ifBlank { "download" }
    }

    // ---------- সেভ / লোড (JSON ফাইল) ----------

    private fun saveAsync() {
        scope.launch { save() }
    }

    @Synchronized
    private fun save() {
        try {
            val arr = JSONArray()
            _items.value.forEach { arr.put(it.toJson()) }
            val f = File(appContext.filesDir, "downloads.json")
            val t = File(appContext.filesDir, "downloads.json.tmp")
            t.writeText(arr.toString())
            if (!t.renameTo(f)) {
                f.delete()
                t.renameTo(f)
            }
        } catch (e: Exception) {
        }
    }

    private fun load(): List<DownloadItem> {
        return try {
            val f = File(appContext.filesDir, "downloads.json")
            if (!f.exists()) emptyList()
            else {
                val arr = JSONArray(f.readText())
                List(arr.length()) { arr.getJSONObject(it).toItem() }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun DownloadItem.toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("url", url)
        o.put("fileName", fileName)
        o.put("total", totalBytes)
        o.put("downloaded", downloadedBytes)
        o.put("parts", JSONArray(partProgress))
        o.put("ranges", supportsRanges)
        o.put("status", status.name)
        o.put("error", error ?: JSONObject.NULL)
        o.put("savedUri", savedUri ?: JSONObject.NULL)
        o.put("mime", mimeType)
        return o
    }

    private fun JSONObject.toItem(): DownloadItem {
        val arr = optJSONArray("parts")
        val parts = if (arr == null) emptyList() else List(arr.length()) { arr.getLong(it) }
        return DownloadItem(
            id = getString("id"),
            url = getString("url"),
            fileName = getString("fileName"),
            totalBytes = optLong("total", -1L),
            downloadedBytes = optLong("downloaded", 0L),
            partProgress = parts,
            supportsRanges = optBoolean("ranges", false),
            status = runCatching { Status.valueOf(getString("status")) }.getOrDefault(Status.PAUSED),
            error = if (isNull("error")) null else optString("error"),
            savedUri = if (isNull("savedUri")) null else optString("savedUri"),
            mimeType = optString("mime", "application/octet-stream")
        )
    }
}
