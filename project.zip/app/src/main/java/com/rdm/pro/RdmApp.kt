package com.rdm.pro

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class RdmApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(
                DownloadService.CHANNEL_ID,
                "Downloads",
                NotificationManager.IMPORTANCE_LOW
            )
        )
        Engine.init(this)
    }
}
